import React from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './App';

const mounts = {};

const api = {
  mount(selector, props) {
    const container = typeof selector === 'string' ? document.querySelector(selector) : selector;
    if (!container) {
      console.error('[mfe-pension] container not found', selector);
      return;
    }
    const root = createRoot(container);
    root.render(<App {...props} />);
    mounts[selector] = root;
  },
  unmount(selector) {
    const root = mounts[selector];
    if (root) {
      root.unmount();
      delete mounts[selector];
    }
  },
};

if (!window.mfe_pension) {
  window.mfe_pension = api;
}

export default api;
