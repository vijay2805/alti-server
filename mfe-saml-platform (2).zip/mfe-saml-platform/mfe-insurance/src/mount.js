// src/mount.js
import React from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './App';

const roots = {};

const api = {
  mount(selector, props) {
    const el = typeof selector === 'string' ? document.querySelector(selector) : selector;
    if (!el) {
      console.error('[mfe_insurance] mount: container not found', selector);
      return;
    }
    const root = createRoot(el);
    root.render(<App {...props} />);
    roots[selector] = root;
  },
  unmount(selector) {
    const root = roots[selector];
    if (root) {
      root.unmount();
      delete roots[selector];
    }
  }
};

export default api;
