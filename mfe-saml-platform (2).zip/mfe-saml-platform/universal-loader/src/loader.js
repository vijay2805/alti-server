const MFE_BASE = {
  insurance: 'http://localhost:4301',
  investment: 'http://localhost:4302',
  pension: 'http://localhost:4303',
  host: 'http://localhost:4300',
};


async function retry(fn, attempts = 3) {
  try {
    return await fn();
  } catch (e) {
    if (attempts <= 1) throw e;
    console.warn('[universal-loader] retrying after error', e);
    return retry(fn, attempts - 1);
  }
}

async function validateSAML(saml) {
  return retry(() =>
    fetch('http://localhost:9999/api/auth/validateSaml', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ saml }),
    }).then((r) => r.json())
  );
}

async function getProduct(sessionToken) {
  return retry(() =>
    fetch('http://localhost:9999/api/auth/productToken', {
      method: 'POST',
      headers: { Authorization: `Bearer ${sessionToken}` },
    }).then((r) => r.json())
  );
}

// 1️⃣ Load remoteEntry.js via <script>, not import()
function loadRemoteEntry(url, globalName) {
  return new Promise((resolve, reject) => {
    // If it's already loaded, reuse it
    if (window[globalName]) {
      return resolve(window[globalName]);
    }

    const script = document.createElement('script');
    script.src = url;
    script.type = 'text/javascript';
    script.async = true;

    script.onload = () => {
      const container = window[globalName];
      if (!container) {
        reject(new Error(`Remote global ${globalName} not found after loading`));
      } else {
        resolve(container);
      }
    };

    script.onerror = () => {
      reject(new Error(`Failed to load remoteEntry from ${url}`));
    };

    document.head.appendChild(script);
  });
}

// 2️⃣ Initialize sharing (optional but correct for MF)
async function initContainer(container) {
  // These globals are injected by webpack in your host build,
  // here we assume loader.js is bundled by webpack as well.
  if (typeof __webpack_init_sharing__ === 'function') {
    await __webpack_init_sharing__('default');
  }
  if (container.init && typeof __webpack_share_scopes__ !== 'undefined') {
    try {
      await container.init(__webpack_share_scopes__.default);
    } catch (e) {
      // Ignore "already been initialized" errors
      if (!/already been initialized/.test(e.message)) {
        throw e;
      }
    }
  }
}

async function run() {
  const mountPointId = 'react-product-root';
  const mountPoint = document.getElementById(mountPointId);
  if (!mountPoint) {
    console.error('[universal-loader] mount point not found');
    return;
  }

  const saml = mountPoint.dataset.samlToken;
  if (!saml) {
    console.error('[universal-loader] no SAML token found');
    return;
  }

  // // For now, hardcode insurance to debug
  // const type = 'insurance';
  // const baseUrl = MFE_BASE[type];
  // const remoteName = 'mfe_insurance'; // must match ModuleFederationPlugin name
// Unmount previous MFE if exists
if (window.currentMfe && window.currentMfe.unmount) {
  window.currentMfe.unmount('#' + mountPointId);
}

const { sessionToken } = await validateSAML(saml);
const { productId, productType = 'host' } = await getProduct(sessionToken);

const type = (productType || 'host').toLowerCase();
const baseUrl = MFE_BASE[type] || MFE_BASE.host;

const globalName =
  type === 'insurance'
    ? 'mfe_insurance'
    : type === 'investment'
    ? 'mfe_investment'
    : type === 'pension'
    ? 'mfe_pension'
    : 'mfe_host';

console.log('[universal-loader] loading', type, 'from', baseUrl);
  console.log('[universal-loader] loading', type, 'from', baseUrl);

  // 3️⃣ Load remoteEntry via script tag
  const container = await loadRemoteEntry(`${baseUrl}/remoteEntry.js`, globalName);

  // 4️⃣ Initialize shared scope (optional but correct)
  await initContainer(container);

  // 5️⃣ Get exposed module "./App" (your mount.js)
  const factory = await container.get('./App');
  const module = factory();
  const api = module.default || module; // { mount, unmount }

  // 6️⃣ Unmount previous MFE if any
  if (window.currentMfe && window.currentMfe.unmount) {
    window.currentMfe.unmount('#' + mountPointId);
  }
  window.currentMfe = api;

  // 7️⃣ Mount into JSP div
  api.mount('#' + mountPointId, {
    saml,
    // later: sessionToken, productId, productType...
  });
}

if (!window.UniversalLoader) {
  window.UniversalLoader = { run };
}

run();
