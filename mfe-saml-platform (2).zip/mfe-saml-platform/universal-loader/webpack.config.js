const path = require('path');

module.exports = {
  entry: './src/loader.js',
  output: {
    filename: 'loader.js',
    path: path.resolve(__dirname, 'dist'),
    publicPath: 'auto',
    library: {
      type: 'umd',
      name: 'UniversalLoader'
    }
  },
  devServer: {
    static: {
      directory: path.join(__dirname, 'dist')
    },
    port: 4400,
    headers: {
      "Access-Control-Allow-Origin": "*"
    }
  },
  mode: 'development'
};
