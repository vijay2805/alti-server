import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';

const Home = () => <div>Home</div>;
const Dashboard = () => <div>Dashboard</div>;
const Claim = () => <div>Claim Journey</div>;

const AppInner = ({ productId, productType }) => {
  const navigate = useNavigate();
  useEffect(() => {
    if (productType === 'insurance' || productType === 'investment') {
      navigate('/dashboard');
    }
  }, [productType, navigate]);
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/claim" element={<Claim />} />
    </Routes>
  );
};

export const App = (props) => (
  <BrowserRouter>
    <AppInner {...props} />
  </BrowserRouter>
);
