import express from 'express';
import cors from 'cors';

const app = express();
app.use(express.json());
app.use(cors());

// Simple SAML -> productType mapping table
const samlProductLookup = {
  'SAML_INS_123': { productId: 'P1001', productType: 'insurance' },
  'SAML_INV_456': { productId: 'P2001', productType: 'investment' },
  'SAML_PEN_789': { productId: 'P3001', productType: 'pension' },
  'SAML_DEFAULT': { productId: 'P0001', productType: 'host' },
};

// Validate SAML -> return session token
app.post('/api/auth/validateSaml', (req, res) => {
  const { saml } = req.body || {};
  if (!saml) {
    return res.status(400).json({ error: 'Missing saml' });
  }
  const sessionToken = 'SESSION_' + saml;
  console.log('[mock-api] validateSaml for', saml, '->', sessionToken);
  res.json({ sessionToken });
});

// Token API -> map sessionToken to product
app.post('/api/auth/productToken', (req, res) => {
  const auth = req.headers.authorization || '';
  const sessionToken = auth.replace('Bearer ', '');
  const samlKey = sessionToken.replace('SESSION_', '');
  const mapping = samlProductLookup[samlKey] || samlProductLookup['SAML_DEFAULT'];
  console.log('[mock-api] productToken for', sessionToken, '->', mapping);
  res.json(mapping);
});

const PORT = 9999;
app.listen(PORT, () => {
  console.log(`[mock-api] running at http://localhost:${PORT}`);
});
