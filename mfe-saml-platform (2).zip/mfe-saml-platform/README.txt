# MFE + JSP + SAML Demo

This repo shows:

- JSP page rendering products and loading a loader.js on button click
- Loader validates SAML, gets product token, decides productType
- Loader dynamically loads the correct React MFE via Module Federation
- MFEs (host, insurance, investment, pension) mount into JSP div

## Packages

- universal-loader: serves loader.js on http://localhost:4400/loader.js
- mfe-host: generic host MFE on http://localhost:4300
- mfe-insurance: insurance MFE on http://localhost:4301
- mfe-investment: investment MFE on http://localhost:4302
- mfe-pension: pension MFE on http://localhost:4303
- mock-api: Node Express mock for SAML + product token APIs
- jsp-example/journey.jsp: example JSP shell

## How to run (high level)

1. Install deps (using pnpm recommended)

   pnpm install

2. In one terminal, run mock API:

   cd mock-api
   pnpm start

3. In separate terminals, run each MFE:

   cd mfe-host && pnpm start
   cd mfe-insurance && pnpm start
   cd mfe-investment && pnpm start
   cd mfe-pension && pnpm start

4. Run universal-loader:

   cd universal-loader
   pnpm start

5. Deploy journey.jsp to your JSP container (Tomcat/Spring Boot) and open:

   http://localhost:8080/jsp-example/journey.jsp

Click on each "View Details" link to see the appropriate MFE load inside the JSP div.
