# React 19 Micro-Frontend Starter (Host + 2 Remotes + Foundation repo)
This ZIP includes **4 repos** (polyrepo style):
- `bank-foundation` (shared packages: contracts, middleware, ui, policy-engine)
- `bank-shell` (host)
- `bank-remote-insurance` (remote)
- `bank-remote-investment` (remote)

## Local dev (quick start)
> This starter uses **npm workspaces inside each repo** independently? No.
> Each repo is standalone. In real polyrepo you would publish `bank-foundation` packages to your npm registry.
> For convenience here, we use `file:` dependencies from remotes/shell → foundation packages.

### 1) Start remotes
```bash
cd bank-remote-insurance
npm i
npm start
```
```bash
cd bank-remote-investment
npm i
npm start
```

### 2) Start shell
```bash
cd bank-shell
npm i
npm start
```

Open:
- http://localhost:3000/insurance
- http://localhost:3000/investment

## Runtime remote URLs (dev/stage/prod)
Shell reads `bank-shell/public/mfe.manifest.json`
You can point to CDN remoteEntry.js without rebuilding the shell.

## Auth sharing (secure)
Shell exposes an in-memory Host Bridge: `window.__BANK_HOST__.auth`.
Remotes fetch tokens on demand. No localStorage token storage.
