import type { InvestmentProductUIModel } from "@bank/contracts";

export function mapSipProduct(raw: any): InvestmentProductUIModel {
  return {
    domain: "INVESTMENT",
    productType: "SIP",
    productCode: raw?.schemeCode ?? "SIP_001",
    title: raw?.schemeName ?? "SIP Investment",
    priceLabel: `From ₹ ${raw?.minAmount ?? 500} / month`,
    keyFacts: [
      { label: "Category", value: raw?.category ?? "Equity" },
      { label: "Risk", value: raw?.risk ?? "Moderate" },
    ],
    actions: [{ label: "Invest", actionId: "START_SIP" }],
    tags: ["Long term"],
  };
}
