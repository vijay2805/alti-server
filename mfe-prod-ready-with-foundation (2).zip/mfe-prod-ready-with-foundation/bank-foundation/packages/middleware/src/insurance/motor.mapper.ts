import type { InsuranceQuoteUIModel } from "@bank/contracts";

export function mapMotorQuote(raw: any): InsuranceQuoteUIModel {
  return {
    domain: "INSURANCE",
    productType: "MOTOR",
    productCode: raw?.planCode ?? "MOTOR_BASIC",
    title: raw?.planName ?? "Motor Insurance",
    priceLabel: `₹ ${raw?.premium ?? 999} / year`,
    keyFacts: [
      { label: "IDV", value: raw?.idv ?? "₹ 5,00,000" },
      { label: "NCB", value: raw?.ncb ?? "20%" },
    ],
    actions: [{ label: "Buy", actionId: "BUY_MOTOR" }],
    tags: ["Popular"],
  };
}
