import type { ProductCardUIModel } from "@bank/contracts";

export type PolicyResult = {
  allowed: boolean;
  reasons: string[];
  ui?: Partial<ProductCardUIModel>;
};

export function evaluatePolicies(input: {
  userRoles: string[];
  model: ProductCardUIModel;
}): PolicyResult {
  // Example policies:
  // - If not CUSTOMER, block investment actions
  if (input.model.domain === "INVESTMENT" && !input.userRoles.includes("CUSTOMER")) {
    return { allowed: false, reasons: ["NOT_ELIGIBLE_FOR_INVESTMENT"] };
  }

  // - Tag high value insurance
  if (input.model.domain === "INSURANCE" && input.model.priceLabel.includes("₹")) {
    return {
      allowed: true,
      reasons: [],
      ui: { tags: [...(input.model.tags || []), "Checked by policy"] },
    };
  }

  return { allowed: true, reasons: [] };
}
