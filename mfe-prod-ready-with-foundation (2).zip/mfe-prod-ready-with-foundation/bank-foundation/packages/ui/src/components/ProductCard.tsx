import React from "react";
import type { ProductCardUIModel } from "@bank/contracts";

export function ProductCard({ model }: { model: ProductCardUIModel }) {
  return (
    <div style={{ border: "1px solid #ddd", borderRadius: 12, padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
        <div>
          <div style={{ fontSize: 14, opacity: 0.7 }}>{model.domain}</div>
          <h3 style={{ margin: "6px 0" }}>{model.title}</h3>
          <div style={{ fontWeight: 600 }}>{model.priceLabel}</div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "start" }}>
          {(model.tags || []).map((t) => (
            <span key={t} style={{ fontSize: 12, border: "1px solid #eee", padding: "2px 8px", borderRadius: 999 }}>
              {t}
            </span>
          ))}
        </div>
      </div>

      <ul style={{ marginTop: 12 }}>
        {model.keyFacts.map((k) => (
          <li key={k.label}>
            <b>{k.label}:</b> {k.value}
          </li>
        ))}
      </ul>

      <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
        {model.actions.map((a) => (
          <button key={a.actionId} onClick={() => alert(a.actionId)}>
            {a.label}
          </button>
        ))}
      </div>
    </div>
  );
}
