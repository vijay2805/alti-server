export type Domain = "INSURANCE" | "INVESTMENT";

export type KeyFact = { label: string; value: string };

export type ProductCardUIModel = {
  domain: Domain;
  productCode: string;
  title: string;
  priceLabel: string;
  keyFacts: KeyFact[];
  actions: { label: string; actionId: string }[];
  tags?: string[];
};
