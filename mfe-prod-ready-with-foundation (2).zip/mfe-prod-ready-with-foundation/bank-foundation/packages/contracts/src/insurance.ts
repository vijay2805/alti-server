import type { ProductCardUIModel } from "./common";

export type InsuranceQuoteUIModel = ProductCardUIModel & {
  domain: "INSURANCE";
  productType: "HOME" | "MOTOR" | "PET";
};
