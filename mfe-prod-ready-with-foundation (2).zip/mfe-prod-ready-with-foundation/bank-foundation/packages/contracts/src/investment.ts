import type { ProductCardUIModel } from "./common";

export type InvestmentProductUIModel = ProductCardUIModel & {
  domain: "INVESTMENT";
  productType: "SIP" | "FD";
};
