import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import QuotePage from "../pages/QuotePage";

export default function InsuranceApp() {
  return (
    <div style={{ padding: 16, border: "1px solid #ddd", borderRadius: 12 }}>
      <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
        <Link to="/insurance">Quote</Link>
      </div>

      <Routes>
        <Route path="/" element={<QuotePage />} />
      </Routes>
    </div>
  );
}
