type Session = { userId: string; roles: string[]; expiresAt: number };

declare global {
  interface Window {
    __BANK_HOST__?: {
      auth: {
        getAccessToken: () => Promise<string>;
        getIdToken: () => Promise<string>;
        getSession: () => Promise<Session | null>;
        subscribe: (listener: (s: Session | null) => void) => () => void;
      };
    };
  }
}

export async function getAccessToken() {
  if (!window.__BANK_HOST__?.auth) throw new Error("HOST_BRIDGE_NOT_AVAILABLE");
  return window.__BANK_HOST__.auth.getAccessToken();
}

export async function getSession() {
  if (!window.__BANK_HOST__?.auth) throw new Error("HOST_BRIDGE_NOT_AVAILABLE");
  return window.__BANK_HOST__.auth.getSession();
}
