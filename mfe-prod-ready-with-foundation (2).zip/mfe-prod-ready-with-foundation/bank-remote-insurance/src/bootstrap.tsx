import React from "react";
import { createRoot } from "react-dom/client";
import InsuranceApp from "./app/InsuranceApp";

const el = document.getElementById("root");

if (el) {
  createRoot(el).render(<InsuranceApp />);
}
