const HtmlWebpackPlugin = require('html-webpack-plugin');
const { ModuleFederationPlugin } = require('webpack').container;
const path = require('path');

module.exports = {
  entry: './src/main.tsx',
  devServer: {
    port: 3001,
    historyApiFallback: true,
    headers: { 'Access-Control-Allow-Origin': '*' },
    static: { directory: __dirname + '/public' },
  },
  output: { publicPath: 'auto', clean: true },
  resolve: { extensions: ['.tsx', '.ts', '.js'] },
  module: {
    rules: [
      {
        test: /\.[jt]sx?$/,
        loader: 'babel-loader',
        exclude: /node_modules/,
        include: [
          path.resolve(__dirname, 'src'),
          path.resolve(__dirname, '../bank-foundation/packages'),
        ], // ✅ ADD THIS
      },
      { test: /\.css$/, use: ['style-loader', 'css-loader'] },
    ],
  },
  plugins: [
    new ModuleFederationPlugin({
      name: 'insurance',
      filename: 'remoteEntry.js',
      exposes: {
        './App': './src/app/InsuranceApp.tsx',
      },
      shared: {
        react: { singleton: true, requiredVersion: false,  eager: false },
        'react-dom': { singleton: true, requiredVersion: false,  eager: false },
        "react-router-dom": { singleton: true, requiredVersion: false, eager: false },
        '@bank/contracts': { singleton: true, requiredVersion: false,  eager: false },
        '@bank/ui': { singleton: true, requiredVersion: false },
        '@bank/middleware': { singleton: true, requiredVersion: false },
        '@bank/policy-engine': { singleton: true, requiredVersion: false },
      },
    }),
    new HtmlWebpackPlugin({ template: './public/index.html' }),
  ],
};
