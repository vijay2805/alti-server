const HtmlWebpackPlugin = require("html-webpack-plugin");
const { ModuleFederationPlugin } = require("webpack").container;

function createRuntimeRemote(remoteName) {
  return `promise new Promise(async (resolve) => {
    const res = await fetch('/mfe.manifest.json', { cache: 'no-store' });
    const manifest = await res.json();
    const url = manifest['${remoteName}'];
    if (!url) throw new Error('Remote URL not found in mfe.manifest.json for: ${remoteName}');

    const scriptId = 'remote-${remoteName}';
    if (!document.getElementById(scriptId)) {
      const script = document.createElement('script');
      script.id = scriptId;
      script.src = url;
      script.type = 'text/javascript';
      script.async = true;
      await new Promise((ok, fail) => {
        script.onload = ok;
        script.onerror = fail;
        document.head.appendChild(script);
      });
    }

    const proxy = {
      get: (request) => window['${remoteName}'].get(request),
      init: (arg) => {
        try { return window['${remoteName}'].init(arg); }
        catch (e) { console.warn('Remote init warning:', e); }
      }
    };
    resolve(proxy);
  })`;
}

module.exports = {
  entry: "./src/main.tsx",
  devServer: {
    port: 3000,
    historyApiFallback: true,
    headers: { "Access-Control-Allow-Origin": "*" },
    static: { directory: __dirname + "/public" },
  },
  output: { publicPath: "auto", clean: true },
  resolve: { extensions: [".tsx", ".ts", ".js"] },
  module: {
    rules: [
      { test: /\.[jt]sx?$/, loader: "babel-loader", exclude: /node_modules/,
    },
      { test: /\.css$/, use: ["style-loader", "css-loader"] },
    ],
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "shell",
      remotes: {
        insurance: createRuntimeRemote("insurance"),
        investment: createRuntimeRemote("investment"),
      },
      shared: {
        react: { singleton: true, requiredVersion: false,  eager: false },
        "react-dom": { singleton: true, requiredVersion: false,  eager: false },
        "react-router-dom": { singleton: true, requiredVersion: false, eager: false },
        "@bank/contracts": { singleton: true, requiredVersion: false,  eager: false },
        "@bank/ui": { singleton: true, requiredVersion: false },
        "@bank/middleware": { singleton: true, requiredVersion: false },
        "@bank/policy-engine": { singleton: true, requiredVersion: false },
      },
    }),
    new HtmlWebpackPlugin({ template: "./public/index.html" }),
  ],
};
