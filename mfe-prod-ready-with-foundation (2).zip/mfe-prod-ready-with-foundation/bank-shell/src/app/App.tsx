import React from "react";
import { BrowserRouter, Routes, Route, Link, Navigate } from "react-router-dom";
import { logout } from "../federation/hostBridge";

const InsuranceApp = React.lazy(() => import("insurance/App"));
const InvestmentApp = React.lazy(() => import("investment/App"));

export default function App() {
  return (
    <BrowserRouter>
      <div style={{ padding: 16, display: "flex", gap: 12 }}>
        <Link to="/insurance">Insurance</Link>
        <Link to="/investment">Investment</Link>
        <button onClick={() => logout()} style={{ marginLeft: "auto" }}>
          Logout (simulate)
        </button>
      </div>

      <React.Suspense fallback={<div style={{ padding: 16 }}>Loading remote…</div>}>
        <Routes>
          {/* <Route path="/" element={<Navigate to="/insurance" replace />} /> */}
          <Route path="/insurance/*" element={<InsuranceApp />} />
          <Route path="/investment/*" element={<InvestmentApp />} />
        </Routes>
      </React.Suspense>
    </BrowserRouter>
  );
}
