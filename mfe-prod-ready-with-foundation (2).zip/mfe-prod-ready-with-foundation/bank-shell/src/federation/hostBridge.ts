export type Session = { userId: string; roles: string[]; expiresAt: number };
export type AuthChangeListener = (session: Session | null) => void;

export type HostAuthBridge = {
  getAccessToken: () => Promise<string>;
  getIdToken: () => Promise<string>;
  getSession: () => Promise<Session | null>;
  subscribe: (listener: AuthChangeListener) => () => void;
};

declare global {
  interface Window {
    __BANK_HOST__?: { auth: HostAuthBridge };
  }
}

let currentSession: Session | null = {
  userId: "demo-user-123",
  roles: ["CUSTOMER"],
  expiresAt: Date.now() + 15 * 60 * 1000,
};

let listeners: AuthChangeListener[] = [];
function notify() { listeners.forEach((l) => l(currentSession)); }

async function issueAccessToken() { return "demo-access-" + Math.random().toString(16).slice(2); }
async function issueIdToken() { return "demo-id-" + Math.random().toString(16).slice(2); }

export function initHostBridge() {
  window.__BANK_HOST__ = {
    auth: {
      async getAccessToken() {
        if (!currentSession || currentSession.expiresAt < Date.now()) {
          currentSession = null; notify(); throw new Error("SESSION_EXPIRED");
        }
        return issueAccessToken();
      },
      async getIdToken() {
        if (!currentSession || currentSession.expiresAt < Date.now()) {
          currentSession = null; notify(); throw new Error("SESSION_EXPIRED");
        }
        return issueIdToken();
      },
      async getSession() {
        if (currentSession && currentSession.expiresAt < Date.now()) currentSession = null;
        return currentSession;
      },
      subscribe(listener) {
        listeners.push(listener);
        listener(currentSession);
        return () => { listeners = listeners.filter((x) => x !== listener); };
      },
    },
  };
}

export function logout() { currentSession = null; notify(); }
