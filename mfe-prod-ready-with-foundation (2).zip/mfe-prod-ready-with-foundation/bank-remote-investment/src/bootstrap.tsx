import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import InvestmentApp from "./app/InvestmentApp";

const el = document.getElementById("root");

if (el) {
  createRoot(el).render(
    <BrowserRouter>
      <InvestmentApp />
    </BrowserRouter>
  );
}
