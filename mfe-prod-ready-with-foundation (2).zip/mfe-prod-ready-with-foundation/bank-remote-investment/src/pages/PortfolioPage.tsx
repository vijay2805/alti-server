import React from "react";
import { ProductCard } from "@bank/ui";
import { mapSipProduct } from "@bank/middleware";
import { evaluatePolicies } from "@bank/policy-engine";
import { getAccessToken, getSession } from "../shared/hostAuth";

export default function PortfolioPage() {
  const [token, setToken] = React.useState<string>("");
  const [model, setModel] = React.useState<any>(null);
  const [policy, setPolicy] = React.useState<any>(null);

  React.useEffect(() => {
    (async () => {
      const session = await getSession();
      const t = await getAccessToken();
      setToken(t);

      // simulate backend response
      const raw = { schemeCode: "SIP_TOP100", schemeName: "Top 100 Equity SIP", minAmount: 1000, category: "Equity", risk: "High" };
      const mapped = mapSipProduct(raw);

      const res = evaluatePolicies({ userRoles: session?.roles ?? [], model: mapped });
      setPolicy(res);

      const finalModel = res.ui ? { ...mapped, ...res.ui } : mapped;
      setModel(finalModel);
    })().catch((e) => setToken("ERROR: " + (e?.message || String(e))));
  }, []);

  return (
    <div style={{ padding: 16 }}>
      <h2>Investment Remote</h2>
      <p>Uses @bank/ui + @bank/middleware + @bank/policy-engine</p>
      <div style={{ marginTop: 12 }}>
        <b>Access Token from Shell:</b>
        <pre style={{ whiteSpace: "pre-wrap" }}>{token}</pre>
      </div>

      {policy && (
        <div style={{ marginTop: 12 }}>
          <b>Policy Result:</b>
          <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(policy, null, 2)}</pre>
        </div>
      )}

      {model && (
        <div style={{ marginTop: 12 }}>
          <ProductCard model={model} />
        </div>
      )}
    </div>
  );
}
