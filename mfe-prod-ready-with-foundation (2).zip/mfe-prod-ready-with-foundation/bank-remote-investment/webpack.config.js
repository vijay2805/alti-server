const HtmlWebpackPlugin = require("html-webpack-plugin");
const { ModuleFederationPlugin } = require("webpack").container;

module.exports = {
  entry: "./src/main.tsx",
  devServer: {
    port: 3002,
    historyApiFallback: true,
    headers: { "Access-Control-Allow-Origin": "*" },
    static: { directory: __dirname + "/public" },
  },
  output: { publicPath: "auto", clean: true },
  resolve: { extensions: [".tsx", ".ts", ".js"] },
  module: {
    rules: [
      { test: /\.[jt]sx?$/, loader: "babel-loader", exclude: /node_modules/, 
    },
      { test: /\.css$/, use: ["style-loader", "css-loader"] },
    ],
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "investment",
      filename: "remoteEntry.js",
      exposes: {
        "./App": "./src/app/InvestmentApp.tsx",
      },
      shared: {
        react: { singleton: true, requiredVersion: false,  eager: false },
        "react-dom": { singleton: true, requiredVersion: false,  eager: false },
        "react-router-dom": { singleton: true, requiredVersion: false, eager: false },
        "@bank/contracts": { singleton: true, requiredVersion: false,  eager: false },
        "@bank/ui": { singleton: true, requiredVersion: false },
        "@bank/middleware": { singleton: true, requiredVersion: false },
        "@bank/policy-engine": { singleton: true, requiredVersion: false },
      },
    }),
    new HtmlWebpackPlugin({ template: "./public/index.html" }),
  ],
};
