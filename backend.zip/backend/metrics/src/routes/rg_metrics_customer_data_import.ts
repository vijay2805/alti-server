import express from "express";
import RgMetricsCustomerDataImportController from "../controllers/rg_metrics_customer_data_importController";

const router = express.Router();

router.post(
  "/",
  RgMetricsCustomerDataImportController.uploadFile,
  RgMetricsCustomerDataImportController.addRgMetricsCustomerData
);

router.get("/db-list", RgMetricsCustomerDataImportController.getDatabaseList);
router.get("/schema-list", RgMetricsCustomerDataImportController.getSchemaList);
router.get("/table-list", RgMetricsCustomerDataImportController.getTableList);
router.get("/column-list", RgMetricsCustomerDataImportController.getColumnList);
router.get(
  "/column-comments",
  RgMetricsCustomerDataImportController.getColumnComments
);

router.get(
  "/comment-table",
  RgMetricsCustomerDataImportController.getTableComments
);

router.post("/db-source", RgMetricsCustomerDataImportController.saveDbSource);
router.post("/api-source", RgMetricsCustomerDataImportController.saveAPISource);
router.post(
  "/metric-config",
  RgMetricsCustomerDataImportController.addMetricCalcConfiguration
);

router.get(
  "/metric-config",
  RgMetricsCustomerDataImportController.getMetricCalcConfiguration
);
export default router;
