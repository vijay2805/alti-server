import express from "express";
import RgCusomersDetailsController from "../controllers/rg_customersController";

const router = express.Router();

router.get("/:id", RgCusomersDetailsController.getRgCustomersDetailsById);

router.patch("/:id", RgCusomersDetailsController.updateRgCustomersDetails);

router.get("/", RgCusomersDetailsController.getRgCustomersDetails);

router.post("/", RgCusomersDetailsController.addRgCustomersDetails);

export default router;
