import express from "express";
import RgMetricsCustomFieldsController from "../controllers/rg_metrics_custom_fields_masterController";

const router = express.Router();

router.get(
  "/:id",
  RgMetricsCustomFieldsController.getRgMetricsCustomFieldsMasterById
);

router.patch(
  "/:id",
  RgMetricsCustomFieldsController.updateRgMetricsCustomFieldsMaster
);

router.post(
  "/",
  RgMetricsCustomFieldsController.addRgMetricsCustomFieldsMaster
);

router.get(
    "/",
    RgMetricsCustomFieldsController.getRgMetricsCustomFieldsMaster
  );

export default router;
