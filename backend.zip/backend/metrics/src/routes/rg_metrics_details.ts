import express from "express";
import RgMetricsDetailsController from "../controllers/rg_metrics_detailsController";

const router = express.Router();
router.get("/metric-customer-data-source", RgMetricsDetailsController.getMetricsCustomerDataSource)
router.get(
  "/custom-fields",
  RgMetricsDetailsController.getRgMetricsCustomFields
);

router.get("/:id", RgMetricsDetailsController.getRgMetricsDetailsById);

router.post("/data-integration", RgMetricsDetailsController.DataIntegration);

router.post("/meta-data", RgMetricsDetailsController.MetaUpdate);

router.post("/metrics-view", RgMetricsDetailsController.getCustomerMetricsDetails);

router.patch("/:id", RgMetricsDetailsController.updateRgMetricsDetails);

router.get("/", RgMetricsDetailsController.getRgMetricsDetails);

router.post("/", RgMetricsDetailsController.addRgMetricsDetails);

export default router;
