import express from "express";
import RgMetricsCustomerMappingController from "../controllers/rg_metrics_customer_mappingController";

const router = express.Router();

router.get(
  "/:id",
  RgMetricsCustomerMappingController.getRgMetricsCustomerMappingById
);

router.patch(
  "/:id",
  RgMetricsCustomerMappingController.updateRgMetricsCustomerMapping
);

router.get("/", RgMetricsCustomerMappingController.getRgMetricsCustomerMapping);

router.post(
  "/",
  RgMetricsCustomerMappingController.addRgMetricsCustomerMapping
);

export default router;
