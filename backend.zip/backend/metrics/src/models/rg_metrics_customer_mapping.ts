import connection from "../config/connection";
import { Model, DataTypes, BuildOptions } from "sequelize";

interface rg_metrics_customer_mappingModel extends Model {
  metric_customer_map_id: number;
  metric_id: number;
  customer_id: number;
  metric_formula: string;
  metric_formula_type: string;
  metric_formula_column_mapping: string;
  metric_custom_column_mapping: string;
  api_info: string;
  data_source: string;
  created_on: string;
  created_by: number;
  modified_on: string;
  modified_by: number;
  status: string;
}

type rg_metrics_customer_mappingModelStatic = typeof Model & {
  new (
    values?: object,
    options?: BuildOptions
  ): rg_metrics_customer_mappingModel;
};

const rg_metrics_customer_mapping = <rg_metrics_customer_mappingModelStatic>(
  connection.define(
    "rg_metrics_customer_mapping",
    {
      metric_customer_map_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      metric_id: {
        type: DataTypes.INTEGER,
      },
      customer_id: {
        type: DataTypes.INTEGER,
      },
      metric_formula: {
        type: DataTypes.JSONB,
        get() {
          if (this.getDataValue("metric_formula")) {
            return JSON.parse(this.getDataValue("metric_formula"));
          } else {
            return null;
          }
        },
      },
      metric_formula_type: { type: DataTypes.CHAR },
      metric_formula_column_mapping: {
        type: DataTypes.JSONB,
        get() {
          if (this.getDataValue("metric_formula_column_mapping")) {
            return JSON.parse(
              this.getDataValue("metric_formula_column_mapping")
            );
          } else {
            return null;
          }
        },
      },
      metric_custom_column_mapping: {
        type: DataTypes.JSONB,
        get() {
          if (this.getDataValue("metric_custom_column_mapping")) {
            return JSON.parse(
              this.getDataValue("metric_custom_column_mapping")
            );
          } else {
            return null;
          }
        },
      },
      data_source: { type: DataTypes.STRING },
      api_info: {
        type: DataTypes.JSONB,
        get() {
          if (this.getDataValue("api_info")) {
            return JSON.parse(this.getDataValue("api_info"));
          } else {
            return null;
          }
        },
      },
      created_on: { type: DataTypes.DATE, allowNull: true },
      created_by: { type: DataTypes.INTEGER, allowNull: true },
      modified_on: { type: DataTypes.DATE, allowNull: true },
      modified_by: { type: DataTypes.INTEGER, allowNull: true },
      status: { type: DataTypes.CHAR, allowNull: false },
    },
    { schema: "metrics", freezeTableName: true, timestamps: false }
  )
);

export default rg_metrics_customer_mapping;
