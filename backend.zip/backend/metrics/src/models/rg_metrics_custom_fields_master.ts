import connection from "../config/connection";
import { Model, DataTypes, BuildOptions } from "sequelize";

interface rg_metrics_custom_fields_masterModel extends Model {
  metric_cust_id: number;
  metric_cust_field_name: string;
  metric_cust_field_desc: string;
  created_on: string;
  created_by: number;
  modified_on: string;
  modified_by: number;
  status: string;
}

type rg_metrics_custom_fields_masterModelStatic = typeof Model & {
  new (
    values?: object,
    options?: BuildOptions
  ): rg_metrics_custom_fields_masterModel;
};

const rg_metrics_custom_fields_master = <
  rg_metrics_custom_fields_masterModelStatic
>connection.define(
  "rg_metrics_custom_fields_master",
  {
    metric_cust_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    metric_cust_field_name: { type: DataTypes.STRING, allowNull: false },

    metric_cust_field_desc: { type: DataTypes.TEXT },
    created_on: { type: DataTypes.DATE, allowNull: true },
    created_by: { type: DataTypes.INTEGER, allowNull: true },
    modified_on: { type: DataTypes.DATE, allowNull: true },
    modified_by: { type: DataTypes.INTEGER, allowNull: true },
    status: { type: DataTypes.CHAR, allowNull: false },
  },
  { schema: "metrics", freezeTableName: true, timestamps: false }
);

export default rg_metrics_custom_fields_master;
