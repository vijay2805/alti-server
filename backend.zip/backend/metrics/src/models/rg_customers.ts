import connection from "../config/connection";
import { Model, DataTypes, BuildOptions } from "sequelize";

interface rg_customersModel extends Model {
  customer_id: number;
  company_code: string;
  company_name: string;
  address_line_1: string;
  address_line_2: string;
  city: string;
  region_state_province_county: string;
  country: string;
  zip_code_pin_code: string;
  industry: string;
  is_subsidiary: string;
  size: string;
  market_category: string;
  territory: string;
  region: string;
  parent_company_code: string;
  status: string;
  acv: string;
  contract_start_date: Date;
  contract_end_date: Date;
  headcount: number;
  pep: string;
  created_on: string;
  created_by: number;
  modified_on: string;
  modified_by: number;
}

type rg_customersModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): rg_customersModel;
};

const rg_customers = <rg_customersModelStatic>connection.define(
  "rg_customers",
  {
    customer_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    company_code: { type: DataTypes.STRING, allowNull: false },
    company_name: {
      type: DataTypes.STRING,
    },
    address_line_1: { type: DataTypes.TEXT },
    address_line_2: { type: DataTypes.TEXT },
    city: { type: DataTypes.STRING },
    region_state_province_county: { type: DataTypes.STRING },
    country: { type: DataTypes.STRING },
    zip_code_pin_code: { type: DataTypes.STRING },
    industry: { type: DataTypes.STRING },
    is_subsidiary: { type: DataTypes.BOOLEAN },
    size: { type: DataTypes.INTEGER },
    market_category: { type: DataTypes.STRING },
    territory: { type: DataTypes.STRING },
    region: { type: DataTypes.STRING },
    parent_company_code: { type: DataTypes.STRING },
    acv: { type: DataTypes.STRING },
    contract_start_date: { type: DataTypes.DATE },
    contract_end_date: { type: DataTypes.DATE },
    headcount: { type: DataTypes.INTEGER },
    pep: { type: DataTypes.STRING },
    created_on: { type: DataTypes.DATE, allowNull: true },
    created_by: { type: DataTypes.INTEGER, allowNull: true },
    modified_on: { type: DataTypes.DATE, allowNull: true },
    modified_by: { type: DataTypes.INTEGER, allowNull: true },
    status: { type: DataTypes.CHAR, allowNull: false },
  },
  { schema: "metrics", freezeTableName: true, timestamps: false }
);

export default rg_customers;
