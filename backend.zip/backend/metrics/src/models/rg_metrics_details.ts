import connection from "../config/connection";
import { Model, DataTypes, BuildOptions } from "sequelize";

interface rg_metrics_detailsModel extends Model {
  metric_id: number;
  metric_name: string;
  metric_desc: string;
  metric_formula: string;
  metric_custom_fields: string;
  metric_table_info: string;
  created_on: string;
  created_by: number;
  modified_on: string;
  modified_by: number;
  status: string;
}

type rg_metrics_detailsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): rg_metrics_detailsModel;
};

const rg_metrics_details = <rg_metrics_detailsModelStatic>connection.define(
  "rg_metrics_details",
  {
    metric_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    metric_name: { type: DataTypes.STRING, allowNull: false },
    metric_formula: {
      type: DataTypes.JSONB,
      get() {
        if (this.getDataValue("metric_formula")) {
          return JSON.parse(this.getDataValue("metric_formula"));
        } else {
          return null;
        }
      },
    },
    metric_desc: { type: DataTypes.TEXT },
    metric_custom_fields: { type: DataTypes.TEXT, allowNull: true },
    metric_fields: {
      type: DataTypes.JSONB,
      get() {
        if (this.getDataValue("metric_fields")) {
          return JSON.parse(this.getDataValue("metric_fields"));
        } else {
          return null;
        }
      },
    },
    metric_filter_fields: {
      type: DataTypes.JSONB,
      get() {
        if (this.getDataValue("metric_filter_fields")) {
          return JSON.parse(this.getDataValue("metric_filter_fields"));
        } else {
          return null;
        }
      },
    },
    metric_table_info: { type: DataTypes.STRING },
    created_on: { type: DataTypes.DATE, allowNull: true },
    created_by: { type: DataTypes.INTEGER, allowNull: true },
    modified_on: { type: DataTypes.DATE, allowNull: true },
    modified_by: { type: DataTypes.INTEGER, allowNull: true },
    status: { type: DataTypes.CHAR, allowNull: false },
  },
  { schema: "metrics", freezeTableName: true, timestamps: false }
);

export default rg_metrics_details;
