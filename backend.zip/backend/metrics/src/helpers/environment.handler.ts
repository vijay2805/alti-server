import getConfiguration from "../environments/environment";

/**
 * Get Host
 */
export const envPORT = () => getConfiguration().PORT;

export const envUSER = () => getConfiguration().USER;

export const envPASSWORD = () => getConfiguration().PASSWORD;

export const envAUTH_KEY = () => getConfiguration().AUTH_KEY;

export const envHOST = () => getConfiguration().HOST;

export const envDB_URL = () => getConfiguration().DB_URL;

export const envWIDGET_TOKEN = () => getConfiguration().WIDGET_TOKEN;

export const envJWT_SECRET = () => getConfiguration().JWT_SECRET;

export const envSERVER_URL = () => getConfiguration().SERVER_URL;

export const envMONGO_DB_URL = () => getConfiguration().MONGO_DB_URL;

export const envSERVER_ASSETS_URL = () => getConfiguration().SERVER_ASSETS_URL;

export const envSSL_CERT = () => getConfiguration().SSL_CERT;

export const envSSL_KEY = () => getConfiguration().SSL_KEY;

export const userDB_URL = () => getConfiguration().userDB_URL;

export const customer_folder = () => getConfiguration().Customer_folder;

export const DATAWIDGETURL = () => getConfiguration().DATAWIDGETURL;

export const ENV_URL = () => getConfiguration().ENV_URL;

export const env_EMAIL = () => getConfiguration().env_EMAIL;

export const ENV = () => getConfiguration().ENV;

export const envProdDataLake_URL = () =>
  getConfiguration().PROD_DATALAKE_DB_URL;

export const ENV_HOST = () => getConfiguration().ENV_HOST;

export const envPROD_DATALAKE_DB = () => getConfiguration().PROD_DATALAKE_DB;

export const envPROD_DATALAKE_DB_UP = () =>
  getConfiguration().PROD_DATALAKE_DB_UP;

export const envPG_DB = () => getConfiguration().PG_DB;
export const envPG_DB_UP = () => getConfiguration().PG_DB_UP;

export const envAPI_ENGINE_DB = () => getConfiguration().API_ENGINE_DB;
export const envAPI_ENGINE_DB_UP = () => getConfiguration().API_ENGINE_DB_UP;

export const envMONGO_DB = () => getConfiguration().MONGO_DB;
export const envMONGO_DB_UP = () => getConfiguration().MONGO_DB_UP;

export const envPG_DB_Master = () => getConfiguration().PG_DB_Master;
export const envMONGO_DB_Master = () => getConfiguration().MONGO_DB_Master;
export const env_pass = () => getConfiguration().env_pass;
export const env_api = () => getConfiguration().env_api;

export const CONNECTORS_SERVER_URL = ()=>getConfiguration().CONNECTORS_SERVER;
export const RGSPY_SERVER_URL = ()=>getConfiguration().RGSPY_SERVER;
export const FLOWBUILDER_SERVER_URL=()=>getConfiguration().FLOWBUILDER_SERVER;