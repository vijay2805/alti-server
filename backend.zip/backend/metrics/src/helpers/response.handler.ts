import { Request, Response } from "express";
import {
  ReasonPhrases,
  StatusCodes,
  getReasonPhrase,
  getStatusCode,
} from "http-status-codes";

/**
 * Error response
 * @param req
 * @param res
 */
export const DYNAMICJSONERROR = (req: Request, res: Response) => {
  const errorCode: number = res.locals.errorCode || StatusCodes.BAD_REQUEST;
  const obj = {
    status: errorCode,
    data: res.locals.data || {},
    errors: res.locals.errors || {},
    message: res.locals.message || "",
    errorCode: errorCode,
  };
  res.status(errorCode).send(obj);
};
export const JSONERROR = (req: Request, res: Response) => {
  const errorCode: number = res.locals.errorCode || StatusCodes.BAD_REQUEST;
  const obj = {
    status: errorCode,
    data: res.locals.data || {},
    errors: res.locals.errors || {},
    message: res.locals.message || "",
    errorCode: errorCode,
  };
  res.send(obj);
};

/**
 * Success response
 * @param req
 * @param res
 */
export const JSONSUCCESS = (req: Request, res: Response) => {
  let obj = {
    status: StatusCodes.OK,
    data: {},
    errors: {},
    message: "",
  };

  if (
    res.locals.data &&
    res.locals.data.length &&
    res.locals.data[0]["e"] &&
    res.locals.data[0]["e"].includes("failed")
  ) {
    res.locals.errors = res.locals.data[0]["e"];
    res.locals.message = res.locals.data[0]["e"];
    JSONERROR(req, res);
  } else {
    if (res.locals.data) {
      obj.data = res.locals.data;
    }
    if (res.locals.errors) {
      obj.errors = res.locals.errors;
    }
    if (res.locals.message) {
      obj.message = res.locals.message;
    }
    res.status(StatusCodes.OK).send(obj);
  }
};
