import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import * as bodyParser from "body-parser";
import helmet from "helmet";
import { createServer } from "http";
const session = require("express-session");
import connection from "./config/connection";
import * as EnvHandler from "./helpers/environment.handler";
import rg_metrics_details from "./routes/rg_metrics_details";
import rg_metrics_customer_mapping from "./routes/rg_metrics_customer_mapping";
import rg_metrics_custom_fields_master from "./routes/rg_metrics_custom_fields_master";
import rg_customers from "./routes/rg_customers";
import rg_metrics_customer_data_import from "./routes/rg_metrics_customer_data_import";

const app = express();
dotenv.config();

const port: any = EnvHandler.envPORT() || 7001;
const env: any = EnvHandler.ENV() || "local";
const host = EnvHandler.envSERVER_URL();

const corsOptions = {
  origin: "*", // Update with your frontend's origin
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  credentials: true,
  optionsSuccessStatus: 204,
};
app.use(cors(corsOptions));
app.use(function (req, res, next) {
  res.setHeader(
    "Content-Security-Policy-Report-Only",
    "default-src 'self'; font-src 'self'; img-src 'self'; script-src 'self'; style-src 'self'; frame-src 'self'"
  );
  next();
});

app.use(
  session({
    secret: "t4ds4w",
    cookie: {
      httpOnly: true,
      secure: true,
      maxAge: 1200000,
    },
    saveUninitialized: false,
  })
);

app.use(bodyParser.json({ limit: "2gb" }));
app.all("/*", function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  next();
});
app.disable("etag").disable("x-powered-by");
app.use(bodyParser.urlencoded({ extended: true })); //for token

app.use(helmet());
app.use(
  helmet.hsts({
    // 60 days
    maxAge: 86400,
    // removing the "includeSubDomains" option
    includeSubDomains: false,
  })
);

app.get("/", (req, res) => {
  res.setHeader(
    "Strict-Transport-Security",
    "max-age=31536000; includeSubDomains"
  );
  res.send("Hey there!!!");
});

app.use("/metrics-gateway/rg-metrics-details", rg_metrics_details);

app.use(
  "/metrics-gateway/rg-metrics-customer-mapping",
  rg_metrics_customer_mapping
);
app.use(
  "/metrics-gateway/rg-metrics-custom-fields",
  rg_metrics_custom_fields_master
);

app.use("/metrics-gateway/rg-customers", rg_customers);
app.use(
  "/metrics-gateway-formdata/rg-metrics-customer-data-import",
  rg_metrics_customer_data_import
);

app.use(
  "/metrics-gateway/rg-metrics-customer-data-import",
  rg_metrics_customer_data_import
);
connection
  .authenticate()
  .then(() => {
    console.log(
      "PostgreSQL Connection using Sequelize has been established successfully."
    );
  })
  .catch((err: string) => {
    console.error("Unable to connect to the database:", err);
  });

let server = createServer(app).listen(port, "127.0.0.1", 511, () => {
  console.log(`Server is listening on ${port}`);
});
