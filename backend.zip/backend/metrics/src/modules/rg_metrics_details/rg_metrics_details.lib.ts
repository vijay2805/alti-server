import rg_metrics_details from "../../models/rg_metrics_details";

export const addRgMetricsDetails = async (input: any) => {
  const result = await rg_metrics_details.create(input);
  return result;
};

export const updateRgMetricsDetails = async (condition: any, obj: any) => {
  const result = await rg_metrics_details.update(obj, {
    where: condition,
  });
  return result;
};

export const getRgMetricsDetailsById = async (condition: any) => {
  const result = await rg_metrics_details.findOne({
    where: condition,
  });
  return result;
};

export const getRgMetricsDetailsList = async (condition: any) => {
  const result = await rg_metrics_details.findAll({
    where: condition,
  });
  return result;
};
