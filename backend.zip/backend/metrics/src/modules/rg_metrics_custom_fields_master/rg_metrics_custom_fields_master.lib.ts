import rg_metrics_custom_fields_master from "../../models/rg_metrics_custom_fields_master";

export const addRgMetricsCustomFieldsMaster = async (input: any) => {
  const result = await rg_metrics_custom_fields_master.create(input);
  return result;
};

export const updateRgMetricsCustomFieldsMaster = async (condition: any, obj: any) => {
  const result = await rg_metrics_custom_fields_master.update(obj, {
    where: condition,
  });
  return result;
};

export const getRgMetricsCustomFieldsMasterById = async (condition: any) => {
  const result = await rg_metrics_custom_fields_master.findOne({
    where: condition,
  });
  return result;
};

export const getRgMetricsCustomFieldsMasterList = async (condition: any) => {
  const result = await rg_metrics_custom_fields_master.findAll({
    where: condition,
  });
  return result;
};
