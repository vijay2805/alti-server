import rg_metrics_customer_mapping from "../../models/rg_metrics_customer_mapping";

export const addRgMetricsCustomerMapping = async (input: any) => {
  const result = await rg_metrics_customer_mapping.create(input);
  return result;
};

export const updateRgMetricsCustomerMapping = async (condition: any, obj: any) => {
  const result = await rg_metrics_customer_mapping.update(obj, {
    where: condition,
  });
  return result;
};

export const getRgMetricsCustomerMappingById = async (condition: any) => {
  const result = await rg_metrics_customer_mapping.findOne({
    where: condition,
  });
  return result;
};

export const getRgMetricsCustomerMappingList = async (condition: any) => {
  const result = await rg_metrics_customer_mapping.findAll({
    where: condition,
  });
  return result;
};
