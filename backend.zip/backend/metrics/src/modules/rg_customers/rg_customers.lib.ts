import rg_customers from "../../models/rg_customers";

export const addRgCustomersDetails = async (input: any) => {
  const result = await rg_customers.create(input);
  return result;
};

export const updateRgCustomersDetails = async (condition: any, obj: any) => {
  const result = await rg_customers.update(obj, {
    where: condition,
  });
  return result;
};

export const getRgCustomersDetailsById = async (condition: any) => {
  const result = await rg_customers.findOne({
    where: condition,
  });
  return result;
};

export const getRgCustomersDetailsList = async (condition: any) => {
  const result = await rg_customers.findAll({
    where: condition,
  });
  return result;
};
