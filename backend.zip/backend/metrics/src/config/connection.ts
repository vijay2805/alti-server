import { Sequelize } from "sequelize";
import * as dotenv from "dotenv";
var CryptoJS = require("crypto-js");
dotenv.config();

import * as EnvHandler from "../helpers/environment.handler";

const prod_dl_db = EnvHandler.envPROD_DATALAKE_DB();
const prod_dl_db_up = EnvHandler.envPROD_DATALAKE_DB_UP();

//pwd encrypt and decrypt start
//Encrypt
// const encrypted = CryptoJS.AES.encrypt("rg@9988", 'secret_key@123456').toString();
// console.log("pwd en=",encrypted);
// //Decrypt
// const bytes = CryptoJS.AES.decrypt(encrypted, 'secret_key@123456');
// const decText = bytes.toString(CryptoJS.enc.Utf8);
// console.log("pwd de=", decText);
//pwd encrypt and decrypt end

// let de_prod_dl_up = CryptoJS.AES.decrypt(
//   prod_dl_db_up,
//   "EXSy$rgTC3?XgLL+n_"
// ).toString(CryptoJS.enc.Utf8);

// let encrypt = CryptoJS.AES.encrypt(
//   "postgres:test@1806",
//   "EXSy$rgTC3?XgLL+n_"
// ).toString();
// console.log("++encrypt",de_prod_dl_up);

// let new_prod_dl_conn = `postgres://${de_prod_dl_up}@${prod_dl_db}`;
//  let new_prod_dl_conn = `postgres://postgres:test@1806@172.31.6.248:5432/rg-framework`;

const pg_db = EnvHandler.envPG_DB();
const pg_db_up = EnvHandler.envPG_DB_UP();
// const de_pg_db_up = CryptoJS.AES.decrypt(
//   pg_db_up,
//   "EXSy$rgTC3?XgLL+n_"
// ).toString(CryptoJS.enc.Utf8);

//let new_pg_db_conn = `postgres://${de_pg_db_up}@${pg_db}`;
let new_pg_db_conn = `postgres://postgres:test@1806@dbsrv1:5432/rg-framework`;

export const pg_server_conn = `postgres://postgres:test@1806@dbsrv1:5432`;

const connection = new Sequelize(new_pg_db_conn, {
  dialect: "postgres",
});

export const RgFrameworkDBConnection = new Sequelize(new_pg_db_conn, {
  dialect: "postgres",
});

//API ENGINE  CONNECTION CHANGES START HERE
const api_engine_db = EnvHandler.envAPI_ENGINE_DB();
const api_engine_db_up = EnvHandler.envAPI_ENGINE_DB_UP();

// let de_api_engine_up = CryptoJS.AES.decrypt(
//   api_engine_db_up,
//   "EXSy$rgTC3?XgLL+n_"
// ).toString(CryptoJS.enc.Utf8);
// let api_engine_con = `postgres://${de_api_engine_up}@${api_engine_db}`;
let api_engine_con = `postgres://postgres:test@1806@dbsrv1:5432/api_engine`;
//let api_engine_con = `postgres://postgres:test@1806@10.0.12.123:5432/api_engine`;
export const APIEngineDBConnection = new Sequelize(api_engine_con, {
  dialect: "postgres",
});
// console.log("APIEngineDBConnection=",APIEngineDBConnection);
//API ENGINE  CONNECTION CHANGES END HERE

export default connection;
