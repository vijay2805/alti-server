import { Request, Response } from "express";
import { DataTypes, Op, QueryTypes, Sequelize, fn } from "sequelize";
import { parse } from "mathjs";

import * as ResponseHandler from "../helpers/response.handler";
import Messages from "../common/constants";
import * as rgCustomersDetailsLib from "../modules/rg_customers/rg_customers.lib";
import connection from "../config/connection";

class RgCustomersDetailsController {
  static addRgCustomersDetails = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    const input = req.body;
    try {
      const obj = {
        company_code: input.company_code,
        company_name: input.company_name,
        address_line_1: input.address_line_1,
        address_line_2: input.address_line_2,
        city: input.city,
        region_state_province_county: input.region_state_province_county,
        country: input.country,
        zip_code_pin_code: input.zip_code_pin_code,
        industry: input.industry,
        is_subsidiary: input.is_subsidiary,
        size: input.size,
        market_category: input.market_category,
        territory: input.territory,
        region: input.region,
        parent_company_code: input.parent_company_code,
        acv: input.acv,
        contract_start_date: input.contract_start_date,
        contract_end_date: input.contract_end_date,
        headcount: input.headcount,
        pep: input.pep,
        created_on: fn("NOW"),
        created_by: loggedInUser,
        status: "A",
      };

      let isexist: any = await rgCustomersDetailsLib.getRgCustomersDetailsById({
        company_name: input?.company_name,
      });
      let result: any = {};

      if (isexist) {
        res.locals.message = "Customer already exists";
        ResponseHandler.JSONERROR(req, res);
      } else {
        result = await rgCustomersDetailsLib.addRgCustomersDetails(obj);

        result = JSON.parse(JSON.stringify(result));

        res.locals.data = result;
        res.locals.message = result
          ? Messages.SAVED
          : Messages.SOMETHING_WENT_WRONG;
        ResponseHandler.JSONSUCCESS(req, res);
      }
    } catch (error) {
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static updateRgCustomersDetails = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    const { id } = req.params;
    try {
      const input: any = req.body;

      const obj = {
        company_code: input.company_code,
        company_name: input.company_name,
        address_line_1: input.address_line_1,
        address_line_2: input.address_line_2,
        city: input.city,
        region_state_province_county: input.region_state_province_county,
        country: input.country,
        zip_code_pin_code: input.zip_code_pin_code,
        industry: input.industry,
        is_subsidiary: input.is_subsidiary,
        size: input.size,
        market_category: input.market_category,
        territory: input.territory,
        region: input.region,
        parent_company_code: input.parent_company_code,
        acv: input.acv,
        contract_start_date: input.contract_start_date,
        contract_end_date: input.contract_end_date,
        headcount: input.headcount,
        pep: input.pep,
        modified_on: fn("NOW"),
        modified_by: loggedInUser,
      };

      let isexist: any = await rgCustomersDetailsLib.getRgCustomersDetailsById({
        company_name: input?.company_name,
        customer_id: { [Op.not]: id },
      });

      if (isexist) {
        res.locals.message = "Customers already exists";
        ResponseHandler.JSONERROR(req, res);
      } else {
        const result: any = rgCustomersDetailsLib.updateRgCustomersDetails(
          { customer_id: id },
          obj
        );

        let data: any = rgCustomersDetailsLib.getRgCustomersDetailsById({
          customer_id: id,
        });
        data = JSON.parse(JSON.stringify(data));

        res.locals.data = data;
        res.locals.message = data
          ? Messages.UPDATED
          : Messages.SOMETHING_WENT_WRONG;
        ResponseHandler.JSONSUCCESS(req, res);
      }
    } catch (error) {
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getRgCustomersDetails = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    try {
      let condition: any = {};
      condition = {
        status: { [Op.eq]: "A" },
      };

      const result: any = await rgCustomersDetailsLib.getRgCustomersDetailsList(
        condition
      );
      console.log("data", result);

      const data: any = JSON.parse(JSON.stringify(result));
      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data.sort((a, b) => b.customer_id - a.customer_id);
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error: any) {
      res.locals.error = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getRgCustomersDetailsById = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;

    try {
      const customer_id = parseInt(req.params.id, 10);

      let data: any = await rgCustomersDetailsLib.getRgCustomersDetailsById({
        customer_id: customer_id,
      });

      data = JSON.parse(JSON.stringify(data));

      if (!data) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error: any) {
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };
}

export default RgCustomersDetailsController;
