import { Request, Response } from "express";
import { DataTypes, Op, QueryTypes, Sequelize, fn } from "sequelize";
import { parse } from "mathjs";
import axios from "axios";
import * as ResponseHandler from "../helpers/response.handler";
import Messages from "../common/constants";
import * as rgMetricsDetailsLib from "../modules/rg_metrics_details/rg_metrics_details.lib";
import connection, { pg_server_conn } from "../config/connection";
import * as rgMetricsCustomerMappingLib from "../modules/rg_metrics_customer_mapping/rg_metrics_customer_mapping.lib";

class RgMetricsDetailsController {
  static addRgMetricsDetails = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    const input = req.body;
    try {
      const obj = {
        metric_name: input.metric_name,
        metric_desc: input.metric_desc,
        metric_formula: JSON.stringify(input.metric_formula) || "",
        metric_custom_fields: input.metric_custom_fields,
        metric_fields:
          JSON.stringify(input.metric_fields) || JSON.stringify({}),
        metric_filter_fields:
          JSON.stringify(input.metric_filter_fields) || JSON.stringify([]),
        created_on: fn("NOW"),
        created_by: loggedInUser,
        status: "A",
      };

      let isexist: any = await rgMetricsDetailsLib.getRgMetricsDetailsById({
        metric_name: input?.metric_name,
      });
      let result: any = {};

      if (isexist) {
        // throw new Error("Metrics already exists");
        res.locals.message = "Metrics already exists";
        ResponseHandler.JSONERROR(req, res);
      } else {
        result = await rgMetricsDetailsLib.addRgMetricsDetails(obj);

        result = JSON.parse(JSON.stringify(result));

        /* Dynamic table creation */

        let metric_name = result.metric_name.toLowerCase();
        let metric_formula = result.metric_formula;
        let custom_fields = result.metric_fields;
        let variables = parse(metric_formula)
          .filter((node: any) => node.isSymbolNode)
          .map((node: any) => node.name);
        let metric_custom_fields: any = [];
        metric_custom_fields = custom_fields.map((obj: any) => obj.value);
        let total_columns: any = [...variables, ...metric_custom_fields];
        total_columns = total_columns.map((obj) =>
          convertToValidTableName(obj)
        );
        let table_name = `rg_${metric_name}`;
        table_name = convertToValidTableName(table_name).toLowerCase();

        const modelAttributes = Object.fromEntries([
          ["customer_id", { type: DataTypes.INTEGER }],
          ...total_columns.map((columnName) => [columnName, DataTypes.STRING]), // Modify DataTypes as needed
          ["dynamic_calculation", { type: DataTypes.STRING }],
          ["createdon", { type: DataTypes.DATE, defaultValue: fn("NOW") }],
          ["createdby", { type: DataTypes.INTEGER, defaultValue: 1 }],
        ]);

        const dynamicModel = connection.define(table_name, modelAttributes, {
          schema: "metrics",
          freezeTableName: true,
          timestamps: false,
        });

        // Synchronize the model with the database to create the table
        let ss = await dynamicModel.sync(); // Set force: true to drop existing table if it exists

        const updateResult: any =
          await rgMetricsDetailsLib.updateRgMetricsDetails(
            { metric_id: result.metric_id },
            { metric_table_info: table_name }
          );

        res.locals.data = result;
        res.locals.message = result
          ? Messages.SAVED
          : Messages.SOMETHING_WENT_WRONG;
        ResponseHandler.JSONSUCCESS(req, res);
      }
    } catch (error) {
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static updateRgMetricsDetails = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    const { id } = req.params;
    try {
      const input: any = req.body;

      const obj = {
        metric_name: input.metric_name,
        metric_desc: input.metric_desc,
        metric_formula: JSON.stringify(input.metric_formula) || "",
        metric_filter_fields:
          JSON.stringify(input.metric_filter_fields) || JSON.stringify([]),
        metric_custom_fields: input.metric_custom_fields,
        modified_on: fn("NOW"),
        modified_by: loggedInUser,
      };

      let isexist: any = await rgMetricsDetailsLib.getRgMetricsDetailsById({
        metric_name: input?.metric_name,
        metric_id: { [Op.not]: id },
      });

      let isMetricsMapped: any =
        await rgMetricsCustomerMappingLib.getRgMetricsCustomerMappingById({
          metric_id: id,
        });

      if (isexist) {
        res.locals.message = "Metrics already exists";
        ResponseHandler.JSONERROR(req, res);
      } else if (isMetricsMapped) {
        res.locals.message = "Metrics already in use can not modify";
        ResponseHandler.JSONERROR(req, res);
      } else {
        const result: any = rgMetricsDetailsLib.updateRgMetricsDetails(
          { metric_id: id },
          obj
        );

        let data: any = rgMetricsDetailsLib.getRgMetricsDetailsById({
          metric_id: id,
        });
        data = JSON.parse(JSON.stringify(data));

        res.locals.data = data;
        res.locals.message = data
          ? Messages.UPDATED
          : Messages.SOMETHING_WENT_WRONG;
        ResponseHandler.JSONSUCCESS(req, res);
      }
    } catch (error) {
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getRgMetricsDetails = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    try {
      let condition: any = {};
      condition = {
        status: { [Op.eq]: "A" },
      };

      const result: any = await rgMetricsDetailsLib.getRgMetricsDetailsList(
        condition
      );
      console.log("data", result);

      const data: any = JSON.parse(JSON.stringify(result));
      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data.sort((a, b) => b.metric_id - a.metric_id);
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error: any) {
      res.locals.error = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getRgMetricsDetailsById = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;

    try {
      const metric_id = parseInt(req.params.id, 10);

      let data: any = await rgMetricsDetailsLib.getRgMetricsDetailsById({
        metric_id: metric_id,
      });

      data = JSON.parse(JSON.stringify(data));
      // let metric_name = data.metric_name.toLowerCase();
      // let metric_formula = data.metric_formula;
      // let custom_fields = data.metric_custom_fields.split(",");
      // let variables = parse(metric_formula)
      //   .filter((node: any) => node.isSymbolNode)
      //   .map((node: any) => node.name);
      // let metric_custom_fields: any = await connection.query(
      //   `SELECT * FROM metrics.rg_metrics_custom_fields_master WHERE status='A' and metric_cust_id in (?);`,
      //   {
      //     type: QueryTypes.SELECT,
      //     replacements: [custom_fields],
      //   }
      // );
      // metric_custom_fields = metric_custom_fields.map(
      //   (obj: any) => obj.metric_cust_field_name
      // );
      // let total_columns: any = [...variables, ...metric_custom_fields];
      // let table_name = `cust_${metric_name}`;
      // table_name = convertToValidTableName(table_name).toLowerCase();
      // const dynamicModel = connection.define(
      //   table_name,
      //   Object.fromEntries(
      //     total_columns.map((columnName) => [columnName, DataTypes.STRING])
      //   ),
      //   { schema: "metrics", freezeTableName: true, timestamps: false }
      // );

      // // Synchronize the model with the database to create the table
      // await dynamicModel.sync(); // Set force: true to drop existing table if it exists

      if (!data) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error: any) {
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getRgMetricsCustomFields = async (req: Request, res: Response) => {
    try {
      let condition: any = {};
      condition = {
        status: { [Op.eq]: "A" },
      };
      let result: any = await connection.query(
        `SELECT * FROM metrics.rg_metrics_custom_fields_master WHERE status='A';`,
        {
          type: QueryTypes.SELECT,
        }
      );

      const data: any = JSON.parse(JSON.stringify(result));
      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error: any) {
      res.locals.error = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static DataIntegration = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    const { integration, module, object } = req.body;
    let hubspotbaseurl = "https://api.hubapi.com";
    const hubspotAPIs = {
      account: {
        "api-usage": {
          url: `${hubspotbaseurl}/account-info/v3/api-usage/daily/private-apps`,
          method: "GET", // Example method
        },
        details: {
          url: `${hubspotbaseurl}/account-info/v3/details`,
          method: "GET", // Example method
        },
      },
      cms: {
        url: "https://api.hubspot.com/cms/v3/",
        method: "GET", // Example method
      },
      crm: {
        companies: {
          url: `${hubspotbaseurl}/crm/v3/objects/companies`,
          method: "GET", // Example method
        },
        contacts: {
          url: `${hubspotbaseurl}/crm/v3/objects/contacts`,
          method: "GET", // Example method
        },
        deals: {
          url: `${hubspotbaseurl}/crm/v3/objects/deals`,
          method: "GET", // Example method
        },
        goals: {
          url: `${hubspotbaseurl}/crm/v3/objects/goal_targets`,
          method: "GET",
        },
        calls: {
          url: `${hubspotbaseurl}/crm/v3/objects/calls`,
          method: "GET",
        },
        communications: {
          url: `${hubspotbaseurl}/crm/v3/objects/communications`,
          method: "GET",
          parameters:
            "hs_communication_channel_type,hs_communication_logged_from,hs_communication_body,hs_timestamp",
        },
        meetings: {
          url: `${hubspotbaseurl}/crm/v3/objects/meetings`,
          method: "GET",
          parameters:
            "hs_timestamp,hubspot_owner_id,hs_meeting_title,hs_meeting_body,hs_internal_meeting_notes,hs_meeting_external_url, hs_meeting_location,hs_meeting_start_time,hs_meeting_end_time,hs_meeting_outcome",
        },
        notes: {
          url: `${hubspotbaseurl}/crm/v3/objects/notes`,
          method: "GET",
          parameters:
            "hs_timestamp,hs_note_body,hubspot_owner_id,hs_attachment_ids",
        },
        tasks: {
          url: `${hubspotbaseurl}/crm/v3/objects/tasks`,
          method: "GET",
          parameters:
            "hs_timestamp,hs_task_body,hubspot_owner_id,hs_task_subject,hs_task_status,hs_task_priority,hs_task_type",
        },
        owners: {
          url: `${hubspotbaseurl}/crm/v3/owners`,
          method: "GET",
          // parameters:
          //   "hs_timestamp,hs_task_body,hubspot_owner_id,hs_task_subject,hs_task_status,hs_task_priority,hs_task_type",
        },
      },
    };

    const totangoAPIs = {
      general: {
        tasks: {
          url: "https://api-eu1.totango.com/api/v3/tasks",
          method: "GET", // Example method
        },
        users: {
          url: "https://api-eu1.totango.com/api/v2/users",
          method: "GET",
        },
        auditlog: {
          url: "https://api-eu1.totango.com/api/v2/audit?startDate=2024-04-01&endDate=2024-04-15",
          method: "GET",
        },
        accounts: {
          url: "https://api-eu1.totango.com/api/v1/search/accounts",
          method: "POST",
          query: {
            query: {
              terms: [
                {
                  type: "string",
                  term: "status_group",
                  in_list: ["paying"],
                },
              ],
              count: 1000,
              offset: 0,
              fields: [
                {
                  type: "string",
                  term: "health",
                  field_display_name: "Health rank",
                },
                {
                  type: "health_trend",
                  field_display_name: "Health last change",
                },
                {
                  type: "string_attribute",
                  attribute: "Success Manager",
                  field_display_name: "Success Manager",
                },
              ],
              sort_by: "display_name",
              sort_order: "ASC",
              scope: "all",
            },
          },
        },
        teams: {
          url: "https://api-eu1.totango.com/api/v2/teams",
          method: "GET",
        },
        "objective-templates": {
          url: "https://api-eu1.totango.com/api/v2/objective-templates",
          method: "GET",
        },
      },
    };

    let apiConfig;

    if (integration === "hubspot") {
      if (module === "cms") {
        apiConfig = hubspotAPIs.cms;
      } else if (module === "crm") {
        apiConfig = hubspotAPIs.crm[object];
      } else if (module == "account") {
        apiConfig = hubspotAPIs.account[object];
      }
    } else if (integration === "totango") {
      if (module === "general") {
        apiConfig = totangoAPIs.general[object];
      }
    }

    console.log("apiConfig", apiConfig);

    if (!apiConfig) {
      return res.status(400).send({ error: "Invalid configuration" });
    }
    let accessToken = "pat-na1-11020d30-ff6a-4dc6-98ad-5551908e05de";

    try {
      const response = await axios({
        method: apiConfig.method,
        // url: `${apiConfig.url}?limit=100&properties=${apiConfig.parameters}`,
        url: `${apiConfig.url}`,
        headers: {
          // Authorization: `Bearer ${accessToken}`, // Replace with actual API key
          "app-token":
            "{bcrypt}$2a$10$LvIjrWFSlnnf5K9bJrg/TOHIN.PiGNKOFy3Izruzo2TNCR2TdQ4gm",
        },
        // data: {query: apiConfig.query}
      });

      let data = response.data.results ? response.data.results : response.data;

      // data = data.splice(0, 500);
      const firstItem = Array.isArray(data) ? data[0] : data;
      console.log("firstItem", firstItem);
      let tableName = `rg_${integration}_${module}_${object}_data`;
      tableName = convertToValidTableName(tableName);
      const attributes = {
        id: {
          type: DataTypes.STRING,
          primaryKey: true,
          // autoIncrement: true,
        },
        // ...Object.keys(firstItem.properties).reduce((acc, key) => {
        //   acc[key] = { type: DataTypes.STRING };
        //   return acc;
        // }, {}),
        // createdAt: {
        //   type: DataTypes.DATE,
        // },
        // updatedAt: {
        //   type: DataTypes.DATE,
        // },
        // archived: {
        //   type: DataTypes.BOOLEAN,
        // },
      };

      Object.keys(firstItem).forEach((key) => {
        // if (key == "id") {
        //   attributes[key] = { type: DataTypes.BIGINT, primaryKey: true };
        // } else {
        //   attributes[key] = {
        //     type: DataTypes.BIGINT,
        //     primaryKey: true,
        //     autoIncrement: true,
        //   };
        // }
        if (key == "createdAt" || key == "updatedAt") {
          attributes[key] = { type: DataTypes.DATE };
        } else if (key == "archived") {
          attributes[key] = { type: DataTypes.BOOLEAN };
        } else if (
          key == "teams" ||
          key == "accountData" ||
          key == "followupActions" ||
          key == "healthObject" ||
          key == "health_data" ||
          key == "selected_fields" ||
          key == "associated_users" ||
          key == "assets" ||
          key == "managerDetails" ||
          key == "team_members" ||
          key == "team_role_settings" ||
          key == "successPlays"
        ) {
          attributes[key] = { type: DataTypes.JSONB };
        } else if (key !== "id") {
          if (
            key == "hs_communication_body" ||
            key == "description" ||
            key == "prefJson"
          )
            attributes[key] = { type: DataTypes.TEXT };
          else attributes[key] = { type: DataTypes.STRING };
        }
      });

      if (firstItem?.properties) {
        Object.keys(firstItem.properties).forEach((key) => {
          if (
            key == "hs_communication_body" ||
            key == "hs_meeting_body" ||
            key == "hs_meeting_external_url" ||
            key == "hs_note_body"
          )
            attributes[key] = { type: DataTypes.TEXT };
          else attributes[key] = { type: DataTypes.STRING };
        });
      }

      const model = await createTable(tableName, attributes);

      let records: any = [];

      if (Array.isArray(data)) {
        records = data.map((item) => ({
          id: item.id,
          // ...item.properties,
          ...item,
          createdAt: item.createdAt,
          updatedAt: item.updatedAt,
          archived: item.archived,
        }));
      } else {
        records.push(data);
      }

      console.log("records", records);

      await insertData(model, records);
      res.locals.data = data;
      res.locals.message = data
        ? Messages.FETCHED
        : Messages.SOMETHING_WENT_WRONG;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error) {
      console.log("VJJJ Err", error);
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getCustomerMetricsDetails = async (req: Request, res: Response) => {
    const { customer_id, metric_id } = req.body;
    try {
      let result: any = await connection.query(
        `SELECT * FROM metrics.rg_metrics_details WHERE status='A' AND metric_id = ?;`,
        {
          type: QueryTypes.SELECT,
          replacements: [metric_id],
        }
      );
      const metric_info: any = JSON.parse(JSON.stringify(result));

      console.log("metric_info", metric_info);

      // const customer_arr = customer_id.split(",");

      let table_name = metric_info[0]?.metric_table_info;
      let metric_name = metric_info[0]?.metric_name;

      table_name = `metrics.${table_name}`;

      let query = `SELECT * FROM ${table_name} WHERE customer_id = ?`;

      let metrics_customer_list: any = await connection.query(query, {
        type: QueryTypes.SELECT,
        replacements: [customer_id, metric_id],
      });
      if (metrics_customer_list?.length) {
        let rg_customers: any = await connection.query(
          `SELECT * FROM metrics.rg_customers`,
          {
            type: QueryTypes.SELECT,
            replacements: [metric_id],
          }
        );
        metrics_customer_list = metrics_customer_list.map((row) => {
          let customer_id = row.customer_id;

          let customer_name =
            rg_customers.filter((obj: any) => obj.customer_id == customer_id)[0]
              ?.company_name || "";

          let newRow = {
            customer_id: row.customer_id, // keep the customer_id as the first property
            customer_name: customer_name, // add customer_name as the second property
            metric_name: metric_name, // add metric_name as the third property
            dynamic_calculation: row.dynamic_calculation,
            ...row, // add the remaining properties of the original row object
          };

          delete newRow["customer_id"];
          delete newRow["id"];

          return newRow;
        });
      }
      if (!metrics_customer_list || !metrics_customer_list.length)
        res.locals.message = Messages.NO_DATA;
      res.locals.data = metrics_customer_list;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error: any) {
      res.locals.error = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getMetricsCustomerDataSource = async (req: Request, res: Response) => {
    console.log("reasdfasdf", req.query);
    const { customer_id, metric_id } = req.query;
    try {
      let source_table_info: any = await connection.query(
        `SELECT * FROM metrics.rg_metrics_customer_data_dump_details WHERE metric_id=? AND customer_id = ?;`,
        {
          type: QueryTypes.SELECT,
          replacements: [metric_id, customer_id],
        }
      );

      // console.log("source_table_info", source_table_info);
      let metric_info: any = JSON.parse(JSON.stringify(source_table_info));
      // console.log("metric_info", metric_info);
      // metric_info = metric_info[0];
      // const table_name = metric_info?.data_table_name;
      // const data_source_info = metric_info?.data_source_info;
      let colInfo: any = {};
      const getColumnInfoQuery = `SELECT table_catalog, table_schema, table_name, column_name FROM information_schema.columns WHERE table_name = ? AND table_schema = ? AND column_name NOT IN (SELECT column_name FROM information_schema.key_column_usage WHERE table_name = ? AND table_schema = ?)`;

      if (metric_info?.length > 0) {
        const condata = await Promise.all(
          metric_info.map(async (dataSourceIfo) => {
            const tbl_name = dataSourceIfo?.data_table_name;
            const data_source_info = dataSourceIfo?.data_source_info;
            if (!tbl_name) {
              // let db_name = metric_info.ds_db_info;
              // let schema_name = metric_info?.ds_schema_info;
              // const nconn = `${pg_server_conn}/${db_name}`;
              // const dconnection = new Sequelize(nconn, { dialect: "postgres" });
              // colInfo = await dconnection.query(getColumnInfoQuery, {
              //   replacements: [table_name, schema_name, table_name, schema_name],
              //   type: QueryTypes.SELECT,
              // });
              const multi_source_info = await processDataSources(
                data_source_info
              );
              colInfo = { ...colInfo, ...multi_source_info };

              console.log("multi_source_info", multi_source_info);
              console.log("colInfo", colInfo);
            } else {
              let single_table = await connection.query(getColumnInfoQuery, {
                replacements: [tbl_name, "metrics", tbl_name, "metrics"],
                type: QueryTypes.SELECT,
              });

              console.log("single_table", single_table);

              colInfo[`${tbl_name}`] = single_table;
            }
          })
        );
      } else {
        const table_name = metric_info?.data_table_name;
        colInfo = await connection.query(getColumnInfoQuery, {
          replacements: [table_name, "metrics", table_name, "metrics"],
          type: QueryTypes.SELECT,
        });
      }

      console.log("testinggggg", colInfo);

      // const columns: any = colInfo?.map((row: any) => ({
      //   label: row.column_name,
      //   value: row.column_name,
      // }));

      const data: any = colInfo;
      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error) {
      console.log("Errr", error);
      res.locals.error = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static MetaUpdate = async (req: Request, res: Response) => {
    console.log("reasdfasdf", req.query);
    const input = req.body;
    const {
      ds_db_info,
      ds_schema_info,
      data_table_name,
      table_desc,
      col_info,
    } = input;
    try {
      // let db_name = req.query.ds_db_info;
      // let s_name = req.query.ds_schema_info;
      const nconn = `${pg_server_conn}/${ds_db_info}`;
      const dconnection = new Sequelize(nconn, { dialect: "postgres" });

      let source_table_info: any = await dconnection.query(
        `COMMENT ON TABLE ${ds_schema_info}.${data_table_name} IS '${table_desc}'`,
        {
          type: QueryTypes.RAW,
        }
      );

      const promises = col_info.map(({ column_name, comment }) =>
        dconnection.query(
          `COMMENT ON COLUMN "${ds_schema_info}"."${data_table_name}"."${column_name}" IS :comment;`,
          {
            replacements: { comment },
            type: QueryTypes.RAW,
          }
        )
      );
      await Promise.all(promises);

      res.locals.message = "Meta data updated";
      res.locals.data = [];
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error) {
      console.log("Errr", error);
      res.locals.error = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };
}

export default RgMetricsDetailsController;

const createTable = async (tableName, attributes) => {
  const model = connection.define(tableName, attributes, {
    tableName: tableName,
    timestamps: false,
    schema: "externaldata",
  });

  await model.sync();
  return model;
};

const insertData = async (model, data) => {
  await model.bulkCreate(data);
};

function convertToValidTableName(inputString) {
  // Remove characters that are not letters, digits, or underscores
  const reservedKeywords = [
    "ALL",
    "ANALYSE",
    "ANALYZE",
    "AND",
    "ANY",
    "ARRAY",
    "AS",
    "ASC",
    "ASYMMETRIC",
    "AUTHORIZATION",
    "BINARY",
    "BOTH",
    "CASE",
    "CAST",
    "CHECK",
    "COLLATE",
    "COLUMN",
    "CONCURRENTLY",
    "CONSTRAINT",
    "CREATE",
    "CROSS",
    "CURRENT_CATALOG",
    "CURRENT_DATE",
    "CURRENT_ROLE",
    "CURRENT_SCHEMA",
    "CURRENT_TIME",
    "CURRENT_TIMESTAMP",
    "CURRENT_USER",
    "DEFAULT",
    "DEFERRABLE",
    "DESC",
    "DISTINCT",
    "DO",
    "ELSE",
    "END",
    "EXCEPT",
    "FALSE",
    "FETCH",
    "FOR",
    "FOREIGN",
    "FREEZE",
    "FROM",
    "FULL",
    "GRANT",
    "GROUP",
    "HAVING",
    "ILIKE",
    "IN",
    "INITIALLY",
    "INNER",
    "INTERSECT",
    "INTO",
    "IS",
    "ISNULL",
    "JOIN",
    "LATERAL",
    "LEADING",
    "LEFT",
    "LIKE",
    "LIMIT",
    "LOCALTIME",
    "LOCALTIMESTAMP",
    "NATURAL",
    "NOT",
    "NULL",
    "OFFSET",
    "ON",
    "ONLY",
    "OR",
    "ORDER",
    "OUTER",
    "OVERLAPS",
    "PLACING",
    "PRIMARY",
    "REFERENCES",
    "RETURNING",
    "RIGHT",
    "SELECT",
    "SESSION_USER",
    "SIMILAR",
    "SOME",
    "SYMMETRIC",
    "TABLE",
    "THEN",
    "TO",
    "TRAILING",
    "TRUE",
    "UNION",
    "UNIQUE",
    "USER",
    "USING",
    "VARIADIC",
    "VERBOSE",
    "WHEN",
    "WHERE",
    "WINDOW",
    "WITH",
  ];
  let tableName = inputString.toLowerCase();

  let sanitizedString = tableName.replace(/[^a-zA-Z0-9_]/g, "_");

  // Ensure that the resulting string begins with a letter or an underscore
  if (!/^[a-z_]/.test(sanitizedString)) {
    sanitizedString = "_" + sanitizedString;
  }

  // Trim the string to a maximum of 63 characters
  sanitizedString = sanitizedString.slice(0, 63);

  // Check and avoid reserved keywords
  if (reservedKeywords.includes(sanitizedString.toUpperCase())) {
    sanitizedString = sanitizedString + "_tbl";
  }

  return sanitizedString;
}

// Function to get columns for a given table
async function getTableColumns(sequelize, schema, table) {
  const query = `SELECT table_catalog, table_schema, table_name, column_name FROM information_schema.columns WHERE table_name = ? AND table_schema = ?`;
  const results = await sequelize.query(query, {
    replacements: [table, schema, table, schema],
    type: sequelize.QueryTypes.SELECT,
  });

  // console.log("results", results);
  // return results.map((row) => row.column_name);
  return results;
}

// Function to process all data sources and get columns
async function processDataSources(dataSources) {
  const results = {};

  for (const ds of dataSources) {
    const nconn = `${pg_server_conn}/${ds.ds_db_info}`;
    const dconnection: any = new Sequelize(nconn, { dialect: "postgres" });
    const table = ds.data_table_name;
    const columns = await getTableColumns(
      dconnection,
      ds.ds_schema_info,
      table
    );
    results[`${table}`] = columns;
    // console.log("FINResult", results);
    /* Multiple table logic */
    // const tables = ds.data_table_name.split(",");

    // for (const table of tables) {
    //   const columns = await getTableColumns(
    //     dconnection,
    //     ds.ds_schema_info,
    //     table
    //   );
    //   results[table] = columns;
    // }

    await dconnection.close();
  }

  // console.log("Result", results);

  return results;
}
