import { Request, Response } from "express";
import { DataTypes, Op, QueryTypes, Sequelize, fn } from "sequelize";
import { evaluate, parse } from "mathjs";
const _ = require("lodash");

import * as ResponseHandler from "../helpers/response.handler";
import Messages from "../common/constants";
import * as rgMetricsCustomerMappingLib from "../modules/rg_metrics_customer_mapping/rg_metrics_customer_mapping.lib";
import * as rgMetricsDetailsLib from "../modules/rg_metrics_details/rg_metrics_details.lib";
import connection, { pg_server_conn } from "../config/connection";

class RgMetricsCustomerMappingController {
  static addRgMetricsCustomerMapping = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    const input = req.body;
    const {
      metric_id,
      customer_id,
      metric_col_mapping,
      metric_formula,
      is_custom_formula_required,
    } = input;
    try {
      const obj = {
        metric_id: input.metric_id,
        customer_id: input.customer_id,
        metric_desc: input.metric_desc,
        metric_formula:
          JSON.stringify(input.metric_formula) || JSON.stringify({}),
        metric_formula_type: input.metric_formula_type,
        is_custom_formula_required: input.is_custom_formula_required,
        custom_metric_formula:
          JSON.stringify(input.custom_metric_formula) || JSON.stringify({}),
        metric_filter_fields:
          JSON.stringify(input.metric_filter_fields) || JSON.stringify([]),
        metric_formula_column_mapping:
          JSON.stringify(input.metric_formula_column_mapping) ||
          JSON.stringify({}),
        metric_custom_column_mapping:
          JSON.stringify(input.metric_custom_column_mapping) ||
          JSON.stringify({}),
        data_source: input.data_source,
        api_info: JSON.stringify(input.api_info) || JSON.stringify({}),

        created_on: fn("NOW"),
        created_by: loggedInUser,
        status: "A",
      };

      // let result: any =
      //   await rgMetricsCustomerMappingLib.addRgMetricsCustomerMapping(obj);

      // result = JSON.parse(JSON.stringify(result));

      // let metric_info: any = await connection.query(
      //   `SELECT * FROM metrics.rg_metrics_details WHERE status='A' AND metric_id = ?;`,
      //   {
      //     type: QueryTypes.SELECT,
      //     replacements: [input.metric_id],
      //   }
      // );
      // const metric_info: any = JSON.parse(JSON.stringify(metric_info));
      /* EXCEL DATA INSERTION LOGIC STARTS */

      // let excel_data = input.excel_data;
      let metric_table_name = input.metric_table_info;

      let source_table_info: any = await connection.query(
        `SELECT * FROM metrics.rg_metrics_customer_data_dump_details WHERE metric_id=? AND customer_id = ?;`,
        {
          type: QueryTypes.SELECT,
          replacements: [metric_id, customer_id],
        }
      );
      let metric_info: any = JSON.parse(JSON.stringify(source_table_info));
      // metric_info = metric_info[0];
      // const souce_table_name = metric_info?.data_table_name;
      // const dataSourceInfo = metric_info?.data_source_info;
      const sourceDestinationMapping = metric_col_mapping;
      let source_data: any = [];
      if (
        metric_info?.length > 0 ||
        (metric_info.length == 1 && !metric_info[0]?.data_table_name)
      ) {
        let data_source_info = [];

        metric_info.map(async (dataSourceIfo) => {
          const tbl_name = dataSourceIfo?.data_table_name;

          if (!tbl_name) {
            const sdata_source_info = dataSourceIfo?.data_source_info;
            data_source_info = data_source_info.length
              ? [...data_source_info, ...sdata_source_info]
              : sdata_source_info;
          } else {
            let sobj = {
              ds_db_info: "rg-framework",
              ds_schema_info: "metrics",
              data_table_name: tbl_name,
            };
            data_source_info.push(sobj);
          }
        });

        source_data = await fetchDataAndJoin(
          data_source_info,
          sourceDestinationMapping
        );

        const destRows = source_data.map((row) => {
          let destRow = {
            ...row,
          };

          destRow["customer_id"] = customer_id;
          return destRow;
        });

        // Insert transformed data into destination table
        const fields = Object.keys(destRows[0]);
        const values = destRows.map((row) => Object.values(row));
        const valuePlaceholders = destRows
          .map((_, rowIndex) => {
            const rowPlaceholders = fields
              .map(
                (_, colIndex) => `$${rowIndex * fields.length + colIndex + 1}`
              )
              .join(", ");
            return `(${rowPlaceholders})`;
          })
          .join(", ");
        const insertQuery = `
          INSERT INTO metrics.${metric_table_name} (${fields.join(", ")})
          VALUES ${valuePlaceholders}
        `;
        const insertValues = destRows.flatMap((row) => Object.values(row));

        // Flatten values for replacements array
        const replacements = values.flat();
        await connection.query(insertQuery, {
          bind: insertValues,
          type: QueryTypes.INSERT,
        });

        let metric_customer_mapping_info_query: any = `UPDATE metrics.rg_metrics_customer_data_dump_details SET metric_raw_mapping = ? , metric_filter_fields = ?  metric_id=? AND customer_id = ?`;

        await connection.query(metric_customer_mapping_info_query, {
          replacements: [
            JSON.stringify(metric_col_mapping),
            JSON.stringify(obj.metric_filter_fields),
            metric_id,
            customer_id
          ],
          type: QueryTypes.UPDATE,
        });

        if (is_custom_formula_required) {
          let metric_custom_formula_query: any = `INSERT INTO metrics.rg_metrics_custom_formula_details (metric_id, customer_id, custom_metric_formula) VALUES (?, ?, ?)`;

          await connection.query(metric_custom_formula_query, {
            replacements: [
              obj.metric_id,
              obj.customer_id,
              obj.custom_metric_formula,
            ],
            type: QueryTypes.INSERT,
          });
        }

        res.locals.data = [];
        res.locals.message = 1 ? Messages.SAVED : Messages.SOMETHING_WENT_WRONG;
        ResponseHandler.JSONSUCCESS(req, res);
      } else {
        const souce_table_name = metric_info[0]?.data_table_name;
        source_data = await connection.query(
          `SELECT * FROM metrics.${souce_table_name};`,
          {
            type: QueryTypes.SELECT,
          }
        );

        source_data = JSON.parse(JSON.stringify(source_data));
        console.log("source_data", source_data);
        let variables = parse(metric_formula)
          .filter((node: any) => node.isSymbolNode)
          .map((node: any) => node.name);
        const variableMapping = {};
        variables.forEach((variable) => {
          variableMapping[variable] = convertToValidTableName(variable);
        });
        // console.log("destRow", destRow)
        let sanitizedFormula = metric_formula;

        for (const [original, lowerCase] of Object.entries(variableMapping)) {
          const regex = new RegExp(`\\b${original}\\b`, "g");
          sanitizedFormula = sanitizedFormula.replace(regex, lowerCase);
        }

        const destRows = source_data.map((row) => {
          let destRow = {};

          // Map fields
          for (let mapping of metric_col_mapping) {
            destRow[mapping.desitination_field] = row[mapping.source_field];
          }
          let sanitizedDestRow = replaceNulls(destRow);
          sanitizedDestRow = Object.fromEntries(
            Object.entries(sanitizedDestRow).map(([key, value]) => [
              key,
              Number(value),
            ])
          );

          console.log("destRow", destRow);
          let cal_val = evaluate(sanitizedFormula, sanitizedDestRow);
          destRow["customer_id"] = customer_id;
          destRow["dynamic_calculation"] = cal_val;
          return destRow;
        });

        // Insert transformed data into destination table
        const fields = Object.keys(destRows[0]);
        const values = destRows.map((row) => Object.values(row));
        const valuePlaceholders = destRows
          .map((_, rowIndex) => {
            const rowPlaceholders = fields
              .map(
                (_, colIndex) => `$${rowIndex * fields.length + colIndex + 1}`
              )
              .join(", ");
            return `(${rowPlaceholders})`;
          })
          .join(", ");
        const insertQuery = `
          INSERT INTO metrics.${metric_table_name} (${fields.join(", ")})
          VALUES ${valuePlaceholders}
        `;
        const insertValues = destRows.flatMap((row) => Object.values(row));

        // Flatten values for replacements array
        const replacements = values.flat();
        await connection.query(insertQuery, {
          bind: insertValues,
          type: QueryTypes.INSERT,
        });
        if (is_custom_formula_required) {
          let metric_custom_formula_query: any = `INSERT INTO metrics.rg_metrics_custom_formula_details (metric_id, customer_id, custom_metric_formula) VALUES (?, ?, ?)`;

          await connection.query(metric_custom_formula_query, {
            replacements: [
              obj.metric_id,
              obj.customer_id,
              obj.custom_metric_formula,
            ],
            type: QueryTypes.INSERT,
          });
        }

        let metric_customer_mapping_info_query: any = `UPDATE metrics.rg_metrics_customer_data_dump_details SET metric_raw_mapping = ? , metric_filter_fields = ? WHERE id metric_id=? AND customer_id = ?`;

        await connection.query(metric_customer_mapping_info_query, {
          replacements: [
            JSON.stringify(metric_col_mapping),
            JSON.stringify(obj.metric_filter_fields),
            metric_id,
            customer_id
          ],
          type: QueryTypes.UPDATE,
        });

        // let metric_formula_column_mapping = result.metric_formula_column_mapping;
        // let metric_custom_column_mapping = result.metric_custom_column_mapping;
        // let metric_formula = result.metric_formula;
        // let variables = parse(metric_formula)
        //   .filter((node: any) => node.isSymbolNode)
        //   .map((node: any) => node.name);
        // const variableMapping = {};
        // variables.forEach((variable) => {
        //   variableMapping[variable] = convertToValidTableName(variable);
        // });
        // let sanitizedFormula = metric_formula;

        // for (const [original, lowerCase] of Object.entries(variableMapping)) {
        //   const regex = new RegExp(`\\b${original}\\b`, "g");
        //   sanitizedFormula = sanitizedFormula.replace(regex, lowerCase);
        // }

        // let combinedConfig = [
        //   ...metric_formula_column_mapping,
        //   ...metric_custom_column_mapping,
        // ];

        // let mappedDataArray = excel_data.map((row) => ({
        //   ...mapDataToColumns(row, combinedConfig),
        //   customer_id: input.customer_id,
        // }));

        // mappedDataArray = mappedDataArray.map((data) => {
        //   const filteredData = {};

        //   for (let key in data) {
        //     // if (data[key] !== undefined) {
        //     filteredData[key] = data[key] ? data[key] : 0;
        //     // }
        //   }
        //   let cal_val = evaluate(sanitizedFormula, data);
        //   filteredData["dynamic_calculation"] = cal_val;

        //   return filteredData;
        // });
        // const query = constructBulkInsertQueryWithNamedParams(
        //   `metrics.${table_name}`,
        //   mappedDataArray
        // );

        // if (query) {
        //   const res: any = await connection.query(query.text, {
        //     replacements: query.replacements,
        //     type: QueryTypes.INSERT,
        //   });
        // } else {
        //   console.log("No data to insert.");
        // }

        /* EXCEL DATA INSERTION LOGIC ENDS */

        res.locals.data = [];
        res.locals.message = 1 ? Messages.SAVED : Messages.SOMETHING_WENT_WRONG;
        ResponseHandler.JSONSUCCESS(req, res);
      }
    } catch (error) {
      console.log("VJ Error", error);
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static updateRgMetricsCustomerMapping = async (
    req: Request,
    res: Response
  ) => {
    const { loggedInUser } = req.query;
    const { id } = req.params;
    try {
      const input: any = req.body;

      const obj = {
        customer_id: input.customer_id,
        metric_name: input.metric_name,
        metric_formula:
          JSON.stringify(input.metric_formula) || JSON.stringify({}),
        metric_formula_type: input.metric_formula_type,
        metric_formula_column_mapping:
          JSON.stringify(input.metric_formula_column_mapping) ||
          JSON.stringify({}),
        metric_custom_column_mapping:
          JSON.stringify(input.metric_custom_column_mapping) ||
          JSON.stringify({}),
        data_source: input.data_source,
        api_info: JSON.stringify(input.api_info) || JSON.stringify({}),

        modified_on: fn("NOW"),
        modified_by: loggedInUser,
      };

      const result: any =
        await rgMetricsCustomerMappingLib.updateRgMetricsCustomerMapping(
          { metric_customer_map_id: id },
          obj
        );

      console.log("result", result);

      let data: any =
        await rgMetricsCustomerMappingLib.getRgMetricsCustomerMappingById({
          metric_customer_map_id: id,
        });
      data = JSON.parse(JSON.stringify(data));
      console.log("VJ data", data);
      /* EXCEL DATA INSERTION LOGIC STARTS */

      let excel_data = input.excel_data;
      let table_name = input.metric_table_info;
      let metric_formula_column_mapping = data.metric_formula_column_mapping;
      let metric_custom_column_mapping = data.metric_custom_column_mapping;
      let metric_formula = data.metric_formula;
      let variables = parse(metric_formula)
        .filter((node: any) => node.isSymbolNode)
        .map((node: any) => node.name);
      const variableMapping = {};
      variables.forEach((variable) => {
        variableMapping[variable] = convertToValidTableName(variable);
      });
      let sanitizedFormula = metric_formula;

      for (const [original, lowerCase] of Object.entries(variableMapping)) {
        const regex = new RegExp(`\\b${original}\\b`, "g");
        sanitizedFormula = sanitizedFormula.replace(regex, lowerCase);
      }
      let combinedConfig = [
        ...metric_formula_column_mapping,
        ...metric_custom_column_mapping,
      ];

      let mappedDataArray = excel_data.map((row) => ({
        ...mapDataToColumns(row, combinedConfig),
        customer_id: input.customer_id,
      }));

      console.log("mappedDataArray", mappedDataArray);

      mappedDataArray = mappedDataArray.map((data) => {
        const filteredData = {};
        for (let key in data) {
          // if (data[key] !== undefined) {
          filteredData[key] = data[key] ? data[key] : 0;
          // }
        }
        let cal_val = evaluate(sanitizedFormula, data);
        filteredData["dynamic_calculation"] = cal_val;
        return filteredData;
      });

      let current_timestamp = new Date().toLocaleString("en-US", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
      });

      let time = current_timestamp.replace(/[/,:.]/g, "_");

      let timestring = time.replace(/[ ]/g, "");
      let new_bakup_table = `${table_name}${timestring}`;
      let alterQuery = `ALTER TABLE metrics.${table_name} RENAME TO ${new_bakup_table}`;
      const sourceTableName = `${new_bakup_table}`;
      const newTableName = `metrics.${table_name}`;
      const transaction = await connection.transaction();

      const getColumnInfoQuery = `SELECT column_name, data_type FROM information_schema.columns WHERE table_name = ? AND table_schema = 'metrics' AND column_name NOT IN (SELECT column_name FROM information_schema.key_column_usage WHERE table_name = ? AND table_schema = 'metrics')`;

      const createTableQuery = `CREATE TABLE ${newTableName} (id SERIAL PRIMARY KEY, ?);`;

      let alerOldTable = await connection.query(alterQuery, {
        type: QueryTypes.UPDATE,
        transaction,
      });

      let createNewTable = await ExecuteCreateTable(
        getColumnInfoQuery,
        sourceTableName,
        createTableQuery,
        transaction
      );
      const query = constructBulkInsertQueryWithNamedParams(
        `${newTableName}`,
        mappedDataArray
      );

      if (query) {
        const res: any = await connection.query(query.text, {
          replacements: query.replacements,
          type: QueryTypes.INSERT,
          transaction,
        });
      } else {
        console.log("No data to insert.");
      }
      await transaction.commit();

      /* EXCEL DATA INSERTION LOGIC ENDS */

      res.locals.data = data;
      res.locals.message = data
        ? Messages.UPDATED
        : Messages.SOMETHING_WENT_WRONG;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error) {
      console.log("errr", error);
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getRgMetricsCustomerMapping = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    try {
      let condition: any = {};
      condition = {
        status: { [Op.eq]: "A" },
      };

      const result: any =
        await rgMetricsCustomerMappingLib.getRgMetricsCustomerMappingList(
          condition
        );
      console.log("data", result);

      let data: any = JSON.parse(JSON.stringify(result));

      let metrics_list: any = await rgMetricsDetailsLib.getRgMetricsDetailsList(
        {
          status: { [Op.eq]: "A" },
        }
      );
      console.log("data", result);

      metrics_list = JSON.parse(JSON.stringify(metrics_list));

      if (data.length) {
        data = data.map((obj) => {
          let metric_id = obj.metric_id;

          obj["metric_name"] =
            metrics_list.find((obj: any) => obj.metric_id == metric_id)
              ?.metric_name || "";

          return obj;
        });
      }

      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data.sort(
        (a, b) => b.metric_customer_map_id - a.metric_customer_map_id
      );
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error: any) {
      res.locals.error = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getRgMetricsCustomerMappingById = async (
    req: Request,
    res: Response
  ) => {
    const { loggedInUser } = req.query;

    try {
      const metric_customer_map_id = parseInt(req.params.id, 10);

      let data: any =
        await rgMetricsCustomerMappingLib.getRgMetricsCustomerMappingById({
          metric_customer_map_id: metric_customer_map_id,
        });

      data = JSON.parse(JSON.stringify(data));
      console.log("VJJJ", data);
      if (!data) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error: any) {
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };
}

export default RgMetricsCustomerMappingController;

function mapDataToColumns(data, config) {
  let mappedData = {};
  config.forEach((cfg) => {
    if (data[cfg.source_field] !== undefined) {
      mappedData[cfg.desitination_field] = data[cfg.source_field];
    } else {
      mappedData[cfg.desitination_field] = null;
    }
  });
  return mappedData;
}

// Function to construct insert query
function constructInsertQuery(table, data) {
  const columns = Object.keys(data).join(", ");
  const values = Object.values(data)
    .map((val, idx) => `$${idx + 1}`)
    .join(", ");

  console.log("values", values);
  const text = `INSERT INTO ${table} (${columns}) VALUES (${values}) RETURNING id`;
  const valuesArray = Object.values(data);

  return { text, values: valuesArray };
}

function constructBulkInsertQuery(table, dataArray) {
  if (dataArray.length === 0) {
    return null;
  }

  const columns = Object.keys(dataArray[0]);
  const columnNames = columns.join(", ");

  let valueIndex = 1;
  const values = dataArray
    .map((data) => {
      const placeholders = Object.values(data)
        .map(() => `$${valueIndex++}`)
        .join(", ");
      return `(${placeholders})`;
    })
    .join(", ");

  const text = `INSERT INTO ${table} (${columnNames}) VALUES ${values} RETURNING id`;
  const valuesArray = dataArray.flatMap(Object.values);

  return { text, values: valuesArray };
}

// Function to construct bulk insert query with named parameters
function constructBulkInsertQueryWithNamedParams(table, dataArray) {
  if (dataArray.length === 0) {
    return null;
  }

  const columns = Object.keys(dataArray[0]);
  const columnNames = columns.join(", ");

  let valueIndex = 1;
  const replacements = {};
  const values = dataArray
    .map((data) => {
      const placeholders = Object.entries(data)
        .map(([key, value]) => {
          const placeholder = `:value${valueIndex}`;
          replacements[`value${valueIndex}`] = value;
          valueIndex++;
          return placeholder;
        })
        .join(", ");
      return `(${placeholders})`;
    })
    .join(", ");

  const text = `INSERT INTO ${table} (${columnNames}) VALUES ${values} RETURNING id`;

  return { text, replacements };
}

const ExecuteCreateTable = async (
  colInfoQuery: any,
  sourceTableName: any,
  createTableQuery: any,
  transaction: any
) => {
  let colInfo: any = await connection.query(colInfoQuery, {
    replacements: [sourceTableName, sourceTableName],
    type: QueryTypes.SELECT,
    transaction,
  });

  const columns: any = colInfo
    ?.map((row: any) => `${row.column_name} ${row.data_type}`)
    .join(", ");
  console.log("columns", columns);
  let newTable: any = await connection.query(
    createTableQuery.replace("?", columns),
    { transaction }
  );

  return newTable;
};

function convertToValidTableName(inputString) {
  // Remove characters that are not letters, digits, or underscores
  const reservedKeywords = [
    "ALL",
    "ANALYSE",
    "ANALYZE",
    "AND",
    "ANY",
    "ARRAY",
    "AS",
    "ASC",
    "ASYMMETRIC",
    "AUTHORIZATION",
    "BINARY",
    "BOTH",
    "CASE",
    "CAST",
    "CHECK",
    "COLLATE",
    "COLUMN",
    "CONCURRENTLY",
    "CONSTRAINT",
    "CREATE",
    "CROSS",
    "CURRENT_CATALOG",
    "CURRENT_DATE",
    "CURRENT_ROLE",
    "CURRENT_SCHEMA",
    "CURRENT_TIME",
    "CURRENT_TIMESTAMP",
    "CURRENT_USER",
    "DEFAULT",
    "DEFERRABLE",
    "DESC",
    "DISTINCT",
    "DO",
    "ELSE",
    "END",
    "EXCEPT",
    "FALSE",
    "FETCH",
    "FOR",
    "FOREIGN",
    "FREEZE",
    "FROM",
    "FULL",
    "GRANT",
    "GROUP",
    "HAVING",
    "ILIKE",
    "IN",
    "INITIALLY",
    "INNER",
    "INTERSECT",
    "INTO",
    "IS",
    "ISNULL",
    "JOIN",
    "LATERAL",
    "LEADING",
    "LEFT",
    "LIKE",
    "LIMIT",
    "LOCALTIME",
    "LOCALTIMESTAMP",
    "NATURAL",
    "NOT",
    "NULL",
    "OFFSET",
    "ON",
    "ONLY",
    "OR",
    "ORDER",
    "OUTER",
    "OVERLAPS",
    "PLACING",
    "PRIMARY",
    "REFERENCES",
    "RETURNING",
    "RIGHT",
    "SELECT",
    "SESSION_USER",
    "SIMILAR",
    "SOME",
    "SYMMETRIC",
    "TABLE",
    "THEN",
    "TO",
    "TRAILING",
    "TRUE",
    "UNION",
    "UNIQUE",
    "USER",
    "USING",
    "VARIADIC",
    "VERBOSE",
    "WHEN",
    "WHERE",
    "WINDOW",
    "WITH",
  ];
  let tableName = inputString.toLowerCase();

  let sanitizedString = tableName.replace(/[^a-zA-Z0-9_]/g, "_");

  // Ensure that the resulting string begins with a letter or an underscore
  if (!/^[a-z_]/.test(sanitizedString)) {
    sanitizedString = "_" + sanitizedString;
  }

  // Trim the string to a maximum of 63 characters
  sanitizedString = sanitizedString.slice(0, 63);

  // Check and avoid reserved keywords
  if (reservedKeywords.includes(sanitizedString.toUpperCase())) {
    sanitizedString = sanitizedString + "_tbl";
  }

  return sanitizedString;
}

function replaceNulls(obj, defaultValue = 0) {
  return Object.fromEntries(
    Object.entries(obj).map(([key, value]) => [
      key,
      value === null ? defaultValue : value,
    ])
  );
}

// Extract and transform data dynamically
const extractAndTransformData = async (
  dataSourceInfo: any[],
  sourceDestinationMapping: any[]
): Promise<any[]> => {
  const transformedData: any[] = [];

  // Iterate over each table in the fetched data source info
  for (const info of dataSourceInfo) {
    const tables = info.data_table_name.split(",");
    for (const table of tables) {
      const mappings = sourceDestinationMapping.filter((mapping) =>
        mapping.source_field.includes(table)
      );
      console.log("mappings", mappings);
      // Construct SQL query dynamically based on fetched mappings
      const columns = mappings.map((m) => m.source_field).join(", ");
      const query = `SELECT ${columns} FROM ${info.ds_schema_info}.${table} LIMIT 100`; // You can remove the LIMIT clause in production

      const nconn = `${pg_server_conn}/${info.ds_db_info}`;
      const dconnection = new Sequelize(nconn, { dialect: "postgres" });

      let results: any = [];
      if (mappings.length)
        results = await dconnection.query(query, { type: QueryTypes.SELECT });

      console.log("VJ Results", results);

      results.forEach((result: any) => {
        const transformedRecord: any = {};

        mappings.forEach((mapping) => {
          transformedRecord[mapping.destination_field] =
            result[mapping.source_field];
        });

        transformedData.push(transformedRecord);
      });
    }
  }

  return transformedData;
};

// Insert data into the destination table using raw SQL
const insertDataIntoDestinationTable = async (
  data: any[],
  metric_table_name: any
): Promise<void> => {
  console.log("data", data);
  const insertQueries = data.map((record) => {
    const fields = Object.keys(record).join(", ");
    const values = Object.values(record)
      .map((value) => `'${value}'`)
      .join(", ");

    return `INSERT INTO metrics.${metric_table_name} (${fields}) VALUES (${values})`;
  });

  for (const query of insertQueries) {
    await connection.query(query);
  }
};

const fetchDataAndJoin = async (config, sourceDestinationMapping) => {
  const connections = {};
  // console.log("config", config);
  try {
    // Create connections for each unique database in the config
    for (const item of config) {
      if (!connections[item.ds_db_info]) {
        const nconn = `${pg_server_conn}/${item.ds_db_info}`;
        const dconnection = new Sequelize(nconn, { dialect: "postgres" });
        connections[item.ds_db_info] = dconnection;
      }
    }
    // console.log("connections", connections);
    // Fetch data from each table
    const dataFetchPromises = config.map(async (item) => {
      const connection = connections[item.ds_db_info];
      const query = `SELECT * FROM ${item.ds_schema_info}.${item.data_table_name}`;
      const [data] = await connection.query(query);

      // console.log("data", data);

      return data.map((row) => {
        let transformedObj = {};

        // Iterate over each mapping in config
        sourceDestinationMapping.forEach((mapping) => {
          // Extract source and destination field names from mapping

          let sourceField = mapping.source_field;

          let destinationField = mapping.desitination_field;

          // console.log("sourceField", sourceField)
          // console.log("destinationField", destinationField)

          const [db, table, field] = sourceField.split(".");

          // Check if sourceField exists in obj
          if (
            row.hasOwnProperty(field) &&
            item.ds_db_info === db &&
            item.data_table_name === table
          ) {
            // Assign value to destinationField in transformedObj
            transformedObj[destinationField] = row[field];
            transformedObj["mapping_column"] = item["mapping_column"];
            if (item["mapping_column"])
              transformedObj[item["mapping_column"]] =
                row[item["mapping_column"]];
          }
        });
        return transformedObj;
      });
      // return data.map((row) => ({
      //   ...row,
      //   mapping_column: item.mapping_column,
      //   ds_db_info: item.ds_db_info,
      //   ds_schema_info: item.ds_schema_info,
      //   data_table_name: item.data_table_name,
      // }));
      // return {
      //   mappingColumn: item.mapping_column,
      //   data: data.map((row) => ({
      //     ...row,
      //     ds_db_info: item.ds_db_info,
      //     ds_schema_info: item.ds_schema_info,
      //     data_table_name: item.data_table_name,
      //   })),
      // };
    });

    const raw_results = await Promise.all(dataFetchPromises);

    // console.log("raw_results", raw_results)

    let result = await joinMultipleArrays(
      sourceDestinationMapping,
      ...raw_results
    );

    console.log("ereeesss", result);
    return result;
  } catch (error) {
    console.error("Error fetching or joining data:", error);
    throw error;
  } finally {
    // Close all connections
    for (const connection of Object.values(connections)) {
      // await connection.close();
    }
  }
};

const joinData = (data1, data2, key) => {
  const map = new Map();
  data1.forEach((item) => {
    map.set(item[key], item);
  });

  data2.forEach((item) => {
    if (map.has(item[key])) {
      Object.assign(map.get(item[key]), item);
    } else {
      map.set(item[key], item);
    }
  });

  return Array.from(map.values());
};

function joinArrays(arrays, config) {
  // Create a map for quick lookup based on mapping_column for each array
  const arrayMaps = arrays.map(
    (arr) => new Map(arr.map((item) => [item.mapping_column, item]))
  );

  // Get unique mapping_column values from all arrays
  const mapping_columns = new Set(
    arrays.flatMap((arr) => arr.map((item) => item.mapping_column))
  );

  console.log("arrayMaps", arrayMaps);

  return Array.from(mapping_columns).map((mapping_column) => {
    let result = {};

    config.forEach(({ source_field, destination_field }) => {
      // console.log("vijaaasdf", source_field);
      const [db, table, field] = source_field.split(".");
      console.log("db, table, field", db, table, field);
      for (let arrayMap of arrayMaps) {
        const item = arrayMap.get(mapping_column);
        if (
          item &&
          item.ds_db_info === db &&
          item.data_table_name === table &&
          item[field] !== undefined
        ) {
          result[destination_field] = item[field];
          break; // Stop once we've found the match in one of the arrays
        }
      }
    });

    return result;
  });
}

async function joinMultipleArrays(sourceDestinationMapping, ...arrays) {
  if (arrays.length === 0) {
    return [];
  }

  console.log("arrays", arrays);

  if (arrays.length === 0) {
    return [];
  }

  if (arrays.length === 1) {
    // Return the single array with all keys intact
    return arrays[0].map((item) => _.omit(item, "mapping_column"));
  }

  // Extract all unique keys from the first array
  const firstArray = arrays[0];
  const firstMap = _.groupBy(firstArray, (item) => item[item.mapping_column]);

  // Start with the first array as the base
  let result = [];

  // Iterate through the rest of the arrays and merge them with the result
  for (let i = 1; i < arrays.length; i++) {
    const currentArray = arrays[i];
    const currentMap = _.groupBy(
      currentArray,
      (item) => item[item.mapping_column]
    );

    result = [];

    // Perform a LEFT JOIN-like merge
    _.forEach(firstMap, (firstItems, key) => {
      const secondItems = currentMap[key] || [{}];
      firstItems.forEach((firstItem) => {
        secondItems.forEach((secondItem) => {
          const mergedItem = { ...firstItem, ...secondItem };
          result.push(mergedItem);
        });
      });
    });
  }

  const destinationFields = sourceDestinationMapping.map(
    ({ desitination_field }) => desitination_field
  );

  const filteredData = result.map((item) =>
    destinationFields.reduce((obj, key) => {
      if (item.hasOwnProperty(key)) {
        obj[key] = item[key];
      }
      return obj;
    }, {})
  );
  // Remove the mapping_column property from the final result
  // result = result.map((item) => _.omit(item, "mapping_column"));

  return filteredData;
}
