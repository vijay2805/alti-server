import { Request, Response } from "express";
import {
  DataTypes,
  Op,
  QueryTypes,
  Sequelize,
  fn,
  Transaction,
  Model,
} from "sequelize";
import { evaluate, parse } from "mathjs";
const multer = require("multer");
const xlsx = require("xlsx");
var S = require("string");

import * as ResponseHandler from "../helpers/response.handler";
import Messages from "../common/constants";
import * as rgMetricsCustomerMappingLib from "../modules/rg_metrics_customer_mapping/rg_metrics_customer_mapping.lib";
import * as rgMetricsDetailsLib from "../modules/rg_metrics_details/rg_metrics_details.lib";
import connection, { pg_server_conn } from "../config/connection";
import { table } from "console";
// const storage = multer.memoryStorage();

const upload = multer(); // Setup multer with destination folder

interface DynamicModel extends Model {
  [key: string]: any;
}
class RgMetricsCustomerDataImportController {
  static uploadFile = upload.single("file");

  static addRgMetricsCustomerData = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    const { id } = req.params;
    try {
      const input: any = req.body;
      // console.log("asdfasdf", req.file);

      const { customer_id, customer_name, metric_id, metric_name } = input;

      // const filePath = req.file.path;
      // const workbook = xlsx.readFile(filePath);
      const fileBuffer = req.file.buffer;
      const workbook = xlsx.read(fileBuffer, { type: "buffer" });
      const sheet_name_list = workbook.SheetNames;
      const xlData = xlsx.utils.sheet_to_json(
        workbook.Sheets[sheet_name_list[0]],
        { defval: null }
      );

      // let short_metric_name = metric_name.split(" ")[0];
      // let short_customer_name = customer_name.split(" ")[0];
      let short_metric_name = metric_name;
      let short_customer_name = customer_name;
      let table_name = `rg_${short_metric_name}_${short_customer_name}_data`;

      table_name = convertToValidTableName(table_name).toLowerCase();

      const bulkInsertData = xlData.map((row) => {
        const data = {
          // customer_id,
          // customer_name,
          // metric_id,
          // metric_name,
          ...row,
        };
        return data;
      });

      const columns = Object.keys(bulkInsertData[0]).map((col) =>
        convertToValidTableName(col)
      );
      let createTableQuery = `CREATE TABLE metrics.${table_name} (id SERIAL PRIMARY KEY,`;

      columns.forEach((col, index) => {
        createTableQuery += `${col} TEXT${
          index < columns.length - 1 ? "," : ""
        }`;
      });
      createTableQuery += `, created_at TIMESTAMPTZ DEFAULT NOW());`;

      const transaction: Transaction = await connection.transaction();

      /* EXCEL DATA INSERTION LOGIC STARTS */

      await connection.query(createTableQuery, {
        transaction,
        type: QueryTypes.RAW,
      });

      // Construct bulk insert query
      const columnNames = Object.keys(bulkInsertData[0]);
      const valuePlaceholders = bulkInsertData
        .map((_, rowIndex) => {
          const rowPlaceholders = columnNames
            .map(
              (_, colIndex) =>
                `$${rowIndex * columnNames.length + colIndex + 1}`
            )
            .join(", ");
          return `(${rowPlaceholders})`;
        })
        .join(", ");

      const insertValues = bulkInsertData.flatMap((row) => Object.values(row));
      const bulkInsertQuery = `INSERT INTO metrics.${table_name} (${columnNames.join(
        ", "
      )}) VALUES ${valuePlaceholders};`;

      // Execute bulk insert query with parameters
      await connection.query(bulkInsertQuery, {
        transaction,
        type: QueryTypes.INSERT,
        bind: insertValues,
      });

      let metric_customer_mapping_info_query: any = `INSERT INTO metrics.rg_metrics_customer_data_dump_details (metric_id, customer_id, data_table_name)  VALUES (${metric_id}, ${customer_id}, '${table_name}')`;
      await connection.query(metric_customer_mapping_info_query, {
        transaction,
        type: QueryTypes.INSERT,
      });
      await transaction.commit();

      /* ROW BY ROW DATA INSERTION LOGIC STARTS */

      // for (const row of xlData) {
      //   const columnNames = [
      //     ...columns,
      //     "customer_id",
      //     "customer_name",
      //     "metric_id",
      //     "metric_name",
      //   ];

      //   const columnValues = [...Object.values(row), customer_id, customer_name,metric_id, metric_name ];
      //   const valuePlaceholders = columnNames.map((_, index) => `$${index + 1}`).join(', ');
      //   const insertQuery = `INSERT INTO metrics.${table_name} (${columnNames.join(', ')}) VALUES (${valuePlaceholders});`;

      //   await connection.query(insertQuery, {
      //     transaction,
      //     type: QueryTypes.INSERT,
      //     bind: [...columnValues]

      //   });
      // }

      // await transaction.commit();

      /* ROW BY ROW DATA INSERTION LOGIC ENDS */

      /* EXCEL DATA INSERTION LOGIC ENDS */

      res.locals.data = [];
      res.locals.message = []
        ? Messages.UPDATED
        : Messages.SOMETHING_WENT_WRONG;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error) {
      console.log("errr", error);
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static saveDbSource = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    const { id } = req.params;
    try {
      const input: any = req.body;
      // console.log("asdfasdf", req.file);

      const {
        customer_id,
        metric_id,
        data_table_name,
        ds_db_info,
        ds_schema_info,
        data_source_info,
      } = input;

      let metric_customer_mapping_info_query: any = `INSERT INTO metrics.rg_metrics_customer_data_dump_details (metric_id, customer_id, data_source_info)  VALUES (?, ?, ?)`;
      await connection.query(metric_customer_mapping_info_query, {
        replacements: [
          metric_id,
          customer_id,
          JSON.stringify(data_source_info),
        ],
        type: QueryTypes.INSERT,
      });

      res.locals.data = [];
      res.locals.message = []
        ? Messages.UPDATED
        : Messages.SOMETHING_WENT_WRONG;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error) {
      console.log("errr", error);
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static saveAPISource = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    const { id } = req.params;
    try {
      const input: any = req.body;
      // console.log("asdfasdf", req.file);

      const {
        customer_id,
        metric_id,
        metric_name,
        customer_name,
        data_table_name,
        ds_db_info,
        ds_schema_info,
        apiInfo,
      } = input;

      let info = apiInfo;
      let short_metric_name = metric_name;
      let short_customer_name = customer_name;
      let table_name = `rg_${short_metric_name}_${short_customer_name}_data`;

      const body = {
        api_url: info.api_url,
        headers: [
          {
            auth_key: info.authkey,
            auth_type: null,
            auth_value: info.authvalue,
          },
        ],
        request_type: info.request_type,
        input_type: info.input_type,
        response_path: info.responsepath,
        request_body: {},
      };

      console.log("calling");
      let api_data: any = await new Promise((resolve, reject) => {
        try {
          const api_url = `http://localhost:7999/dashboard/dynamicapi/DynamicAPIData`;
          fetch(api_url, {
            method: "POST",
            body: JSON.stringify(body),
            headers: { "Content-Type": "application/json" },
          })
            .then((res) => {
              console.log("saveAPISource", res);
              return res.json();
            })
            .then((data) => {
              console.log("data", data.data);
              resolve(data.data);
            })
            .catch((err) => {
              console.log("vjj", err);
            });
        } catch (err) {
          console.log("ERERER", err);
        }
      });

      table_name = convertToValidTableName(table_name).toLowerCase();

      const bulkInsertData = api_data.map((row) => {
        const data = {
          // customer_id,
          // customer_name,
          // metric_id,
          // metric_name,
          ...row,
        };
        return data;
      });

      const columns = Object.keys(bulkInsertData[0]).map((col) =>
        convertToValidTableName(col)
      );
      console.log("columns", columns);
      let createTableQuery = `CREATE TABLE metrics.${table_name} (`;

      columns.forEach((col, index) => {
        createTableQuery += `${col} TEXT${
          index < columns.length - 1 ? "," : ""
        }`;
      });
      createTableQuery += `, created_at TIMESTAMPTZ DEFAULT NOW());`;

      const transaction: Transaction = await connection.transaction();

      /* EXCEL DATA INSERTION LOGIC STARTS */

      await connection.query(createTableQuery, {
        transaction,
        type: QueryTypes.RAW,
      });

      // Construct bulk insert query
      const columnNames = Object.keys(bulkInsertData[0]);
      const valuePlaceholders = bulkInsertData
        .map((_, rowIndex) => {
          const rowPlaceholders = columnNames
            .map(
              (_, colIndex) =>
                `$${rowIndex * columnNames.length + colIndex + 1}`
            )
            .join(", ");
          return `(${rowPlaceholders})`;
        })
        .join(", ");

      const insertValues = bulkInsertData.flatMap((row) => Object.values(row));
      const bulkInsertQuery = `INSERT INTO metrics.${table_name} (${columnNames.join(
        ", "
      )}) VALUES ${valuePlaceholders};`;

      // Execute bulk insert query with parameters
      await connection.query(bulkInsertQuery, {
        transaction,
        type: QueryTypes.INSERT,
        bind: insertValues,
      });

      let metric_customer_mapping_info_query: any = `INSERT INTO metrics.rg_metrics_customer_data_dump_details (metric_id, customer_id, data_table_name)  VALUES (${metric_id}, ${customer_id}, '${table_name}')`;
      await connection.query(metric_customer_mapping_info_query, {
        transaction,
        type: QueryTypes.INSERT,
      });
      await transaction.commit();

      res.locals.data = [];
      res.locals.message = []
        ? Messages.UPDATED
        : Messages.SOMETHING_WENT_WRONG;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error) {
      console.log("errr", error);
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getDatabaseList = async (req: Request, res: Response) => {
    try {
      let data: any = [];

      data = await connection.query(`SELECT datname FROM pg_database`, {
        type: QueryTypes.SELECT,
      });
      if (!data || !data.length) res.locals.message = Messages.NO_DATA;

      res.locals.data = data;

      ResponseHandler.JSONSUCCESS(req, res);
    } catch (e) {
      res.locals.errors = e.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getSchemaList = async (req: Request, res: Response) => {
    try {
      let db_name = req.query.dname;
      const nconn = `${pg_server_conn}/${db_name}`;
      const dconnection = new Sequelize(nconn, { dialect: "postgres" });

      const data = await dconnection.query(
        `SELECT catalog_name, schema_name FROM information_schema.schemata WHERE catalog_name = ?`,
        { replacements: [db_name], type: QueryTypes.SELECT }
      );

      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (err) {
      res.locals.errors = err.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getTableList = async (req: Request, res: Response) => {
    try {
      let db_name = req.query.dname;
      let s_name = req.query.sname;
      const nconn = `${pg_server_conn}/${db_name}`;
      const dconnection = new Sequelize(nconn, { dialect: "postgres" });

      const data = await dconnection.query(
        `SELECT * FROM information_schema.tables WHERE table_schema = ?`,
        { replacements: [s_name], type: QueryTypes.SELECT }
      );

      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (err) {
      res.locals.errors = err.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getColumnList = async (req: Request, res: Response) => {
    try {
      let db_name = req.query.dname;
      let s_name = req.query.sname;
      let t_name = req.query.tname;

      const nconn = `${pg_server_conn}/${db_name}`;
      const dconnection = new Sequelize(nconn, { dialect: "postgres" });

      const getColumnInfoQuery = `SELECT table_catalog, table_schema, table_name, column_name FROM information_schema.columns WHERE table_name = ? AND table_schema = ?`;

      const data = await dconnection.query(getColumnInfoQuery, {
        replacements: [t_name, s_name, t_name, s_name],
        type: QueryTypes.SELECT,
      });

      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (err) {
      res.locals.errors = err.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getColumnComments = async (req: Request, res: Response) => {
    try {
      let db_name = req.query.dname;
      let s_name = req.query.sname;
      let t_name = req.query.tname;

      const nconn = `${pg_server_conn}/${db_name}`;
      const dconnection = new Sequelize(nconn, { dialect: "postgres" });

      // const getColumnInfoQuery = `SELECT column_name FROM information_schema.columns WHERE table_name = ? AND table_schema = ?`;

      const getColumnCommentsQuery = `SELECT
  a.attname AS column_name,
  pg_catalog.format_type(a.atttypid, a.atttypmod) AS data_type,
  col_description(a.attrelid, a.attnum) AS column_comment
FROM
  pg_catalog.pg_attribute a
JOIN
  pg_catalog.pg_class c ON a.attrelid = c.oid
JOIN
  pg_catalog.pg_namespace n ON c.relnamespace = n.oid
WHERE
  a.attnum > 0
  AND NOT a.attisdropped
  AND c.relname = ?
  AND n.nspname = ?;`;
      const data = await dconnection.query(getColumnCommentsQuery, {
        replacements: [t_name, s_name],
        type: QueryTypes.SELECT,
      });

      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (err) {
      res.locals.errors = err.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getTableComments = async (req: Request, res: Response) => {
    try {
      let db_name = req.query.dname;
      let s_name = req.query.sname;
      let t_name = req.query.tname;
      const nconn = `${pg_server_conn}/${db_name}`;
      const dconnection = new Sequelize(nconn, { dialect: "postgres" });

      const data = await dconnection.query(
        `SELECT obj_description('${s_name}.${t_name}'::regclass, 'pg_class') AS table_comment;`,
        { replacements: [s_name, t_name], type: QueryTypes.SELECT }
      );

      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (err) {
      console.log("VJ err", err);
      res.locals.errors = err.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static addMetricCalcConfiguration = async (req: Request, res: Response) => {
    const { loggedInUser } = req.query;
    const { id } = req.params;
    try {
      const input: any = req.body;
      // console.log("asdfasdf", req.file);

      const {
        customer_id,
        metric_id,
        metric_name,
        metric_formula,
        data_source_info,
        metric_raw_mapping,
        is_custom,
        data_filter,
      } = input;

      console.log("metric_raw_mapping", metric_raw_mapping);

      let formatted_raw_mapping = metric_raw_mapping;

      if (is_custom) {
        formatted_raw_mapping[0].expression = S(
          formatted_raw_mapping[0].expression
        ).collapseWhitespace().s;
      }
      console.log("formatted_raw_mapping", formatted_raw_mapping);
      let metric_config_info: any = await connection.query(
        `SELECT * FROM metrics.rg_metrics_customer_data_dump_details WHERE metric_id=? AND customer_id = ?;`,
        {
          type: QueryTypes.SELECT,
          replacements: [metric_id, customer_id],
        }
      );
      let metric_info: any = JSON.parse(JSON.stringify(metric_config_info));
      // metric_info = metric_info[0];
      // const souce_table_name = metric_info?.data_table_name;
      // const dataSourceInfo = metric_info?.data_source_info;
      if (metric_info?.length > 0) {
        let metric_customer_mapping_info_query: any = `UPDATE metrics.rg_metrics_customer_data_dump_details SET metric_formula = ?, data_source_info = ?, metric_raw_mapping = ?, data_filter = ? WHERE metric_id = ? AND customer_id = ?`;
        await connection.query(metric_customer_mapping_info_query, {
          type: QueryTypes.INSERT,
          replacements: [
            JSON.stringify(metric_formula),
            JSON.stringify(data_source_info),
            JSON.stringify(formatted_raw_mapping),
            JSON.stringify(data_filter),
            metric_id,
            customer_id,
          ],
        });
      } else {
        let metric_customer_mapping_info_query: any = `INSERT INTO metrics.rg_metrics_customer_data_dump_details (metric_id, metric_name, customer_id, is_custom, metric_formula, data_source_info, metric_raw_mapping, data_filter)  VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
        await connection.query(metric_customer_mapping_info_query, {
          type: QueryTypes.INSERT,
          replacements: [
            metric_id,
            metric_name,
            customer_id,
            is_custom,
            JSON.stringify(metric_formula),
            JSON.stringify(data_source_info),
            JSON.stringify(formatted_raw_mapping),
            JSON.stringify(data_filter),
          ],
        });
      }
      res.locals.data = [];
      res.locals.message = []
        ? Messages.UPDATED
        : Messages.SOMETHING_WENT_WRONG;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error) {
      console.log("errr", error);
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getMetricCalcConfiguration = async (req: Request, res: Response) => {
    try {
      const { metric_id, customer_id } = req.query;
      let metric_customer_mapping_info_query: any = `SELECT * FROM metrics.rg_metrics_customer_data_dump_details WHERE metric_id = ? AND customer_id = ?`;
      let data: any = await connection.query(
        metric_customer_mapping_info_query,
        {
          type: QueryTypes.SELECT,
          replacements: [metric_id, customer_id],
        }
      );
      data = JSON.parse(JSON.stringify(data));
      res.locals.data = data;
      res.locals.message = data
        ? Messages.FETCHED
        : Messages.SOMETHING_WENT_WRONG;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error) {
      console.log("errr", error);
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };
}

export default RgMetricsCustomerDataImportController;

function mapDataToColumns(data, config) {
  let mappedData = {};
  config.forEach((cfg) => {
    if (data[cfg.source_field] !== undefined) {
      mappedData[cfg.desitination_field] = data[cfg.source_field];
    } else {
      mappedData[cfg.desitination_field] = null;
    }
  });
  return mappedData;
}

// Function to construct bulk insert query with named parameters
function constructBulkInsertQueryWithNamedParams(table, dataArray) {
  if (dataArray.length === 0) {
    return null;
  }

  const columns = Object.keys(dataArray[0]);
  const columnNames = columns.join(", ");

  let valueIndex = 1;
  const replacements = {};
  const values = dataArray
    .map((data) => {
      const placeholders = Object.entries(data)
        .map(([key, value]) => {
          const placeholder = `:value${valueIndex}`;
          replacements[`value${valueIndex}`] = value;
          valueIndex++;
          return placeholder;
        })
        .join(", ");
      return `(${placeholders})`;
    })
    .join(", ");

  const text = `INSERT INTO ${table} (${columnNames}) VALUES ${values} RETURNING id`;

  return { text, replacements };
}

const ExecuteCreateTable = async (
  colInfoQuery: any,
  sourceTableName: any,
  createTableQuery: any,
  transaction: any
) => {
  let colInfo: any = await connection.query(colInfoQuery, {
    replacements: [sourceTableName, sourceTableName],
    type: QueryTypes.SELECT,
    transaction,
  });

  const columns: any = colInfo
    ?.map((row: any) => `${row.column_name} ${row.data_type}`)
    .join(", ");
  console.log("columns", columns);
  let newTable: any = await connection.query(
    createTableQuery.replace("?", columns),
    { transaction }
  );

  return newTable;
};

function convertToValidTableName(inputString) {
  // Remove characters that are not letters, digits, or underscores
  const reservedKeywords = [
    "ALL",
    "ANALYSE",
    "ANALYZE",
    "AND",
    "ANY",
    "ARRAY",
    "AS",
    "ASC",
    "ASYMMETRIC",
    "AUTHORIZATION",
    "BINARY",
    "BOTH",
    "CASE",
    "CAST",
    "CHECK",
    "COLLATE",
    "COLUMN",
    "CONCURRENTLY",
    "CONSTRAINT",
    "CREATE",
    "CROSS",
    "CURRENT_CATALOG",
    "CURRENT_DATE",
    "CURRENT_ROLE",
    "CURRENT_SCHEMA",
    "CURRENT_TIME",
    "CURRENT_TIMESTAMP",
    "CURRENT_USER",
    "DEFAULT",
    "DEFERRABLE",
    "DESC",
    "DISTINCT",
    "DO",
    "ELSE",
    "END",
    "EXCEPT",
    "FALSE",
    "FETCH",
    "FOR",
    "FOREIGN",
    "FREEZE",
    "FROM",
    "FULL",
    "GRANT",
    "GROUP",
    "HAVING",
    "ILIKE",
    "IN",
    "INITIALLY",
    "INNER",
    "INTERSECT",
    "INTO",
    "IS",
    "ISNULL",
    "JOIN",
    "LATERAL",
    "LEADING",
    "LEFT",
    "LIKE",
    "LIMIT",
    "LOCALTIME",
    "LOCALTIMESTAMP",
    "NATURAL",
    "NOT",
    "NULL",
    "OFFSET",
    "ON",
    "ONLY",
    "OR",
    "ORDER",
    "OUTER",
    "OVERLAPS",
    "PLACING",
    "PRIMARY",
    "REFERENCES",
    "RETURNING",
    "RIGHT",
    "SELECT",
    "SESSION_USER",
    "SIMILAR",
    "SOME",
    "SYMMETRIC",
    "TABLE",
    "THEN",
    "TO",
    "TRAILING",
    "TRUE",
    "UNION",
    "UNIQUE",
    "USER",
    "USING",
    "VARIADIC",
    "VERBOSE",
    "WHEN",
    "WHERE",
    "WINDOW",
    "WITH",
  ];
  let tableName = inputString.toLowerCase();

  let sanitizedString = tableName.replace(/[^a-zA-Z0-9_]/g, "_");

  // Ensure that the resulting string begins with a letter or an underscore
  if (!/^[a-z_]/.test(sanitizedString)) {
    sanitizedString = "_" + sanitizedString;
  }

  // Trim the string to a maximum of 63 characters
  sanitizedString = sanitizedString.slice(0, 63);

  // Check and avoid reserved keywords
  if (reservedKeywords.includes(sanitizedString.toUpperCase())) {
    sanitizedString = sanitizedString + "_tbl";
  }

  return sanitizedString;
}
