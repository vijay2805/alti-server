import { Request, Response } from "express";
import { Op, QueryTypes, fn } from "sequelize";

import * as ResponseHandler from "../helpers/response.handler";
import Messages from "../common/constants";
import * as RgMetricsCustomFieldsMasterLib from "../modules/rg_metrics_custom_fields_master/rg_metrics_custom_fields_master.lib";
import connection from "../config/connection";

class RgMetricsCustomFieldsMasterController {
  static addRgMetricsCustomFieldsMaster = async (
    req: Request,
    res: Response
  ) => {
    const { loggedInUser } = req.query;
    const input = req.body;
    try {
      const obj = {
        metric_cust_field_name: input.metric_cust_field_name,
        metric_cust_field_desc: input.metric_cust_field_desc,
        created_on: fn("NOW"),
        created_by: loggedInUser,
        status: "A",
      };
      let isexist: any =
        await RgMetricsCustomFieldsMasterLib.getRgMetricsCustomFieldsMasterById(
          {
            metric_cust_field_name: input.metric_cust_field_name,
          }
        );

      if (isexist) {
        res.locals.message = "Metrics custom field already exists";
        ResponseHandler.JSONERROR(req, res);
      } else {
        let result: any =
          await RgMetricsCustomFieldsMasterLib.addRgMetricsCustomFieldsMaster(
            obj
          );

        result = JSON.parse(JSON.stringify(result));

        res.locals.data = result;
        res.locals.message = result
          ? Messages.SAVED
          : Messages.SOMETHING_WENT_WRONG;
        ResponseHandler.JSONSUCCESS(req, res);
      }
    } catch (error) {
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static updateRgMetricsCustomFieldsMaster = async (
    req: Request,
    res: Response
  ) => {
    const { loggedInUser } = req.query;
    const { id } = req.params;
    try {
      const input: any = req.body;

      const obj = {
        metric_cust_field_name: input.metric_cust_field_name,
        metric_cust_field_desc: input.metric_cust_field_desc,
        modified_on: fn("NOW"),
        modified_by: loggedInUser,
      };

      let isexist: any =
        await RgMetricsCustomFieldsMasterLib.getRgMetricsCustomFieldsMasterById(
          {
            metric_cust_field_name: input.metric_cust_field_name,
            metric_cust_id: { [Op.not]: id },
          }
        );
      if (isexist) {
        res.locals.message = "Metrics custom field already exists";
        ResponseHandler.JSONERROR(req, res);
      } else {
        const result: any =
          RgMetricsCustomFieldsMasterLib.updateRgMetricsCustomFieldsMaster(
            { metric_cust_id: id },
            obj
          );

        let data: any =
          RgMetricsCustomFieldsMasterLib.getRgMetricsCustomFieldsMasterById({
            metric_cust_id: id,
          });
        data = JSON.parse(JSON.stringify(data));

        res.locals.data = data;
        res.locals.message = data
          ? Messages.UPDATED
          : Messages.SOMETHING_WENT_WRONG;
        ResponseHandler.JSONSUCCESS(req, res);
      }
    } catch (error) {
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getRgMetricsCustomFieldsMaster = async (
    req: Request,
    res: Response
  ) => {
    const { loggedInUser } = req.query;
    try {
      let condition: any = {};
      condition = {
        status: { [Op.eq]: "A" },
      };

      const result: any =
        await RgMetricsCustomFieldsMasterLib.getRgMetricsCustomFieldsMasterList(
          condition
        );
      console.log("data", result);

      const data: any = JSON.parse(JSON.stringify(result));
      if (!data || !data.length) res.locals.message = Messages.NO_DATA;
      res.locals.data = data.sort(
        (a, b) => b.metric_cust_id - a.metric_cust_id
      );
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error: any) {
      res.locals.error = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };

  static getRgMetricsCustomFieldsMasterById = async (
    req: Request,
    res: Response
  ) => {
    const { loggedInUser } = req.query;

    try {
      const metric_cust_id = parseInt(req.params.id, 10);

      let data: any =
        await RgMetricsCustomFieldsMasterLib.getRgMetricsCustomFieldsMasterById(
          {
            metric_cust_id: metric_cust_id,
          }
        );

      data = JSON.parse(JSON.stringify(data));
      if (!data) res.locals.message = Messages.NO_DATA;
      res.locals.data = data;
      ResponseHandler.JSONSUCCESS(req, res);
    } catch (error: any) {
      res.locals.errors = error.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };
}

export default RgMetricsCustomFieldsMasterController;
