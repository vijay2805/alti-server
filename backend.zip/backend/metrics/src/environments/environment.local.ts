import dotenv from "dotenv";

console.log("++process.env.NODE_ENV",process.env.NODE_ENV);

dotenv.config({ path: `${__dirname}/./../../.env.${process.env.NODE_ENV}` });

const environmentConfiguration = {
  PORT: process.env.PORT,
  USER: process.env.USER,
  PASSWORD: process.env.PASSWORD,
  JWT_SECRET: process.env.JWT_SECRET,
  HOST: process.env.HOST,
  AUTH_KEY: process.env.AUTH_KEY,
  DB_URL: process.env.DB_URL,
  WIDGET_TOKEN: process.env.WIDGET_TOKEN,
  SERVER_URL: process.env.SERVER_URL,
  MONGO_DB_URL: process.env.MONGO_DB_URL,
  SERVER_ASSETS_URL: process.env.SERVER_ASSETS_URL,
  SSL_CERT: process.env.SSL_CERT,
  SSL_KEY: process.env.SSL_KEY,
  userDB_URL: process.env.userDB_URL,
  Customer_folder: process.env.CUSTOMERFOLDER,
  DATAWIDGETURL: process.env.DATAWIDGETURL,
  ENV_URL: process.env.ENV_URL,
  env_EMAIL: process.env.env_EMAIL,
  PROD_DATALAKE_DB_URL: process.env.PROD_DATALAKE_DB_URL,
  ENV_HOST: process.env.ENVHOST,
  ENV: process.env.ENV,
  PROD_DATALAKE_DB : process.env.PROD_DATALAKE_DB,
  PROD_DATALAKE_DB_UP: process.env.PROD_DATALAKE_DB_UP,
  PG_DB: process.env.PG_DB,
  PG_DB_UP:process.env.PG_DB_UP,

  API_ENGINE_DB: process.env.API_ENGINE_DB,
  API_ENGINE_DB_UP:process.env.API_ENGINE_DB_UP,

  MONGO_DB:process.env.MONGO_DB,
  MONGO_DB_UP:process.env.MONGO_DB_UP,
  PG_DB_Master: process.env.PG_DB_Master,
  MONGO_DB_Master:process.env.MONGO_DB_Master,
  env_pass:process.env.ENV_PASS,
  env_api:process.env.ENV_API,
  CONNECTORS_SERVER:process.env.CONNECTORS_SERVER,
  RGSPY_SERVER:process.env.RGSPY_SERVER,
  FLOWBUILDER_SERVER:process.env.FLOWBUILDER_SERVER,
};

export default environmentConfiguration;
