import { RgFrameworkDBConnection } from "../config/connection";
import { Model, DataTypes, BuildOptions } from "sequelize";

// We need to declare an interface for our model that is basically what our class would be
interface profileModel extends Model {
  profile_id: number;
  profile_name:string;
  role_id:number;
  customer_id:number;
  clients_info:string;
  project_info:string;
  menu_info:string;
  widget_info:string;
  created_on:string;
  created_by:number;
  modified_on:string;
  modified_by:number;
  status:string;
}

// Need to declare the static model so `findOne` etc. use correct types.
type profileModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): profileModel;
};

// TS can't derive a proper class definition from a `.define` call, therefor we need to cast here.
const profile = <profileModelStatic>(
  RgFrameworkDBConnection.define(
    "fw_profiles",
    {
    profile_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
    profile_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      role_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      
      customer_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      clients_info:{
        type: DataTypes.TEXT,
        allowNull: true,
      },
      project_info:{
        type: DataTypes.TEXT,
        allowNull: false,
      },
      menu_info:{
        type: DataTypes.TEXT,
        allowNull: false,
      },
      widget_info:{
        type: DataTypes.TEXT,
        allowNull: false,
      },
      created_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      modified_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      status: {
        type: DataTypes.CHAR,
        allowNull: false,
      },
    },
    { schema: "public", freezeTableName: true, timestamps: false }
  )
);


export default profile;
