import { RgFrameworkDBConnection } from "../config/connection";
import { Model, DataTypes, BuildOptions } from "sequelize";

// We need to declare an interface for our model that is basically what our class would be
interface onboardingModel extends Model {
  user_id: number;
  username:string;
  password_hash:string;
  email: string;
  full_name:string;
  phone_number:number;
  profile_id:number;
  permisssion_set_id:number;
  customer_id:number;
  role_id:number;
  user_privileges:JSON;
  created_on:string;
  created_by:number;
  modified_on:string;
  modified_by:number;
  status:string;
  twofa_auth_code: string;
  enable_twofa: number;
  is_twofa_login: number;
  active_token: string;
  is_active_session: number;
  active_session: Date;
}

// Need to declare the static model so `findOne` etc. use correct types.
type onboardingModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): onboardingModel;
};

// TS can't derive a proper class definition from a `.define` call, therefor we need to cast here.
const onboarding = <onboardingModelStatic>(
  RgFrameworkDBConnection.define(
    "fw_users",
    {
      user_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      username: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      password_hash: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      full_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      phone_number: {
        type: DataTypes.NUMBER,
        allowNull: true,
      },
      profile_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      permission_set_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      customer_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      role_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      user_privileges: {
        type: DataTypes.JSON,
        allowNull: false,
      },
      created_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      modified_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      status: {
        type: DataTypes.CHAR,
        allowNull: false,
      },
      twofa_auth_code: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      enable_twofa: {
        type: DataTypes.SMALLINT,
        allowNull: true,
        defaultValue: 0,
      },
      is_twofa_login: {
        type: DataTypes.SMALLINT,
        allowNull: false,
        defaultValue: 1,
      },
      active_token: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      is_active_session: {
        type: DataTypes.SMALLINT,
        allowNull: true,
      },
      active_session: {
        type: DataTypes.DATE,
        allowNull: true,
      },
    },
    { schema: "public", freezeTableName: true, timestamps: false }
  )
);

export default onboarding;
