import { Json } from "sequelize/types/lib/utils";
import { RgFrameworkDBConnection } from "../config/connection";
import { Model, DataTypes, BuildOptions } from "sequelize";

// We need to declare an interface for our model that is basically what our class would be
interface objectMappingModel extends Model {
  object_id: number;
  profile_id:number;
  customer_id:number;
  objmapping_info:Json;
  created_on:string;
  created_by:number;
  modified_on:string;
  modified_by:number;
  status:string;
}

// Need to declare the static model so `findOne` etc. use correct types.
type objectMappingModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): objectMappingModel;
};

// TS can't derive a proper class definition from a `.define` call, therefor we need to cast here.
const objectMapping = <objectMappingModelStatic>(
    RgFrameworkDBConnection.define(
    "fw_object_profile_mapping",
    {
    object_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
    profile_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      customer_id: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      objmapping_info: {
        type: DataTypes.JSON,
        allowNull: true,
      },
      created_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      modified_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      status: {
        type: DataTypes.CHAR,
        allowNull: false,
      },
    },
    { schema: "public", freezeTableName: true, timestamps: false }
  )
);


export default objectMapping;
