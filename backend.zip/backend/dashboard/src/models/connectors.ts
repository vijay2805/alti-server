import { RgFrameworkDBConnection } from "../config/connection";
import { Model, DataTypes, BuildOptions } from "sequelize";

// We need to declare an interface for our model that is basically what our class would be
interface connectorModel extends Model {
    connector_id: number;
    connector_name:string;
    connector_desc:number;
    connector_info:string;
    created_on:string;
    created_by:number;
    modified_on:string;
    modified_by:number;
    status:string;
}

// Need to declare the static model so `findOne` etc. use correct types.
type connectorModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): connectorModel;
};

// TS can't derive a proper class definition from a `.define` call, therefor we need to cast here.
const connector = <connectorModelStatic>(
  RgFrameworkDBConnection.define(
    "connectors",
    {
    connector_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
    connector_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      connector_desc:{
        type: DataTypes.TEXT,
        allowNull: true,
      },
      connector_info:{
        type: DataTypes.JSON,
        allowNull: true,
      },
      created_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      modified_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      status: {
        type: DataTypes.CHAR,
        allowNull: false,
      },
    },
    { schema: "public", freezeTableName: true, timestamps: false }
  )
);


export default connector;
