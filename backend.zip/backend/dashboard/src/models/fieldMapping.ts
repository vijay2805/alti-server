import { Json } from "sequelize/types/lib/utils";
import { RgFrameworkDBConnection } from "../config/connection";
import { Model, DataTypes, BuildOptions } from "sequelize";

// We need to declare an interface for our model that is basically what our class would be
interface fieldMappingModel extends Model {
  field_id: number;
  field_name:string;
  object_id:number;

  field_type:number;
  field_desc:string;
  customer_id:number;
  field_info:Json;


  readable:number;
  ediatable:number;
  deletable:number;
  created_on:string;
  created_by:number;
  modified_on:string;
  modified_by:number;
  status:string;
}

// Need to declare the static model so `findOne` etc. use correct types.
type fieldMappingModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): fieldMappingModel;
};

// TS can't derive a proper class definition from a `.define` call, therefor we need to cast here.
const fieldMapping = <fieldMappingModelStatic>(
    RgFrameworkDBConnection.define(
    "fw_object_field_mapping",
    {
      field_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      field_name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      object_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      field_type: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      field_desc: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      customer_id: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      field_info: {
        type: DataTypes.JSON,
        allowNull: true,
      },
      readable: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      editable: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      deletable: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      created_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      modified_on: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      status: {
        type: DataTypes.CHAR,
        allowNull: false,
      },
    },
    { schema: "public", freezeTableName: true, timestamps: false }
  )
);


export default fieldMapping;
