const axios = require('axios');
const url = require('url');
import { sanitizeRequestObj } from "./sanitizeAndValidateDate";

export const baseURL = (baseURL) => {
  return axios.create({
    baseURL: baseURL,
  });
}

export const axiosURL = async (req) => {
  const sanitizedRequest= await sanitizeRequestObj(req); 
  // const sanitizedRequest: any = req; 
  // console.log("santized REQ---",sanitizedRequest);
  const url =  require('url');
  let payload = sanitizedRequest.query;
  if (sanitizedRequest.hasOwnProperty('emailid')) {
    payload['loggedInUser'] = sanitizedRequest.loggedInUser;
  }
  if (sanitizedRequest.hasOwnProperty('emailid')) {
    payload['emailid'] = sanitizedRequest.emailid;
  }
  if (sanitizedRequest.hasOwnProperty('token')) {
    payload['token'] = sanitizedRequest.token;
  }
  const params = new url.URLSearchParams(payload);
  const finalURL = `${sanitizedRequest.path}?${params}`;
  return finalURL;
}