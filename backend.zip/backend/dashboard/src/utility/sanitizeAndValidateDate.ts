import Joi from "joi";
import xss from "xss";
const sanitizeHtml = require("sanitize-html");
import validator from 'validator';

// Validate and sanitize a date string using Joi
export function sanitizeAndValidateDate(input: any): string | null {
  const schema = Joi.string().isoDate().required();

  const { error, value } = schema.validate(input);
  if (!error) {
    return value;
  } else {
    return null;
  }
}
  
// Sanitize and validate a string using Joi
export function sanitizeAndValidateString(input: any): string | null {
  const schema = Joi.string().required();

  const { error, value } = schema.validate(input);
  if (!error && !/\W/.test(value)) {
    const sanitizedValue = sanitizeHtml(value, {
      allowedTags: [], // Allow no HTML tags
      allowedAttributes: {}, // Allow no HTML attributes
    });

    return sanitizedValue;
  } else {
    return "";
  }
}



// // Sanitize and validate an object using Joi
// export function sanitizeAndValidateObj(input: any): any {
//   if (typeof input !== "object" || input === null) {
//     return {};
//   }

//   const sanitizedInput = { ...input };

//   for (const key in sanitizedInput) {
//     if (Object.prototype.hasOwnProperty.call(input, key) && !/\W/.test(key)) {
//       sanitizedInput[key] = sanitizeString(sanitizedInput[key]);
//     } else {
//       delete sanitizedInput[key]; // Remove keys with non-word characters
//     }
//   }

//   return sanitizedInput;
// }

// Sanitize and validate an object using Joi
export function sanitizeAndValidateObj(input: any): any {
  if (typeof input !== "object" || input === null) {
    return {};
  }

  const sanitizedInput = { ...input };

  for (const key in sanitizedInput) {
    if (Object.prototype.hasOwnProperty.call(input, key) && !/\W/.test(key)) {
      sanitizedInput[key] = sanitizeString(sanitizedInput[key]);
    } else {
      delete sanitizedInput[key]; // Remove keys with non-word characters
    }
  }

  return sanitizedInput;
}

// Sanitize a string using the `joi` library
function sanitizeString(value: any): any {
  const data = Joi.string().isoDate().required();
  const isCheck = data.validate(value);
  // console.log("isCheck",isCheck);
  if (typeof value == 'boolean' || typeof value == "object"){
    return value;
  }
  if (typeof value === 'string') {
    return validator.unescape(value);
  } else if (value && !isNaN(value)) {
     return parseInt(value,10)
  }else if (!isCheck.error) {
      return isCheck.value
  } else {
      return value
  }
  
}

// // Sanitize a string using the `joi` library
// function sanitizeString(value: any): any {
//   if (typeof value === "string") {
//     return value;
//   }
//   return value;
// }

export const sanitizeRequestObj = async (req) => {
  // console.log("req==",req.body);
  // const req = { ...req };

  // Sanitize request body
  if (req.body) {
    if (Array.isArray(req.body) && req.body.length) {
      req.body = await Promise.all(
        req.body.map(async (item) => {
          if (typeof item === "string") {
            return await xss(item);
          } else {
            return item;
          }
        })
      );
    } else if (typeof req.body === "object") {
      await Promise.all(
        Object.keys(req.body).map(async (key) => {
          if (typeof req.body[key] === "string") {
            req.body[key] = await xss(req.body[key]);
          }
        })
      );
    }
  }

  // Sanitize query parameters
  if (req.query) {
    await Promise.all(
      Object.keys(req.query).map(async (key) => {
        if (typeof req.query[key] === "string") {
          req.query[key] = await xss(req.query[key]);
        }
      })
    );
  }

  return req;
};
