import express from "express";
const router = express.Router();
import { validateJwt } from "../middlewares/validateJWT";
const { baseURL, axiosURL } = require("../utility/apiAdapter");
import * as EnvHandler from "../helpers/environment.handler";
//import APIErrorLogger from "../middlewares/apilogger";

import { sanitizeRequestObj } from "../utility/sanitizeAndValidateDate";
const CONNECTORS_SERVER_BASE_URL = EnvHandler.CONNECTORS_SERVER_URL();
const api = baseURL(CONNECTORS_SERVER_BASE_URL);

router.get("/connectors-gateway*", validateJwt, async(req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  api
    .get(url)
    .then((resp) => {
      res.setHeader("X-Frame-Options", "SAMEORIGIN");
      res.send(resp.data);
    })
    .catch((error) => {
      const protocol = req.protocol;
      const host = req.hostname;
      const url = req.originalUrl;
      const port = process.env.PORT;

      const fullUrl = `${protocol}://${host}:${port}${url}`;
      // APIErrorLogger.error(
      //   `${error}, Request : ${fullUrl}, Method:${req.method}`
      // );
    });
});
router.delete("/connectors-gateway*", validateJwt, async(req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  api
    .delete(url)
    .then((resp) => {
      res.setHeader("X-Frame-Options", "SAMEORIGIN");
      res.send(resp.data);
    })
    .catch((error) => {
      const protocol = req.protocol;
      const host = req.hostname;
      const url = req.originalUrl;
      const port = process.env.PORT;

      const fullUrl = `${protocol}://${host}:${port}${url}`;
      // APIErrorLogger.error(
      //   `${error}, Request : ${fullUrl}, Method:${req.method}`
      // );
    });
});
router.post("/connectors-gateway*", validateJwt, async(req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  
  api
    .post(url, sanitizedRequest["body"])
    .then((resp) => {
      res.status(resp.data.status).send(resp.data);
    })
    .catch((error) => {
      const protocol = req.protocol;
      const host = req.hostname;
      const url = req.originalUrl;
      const port = process.env.PORT;

      const fullUrl = `${protocol}://${host}:${port}${url}`;
      // APIErrorLogger.error(
      //   `${error}, Request : ${fullUrl}, Method:${req.method}`
      // );
    });
});
router.put("/connectors-gateway*", validateJwt, async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  
  api
    .put(url, sanitizedRequest["body"])
    .then((resp) => {
      res.status(resp.data.status).send(resp.data);
    })
    .catch((error) => {
      const protocol = req.protocol;
      const host = req.hostname;
      const url = req.originalUrl;
      const port = process.env.PORT;

      const fullUrl = `${protocol}://${host}:${port}${url}`;
      // APIErrorLogger.error(
      //   `${error}, Request : ${fullUrl}, Method:${req.method}`
      // );
    });
});
router.patch("/connectors-gateway*", validateJwt, async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  
  api
    .patch(url, sanitizedRequest["body"])
    .then((resp) => {
      res.setHeader("X-Frame-Options", "SAMEORIGIN");
      res.send(resp.data);
    })
    .catch((error) => {
      const protocol = req.protocol;
      const host = req.hostname;
      const url = req.originalUrl;
      const port = process.env.PORT;

      const fullUrl = `${protocol}://${host}:${port}${url}`;
      // APIErrorLogger.error(
      //   `${error}, Request : ${fullUrl}, Method:${req.method}`
      // );
    });
});

export default router;
