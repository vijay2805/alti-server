import express from "express";
const router = express.Router();
import fs from "fs";
import * as path from "path";
// const { baseURL, axiosURL } = require("../utility/apiAdapter");
import { baseURL,axiosURL } from "../utility/apiAdapter";

import * as EnvHandler from "../helpers/environment.handler";
import { sanitizeRequestObj } from "../utility/sanitizeAndValidateDate";
const CONNECTORS_SERVER_BASE_URL = EnvHandler.CONNECTORS_SERVER_URL();
// console.log(CONNECTORS_SERVER_BASE_URL);
const api = baseURL("http://localhost:9001");
import { validateHeaders } from "../middlewares/validateJWT";

router.get("/connectors-gateway*",validateHeaders, async(req:any, res:any) => {
  // console.log("/connectors-gateway called")
  const sanitizedRequest = await sanitizeRequestObj(req);
  // console.log("sanitizedRequest",sanitizedRequest)
  const url = await axiosURL(sanitizedRequest);
  console.log("url",url)
  api.get(url).then(async (resp:any) => {
    console.log("called inside");
      res.setHeader("X-Frame-Options", "SAMEORIGIN");
      res.send(resp.data);
  });
});
router.delete("/connectors-gateway*",validateHeaders, async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  api.delete(url).then((resp) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.send(resp.data);
  });
});
router.post("/connectors-gateway*",validateHeaders, async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  api.post(url, sanitizedRequest["body"]).then((resp) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.send(resp.data);
  });
});
router.put("/connectors-gateway*",validateHeaders, async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  api.put(url, sanitizedRequest["body"]).then((resp) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.send(resp.data);
  });
});
router.patch("/connectors-gateway*",validateHeaders, async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  api.patch(url, sanitizedRequest["body"]).then((resp) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.send(resp.data);
  });
});

export default router;
