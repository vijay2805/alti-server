import express from "express";
const router = express.Router();
import FormData from "form-data"; // Import the form-data package

import fs from "fs";
import * as path from "path";
// const { baseURL, axiosURL } = require("../utility/apiAdapter");
import { baseURL, axiosURL } from "../utility/apiAdapter";
import multer from "multer";

import * as EnvHandler from "../helpers/environment.handler";
import { sanitizeRequestObj } from "../utility/sanitizeAndValidateDate";
//const METRICS_SERVER_URL = EnvHandler.METRICS_SERVER_URL();
const METRICS_SERVER_URL = 'http://localhost:7001';
// console.log(CONNECTORS_SERVER_BASE_URL);
const api = baseURL(METRICS_SERVER_URL);
import { validateHeaders } from "../middlewares/validateJWT";
const upload = multer(); // Multer instance for parsing multipart/form-data

router.get("/metrics-gateway*", async (req: any, res: any) => {
  // console.log("/metrics-gateway called")
  const sanitizedRequest = await sanitizeRequestObj(req);
  // console.log("sanitizedRequest",sanitizedRequest)
  const url = await axiosURL(sanitizedRequest);
  console.log("url", url);
  api.get(url).then(async (resp: any) => {
    console.log("called inside", resp);
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.send(resp.data);
  });
});
router.delete("/metrics-gateway*", async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  api.delete(url).then((resp) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.send(resp.data);
  });
});
router.post("/metrics-gateway-formdata*", upload.single('file'), async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  const formData: any = new FormData();
    
  // Append all fields to formData
  for (const key in sanitizedRequest.body) {
    formData.append(key, sanitizedRequest.body[key]);
  }

  console.log(" req.file",  req.file)
  
  // Append the file to formData
  if (req.file) {
    formData.append('file', req.file.buffer, req.file.originalname);
  }
  
  const config = {
    headers: {
      ...formData.getHeaders()
    }
  };
  api.post(url, formData, config).then((resp) => {
    console.log("VJJ POST", resp);
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.status(resp.data.status).send(resp.data);
  });
});
router.post("/metrics-gateway*", async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  api.post(url, sanitizedRequest["body"]).then((resp) => {
    console.log("VJJ POST", resp);
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.status(resp.data.status).send(resp.data);
  });
});

router.put("/metrics-gateway*", async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  api.put(url, sanitizedRequest["body"]).then((resp) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.status(resp.data.status).send(resp.data);
  });
});
router.patch("/metrics-gateway*", async (req, res) => {
  const sanitizedRequest = await sanitizeRequestObj(req);
  const url = await axiosURL(sanitizedRequest);
  api.patch(url, sanitizedRequest["body"]).then((resp) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.status(resp.data.status).send(resp.data);
  });
});

export default router;
