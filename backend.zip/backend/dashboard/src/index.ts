import express, { Request, Response } from "express";
const helmet = require("helmet");
import dotenv from "dotenv";
import cors from "cors";
import * as bodyParser from "body-parser";
import { createServer } from "http";
import {
  APIEngineDBConnection,
  RgFrameworkDBConnection,
} from "./config/connection";
var cookieParser = require("cookie-parser");
var cookieSession = require("cookie-session");
import * as onboardingLib from "./modules/onboarding/onboarding.lib";
var CryptoJS = require("crypto-js");

import axios from "axios";
import { Sequelize, QueryTypes, Op } from "sequelize";
import { generateJWT } from "./helpers/auth.handler";

import * as jwt from "jsonwebtoken";
import sha1 from "sha1";

import connection from "./config/connection";
import * as EnvHandler from "./helpers/environment.handler";

const app = express();

import Messages from "./common/constants";
import * as ResponseHandler from "./helpers/response.handler";
import https from "https";
import fs from "fs";
import path from "path";

import * as HttpStatus from "http-status-codes";
var xss = require("xss");

import dynamicapi from "./routes/dynamicapi";
import onboarding from "./routes/onboarding";
import dynamic_crud_api from "./routes/dynamic_crud_api";
import projects from "./routes/projects";
import menus from "./routes/menus";
import widgets from "./routes/widgets";
import profiles from "./routes/profiles";
import users from "./routes/users";
import empinfo from "./routes/empinfo";
import fieldMapping from "./routes/fieldMapping";
import objecctMapping from "./routes/objecctMapping";
//connectors start
import connectoresConfig from "./routes/connectorsconfiguration";
//connectors end
dotenv.config();
//microservice changes start in TS
//import router1 from "./routes/routerV1";
import router2 from "./routes/routerV2";
import APIErrorLogger from "./middlewares/apilogger";
//microservice changes end in TS
console.log("First");
//saml changes start

const passport = require("passport");
const session = require("express-session");
const { Strategy } = require("passport-saml");
const xml2js = require("xml2js");
const { Buffer } = require("buffer");
// const bodyParser = require('body-parser');
//saml changes end
const port: any = EnvHandler.envPORT() || 7999;
const env: any = EnvHandler.ENV() || "local";
const host = EnvHandler.envSERVER_URL();

const corsOptions = {
  origin: "*", // Update with your frontend's origin
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  credentials: true,
  optionsSuccessStatus: 204,
};
app.use(cors(corsOptions));
app.use(function (req, res, next) {
  res.setHeader(
    "Content-Security-Policy-Report-Only",
    "default-src 'self'; font-src 'self'; img-src 'self'; script-src 'self'; style-src 'self'; frame-src 'self'"
  );
  next();
});

app.use(bodyParser.json({ limit: "5gb" }));
app.all("/*", function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  next();
});
//saml changes start
app.use(
  session({ secret: "your-secret-key", resave: true, saveUninitialized: false })
);
app.use(passport.initialize());
app.use(passport.session());
passport.use(
  new Strategy(
    {
      entryPoint:
        "https://login.microsoftonline.com/d33ecf7f-34a9-469a-9102-cbae981e9847/saml2",
      issuer: "https://dbsso.revgain.ai/",
      callbackUrl: "https://dbsso.revgain.ai/saml/consume",
      // issuer: "http://localhost:8080/",
      // callbackUrl: "http://localhost:8999/saml/consume",
      // cert: "MIIC8DCCAdigAwIBAgIQKz8Zj8IH0YlPnfQsM+7ZvjANBgkqhkiG9w0BAQsFADA0MTIwMAYDVQQDEylNaWNyb3NvZnQgQXp1cmUgRmVkZXJhdGVkIFNTTyBDZXJ0aWZpY2F0ZTAeFw0yNDAyMDcxNzE0MTBaFw0yNzAyMDcxNzE0MDdaMDQxMjAwBgNVBAMTKU1pY3Jvc29mdCBBenVyZSBGZWRlcmF0ZWQgU1NPIENlcnRpZmljYXRlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvtBXulWbxwjg8lh077rIHfe94z2w0LGH9U27MeFkdt6sZHQVGXkkSe9bJpGVmdumGJ9GVAoHGWLYziaar9i826AERWrN5AHHWqZVJSYRXZHj4fn8emBQr8TIxnjcWQ8T8JT7q043BLhjI8PH9KYQ9Yi6mMFxvmDFy4DF7lv6KOZDxkxFC1Xv7k7fXOIB/dWHrz+ogVsLq1ty1X5ERRVByTg0gKeX467qW93vwplZK19XQm03cvaUcN1OIfqzracXrBHqgXGP2t7HIUQOhD1+jDeX0mZ5rytz4UXeSt+TqIqJSndMTHsKPYlF0Vlh80DpeAX9u2MOJegDJ5TRQs09rQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQA1rCxjU/uHWEKIr292/yXkZX9MeFGVEItwPAFbqqIjmnMzCey8RAkDUSmRDqrm6K9mWMGUXRNuOg1yGYHXx1BLwa8IhQZ/uBhcn/JLR7YwZKzRMJcXRCEWiQ2ILODIzDXSGv4KvoWPlppYk5B7G6KSjz40XNuQMjmDpGGczMXrg2FB9w+cYz9bUDby1PUClP+psFXj+lSyM/WFq9F4/bmfxW4VrracRDD4yklYf8CdnqVrY61rNz/2ZCZwy/jJHiZ6WFzNgp7zD25Ib7OvM28KGcPnWt9767AH/ghBoBMFZprNJNTQHag+QLo5vSBv0e0OtdP220FYmTw5HwsRrjxI",
      cert: "MIIC8DCCAdigAwIBAgIQJITG0cHVP71ISRscOmwM5TANBgkqhkiG9w0BAQsFADA0MTIwMAYDVQQDEylNaWNyb3NvZnQgQXp1cmUgRmVkZXJhdGVkIFNTTyBDZXJ0aWZpY2F0ZTAeFw0yNDAzMjYxNjUyMzRaFw0yNzAzMjYxNjUyMzBaMDQxMjAwBgNVBAMTKU1pY3Jvc29mdCBBenVyZSBGZWRlcmF0ZWQgU1NPIENlcnRpZmljYXRlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+2FBW2o2gG4OaAg18h080qin+rPytpTYmP/wtDLIf18IyaUpSZD32XKrPLv94w3Gbrn5ccR4PGmX351xiB41wbnUjwppNI0629/x2sDuNZPw+LTeafYavvObCdSIKoA5YFaEIkLMRF6bk5S2qyfqQtmyrfll/vSARhx7wtv2yPMysCHO9Nusp4WQp0L6/mDgIsB/+OmdT9/8x1guW9MIvFSq+3pnz/myajL7ZfOmAk7//wA53Cbq0XUIen1vv+KmIvxlOqJIy3RYJPMLl0ipMZbXM06sXyiqt6BoXCmhPZn93hhsya0fkOF/DhWuyQGl52Swm7XRNpoC8iteYT/VsQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQAw9zAJ0OesFQ9ig2IRzcG8fDgqoJbRTqLNjOVzP/FDpYOLJEwyT1Ahldxr/JHPTQSuiRvkbmFrrH5tbKgs7cuLKsvt0c+FmF/ZKJNGd35OXu9vZX6XUEqO8HZH3NbEw/WwFp3hGsBPlZzrkjk0F5/UgQXf25Fec0apHHp26XVvihS1gFLWClxf7b1fLbXiSj5I3riNySEFy7dwUvF+WkPmQSyEJtYVDNTB9wPAhRoLhTLkhBYlbHULHqygcrsJOVd7DM0xyxlXqIjDLQUKKOO/4SLfFXHyiptQCMqr3yP+ICKqaHIRz01JE4oxXHuRyjEO416OqcE+Z6g8lo3ogDGZ"
    },
    (profile, done) => {
      // console.log("profile=", profile);
      return done(null, profile);
    }
  )
);

passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((user, done) => {
  done(null, user);
});
//saml changes end
app.disable("etag").disable("x-powered-by");
app.use(bodyParser.urlencoded({ extended: true })); //for token
// app.use(bodyParser.urlencoded({ extended: true, limit: "2gb" }));
// app.use(
//   express.session({
//     secret: "k5Zurj4",
//     cookie: {
//       httpOnly: true,
//       secure: true,
//     },
//   })
// );
//Sequelize database connection
connection
  .authenticate()
  .then(() => {
    console.log(
      "PostgreSQL Connection using Sequelize has been established successfully."
    );
  })
  .catch((err: string) => {
    console.error("Unable to connect to the database:", err);
  });

// allow cross origin

app.use(helmet());
app.use(
  helmet.hsts({
    // 60 days
    maxAge: 86400,
    // removing the "includeSubDomains" option
    includeSubDomains: false,
  })
);
// app.get("/login", passport.authenticate("saml"));

app.get("/", (req, res) => {
  res.setHeader(
    "Strict-Transport-Security",
    "max-age=31536000; includeSubDomains"
  );
  res.send("Hey there!!!");
});

app.use("/logger", async (req: Request, res: Response) => {
  try {
    const input = req.body;
    input["view_date"] = new Date();
    APIErrorLogger.info(input);

    res.locals.data = input;
    res.locals.message = Messages.SAVED;
    ResponseHandler.JSONSUCCESS(req, res);
  } catch (e) {
    res.locals.errors = "An error occured";
    ResponseHandler.JSONERROR(req, res);
  }
});

app.get(
  "/login",
  passport.authenticate("saml", { failureRedirect: "/", failureFlash: true }),
  (req, res) => {
    res.redirect("/");
  }
);

//if required login functionality end
app.post(
  "/saml/consume",
  cors(),
  passport.authenticate("saml", {
    failureRedirect: "/logincheck",
    failureFlash: true,
  }),
  (req, res) => {
    // Successful authentication, redirect or send user details

    return res.redirect("/logincheck");
  }
);

app.get("/validate-user", (req, res, next) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({
      message: "Unauthorized",
    });
  } else {
    return res.status(200).json({ user: req.user });
  }
});

app.get("/logincheck", async (req, res) => {
  // console.log("==point2");
  // console.log("res-", res);
  // res.send(req);
  if (req.isAuthenticated()) {
    //db insertion start
    let result: any;
    let subResult: any;

    const currentDate = new Date(); // Replace this with your date object
    const formattedDate = currentDate.toISOString().split("T")[0];

    const user_info = req.user;
    const email = user_info.nameID;
    const sessionIndex = user_info.sessionIndex;
    const name =
      user_info["http://schemas.microsoft.com/identity/claims/displayname"];
    console.log("email", email);
    //sso logic changes for tales start
    // Redirect to frontend with JWT token as a query parameter
    let user_infoExists: any = await RgFrameworkDBConnection.query(
      `SELECT * FROM public.fw_users WHERE email='${email}' and status='A';`,
      {
        type: QueryTypes.SELECT,
      }
    );
    let mask_mail_info: any = await RgFrameworkDBConnection.query(
      `SELECT * FROM public.fw_email_mask WHERE actual_email = '${email}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    let mask_email = mask_mail_info[0]?.mask_email || email;
    if (user_infoExists?.length > 0) {
      console.log("user_infoExists=", user_infoExists);
      const user_id = user_infoExists[0]["user_id"];
      const active_session = new Date(new Date().getTime() + 3600000 * 5.5);
      const token: string = generateJWT({
        userId: user_id,
        email: email ? email : "",
        user_email: mask_email,
      });
      // await RgFrameworkDBConnection.query(
      //   `UPDATE public.fw_users SET session_index = ?,modified_by=?,modified_on=?,active_session=?,is_active_session=?,active_token=? WHERE user_id = ?`,
      //   {
      //     replacements: [
      //       sessionIndex,
      //       user_id,
      //       formattedDate,
      //       active_session,
      //       1,
      //       token,
      //       user_id
      //     ],
      //     type: QueryTypes.INSERT
      //   }
      // )

      subResult = await RgFrameworkDBConnection.query(
        `UPDATE public.user_token_info SET session_index = ? WHERE email = ?`,
        {
          replacements: [sessionIndex, email],
          type: QueryTypes.INSERT,
        }
      );
      return res.redirect(
        `https://dbssologin.revgain.ai/success-handler?token=${token}`
      );
    } else {
      const def_customer_id = 2;
      result = await RgFrameworkDBConnection.query(
        `INSERT INTO public.fw_users(username, email, customer_id,session_index, user_info,status,created_on) VALUES('${name}', '${email}','${def_customer_id}','${sessionIndex}','${JSON.stringify(
          user_info
        )}', 'A','${formattedDate}') returning*`,
        {
          type: QueryTypes.INSERT,
        }
      );
      console.log("result=", result);
      let id = result[0][0]["user_id"];
      let pemail = result[0][0]["email"];
      let session_index = result[0][0]["session_index"];
      console.log("result", result);
      subResult = await RgFrameworkDBConnection.query(
        `INSERT INTO public.user_token_info(id, email, session_index, status,created_date) VALUES(?, ?, ?, ?, ?)`,
        {
          replacements: [id, pemail, session_index, "A", formattedDate],
          type: QueryTypes.INSERT,
        }
      );
      const token: string = generateJWT({
        userId: id,
        email: email ? email : "",
        user_mail: mask_email,
      });
      return res.redirect(
        `https://dbssologin.revgain.ai/success-handler?token=${token}`
      );
    }
    //db insertion end
  } else {
    return res.redirect(
      `https://dbssologin.revgain.ai/success-handler?token=null`
    );
  }
});
//saml functionalities changes end
app.get("/read-file", (req: Request, res: Response) => {
  const filePath = path.join(__dirname, "./../../../../public/python_file.py");
  fs.readFile(filePath, "utf8", (err, data) => {
    if (err) {
      console.log("VJJ Err", err);
      return res.status(500).send("Error reading file");
    }
    res.send({ content: data });
  });
});

app.post("/save-file", (req: Request, res: Response) => {
  const { content } = req.body;
  const timestamp = getFormattedTimestamp();

  const newFilePath = path.join(
    __dirname,
    `./../../../../public/python_file_${timestamp}.py`
  );
  fs.writeFile(newFilePath, content, "utf8", (err) => {
    if (err) {
      return res.status(500).send("Error saving file");
    }
    res.send("File saved successfully");
  });
});

app.use("/dashboard/dynamicapi", dynamicapi);
app.use("/dashboard/onboarding", onboarding);
app.use("/dashboard/dynamic_crud_api", dynamic_crud_api);
app.use("/dashboard/projects", projects);
app.use("/dashboard/menus", menus);
app.use("/dashboard/widgets", widgets);
app.use("/dashboard/profiles", profiles);
app.use("/dashboard/users", users);
app.use("/dashboard/empinfo", empinfo);
app.use("/dashboard/fieldMapping", fieldMapping);
app.use("/dashboard/objecctMapping", objecctMapping);
app.use("/dashboard/connectoresConfig", connectoresConfig);
//sso jwt token based data
app.post("/dashboard/getjwttokenData", async (req: any, res: any) => {
  // Successful authentication, redirect or send user details
  try {
    const input = req.body;
    console.log("input", input);
    const jwtSecret = "qwerty";
    const tokenget = input.jwttoken;
    let payload = jwt.verify(tokenget, jwtSecret);
    console.log("payload=", payload);
    const email = payload.emailid;
    //token based data changes start
    let userDetail = await onboardingLib.getonboardingByUser({
      email: email,
    });
    userDetail = JSON.parse(JSON.stringify(userDetail));
    let data: any = {};
    data = userDetail;
    const sessionKey = async () => {
      var number = Math.random(); // 0.9394456857981651
      number.toString(36); // '0.xtis06h6'
      var id = number.toString(36).substr(2, 9); // 'xtis06h6'
      return id;
    };
    const session_key: string = await sessionKey();
    //get rbac data start
    let role_data_sub: any = [];
    let role_data: any = [];

    const customer_id_res = data?.customer_id;
    const user_id_res = data?.user_id;
    role_data_sub = await RgFrameworkDBConnection.query(
      `SELECT * from public.fw_project_rbac_role_mapping where customer_id=${customer_id_res} and user_id=${user_id_res} and status='A';`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (role_data_sub.length > 0) {
      role_data = await RgFrameworkDBConnection.query(
        `SELECT * from public.fw_project_rbac_role_configuration where customer_id=${role_data_sub[0].customer_id} and role_id=${role_data_sub[0].role_id} and status='A';`,
        {
          type: QueryTypes.SELECT,
        }
      );
    }
    // console.log("role_data=",role_data);
    //get settings access start
    let settings_data: any = [];
    settings_data = await RgFrameworkDBConnection.query(
      `SELECT * from public.fw_settings where customer_id=${customer_id_res} and user_id=${user_id_res} and status='A';`,
      {
        type: QueryTypes.SELECT,
      }
    );
    // console.log("settings_data==",settings_data.length);
    // return false;
    //get settings access end
    //get frbac data end

    data = {
      verified: true,
      user: {
        ...data,
        name: data.username,
        role_info: role_data,
        rbac_access: settings_data && settings_data?.length > 0 ? true : false,
        token: tokenget,
        session_key,
        staffId: data.user_id,
      },
    };
    //token based data changes end
    res.locals.data = data;
    ResponseHandler.JSONSUCCESS(req, res);
  } catch (e) {
    res.locals.errors = e.message;
    ResponseHandler.JSONERROR(req, res);
  }
});

//sso jwt token based data

//micor services changes start in TS
//app.use("/api/v1", router1);
app.use("/api/v2", router2);

//micor services changes end in TS

let server = createServer(app).listen(port, "127.0.0.1", 511, () => {
  console.log(`Server is listening on ${port}`);
});

function getFormattedTimestamp() {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0"); // Months are zero-based
  const day = String(now.getDate()).padStart(2, "0");
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");

  return `${year}_${month}_${day}_${hours}_${minutes}_${seconds}`;
}
