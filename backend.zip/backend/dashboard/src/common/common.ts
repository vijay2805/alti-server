export const HTTP_METHODS = {
    GET: "get",
    POST: "post",
    PUT: "put",
    PATCH: "patch",
    DELETE: "delete",
  };

  export const REQUEST_TYPES = {
    JSON: "json",
    FORMDATA: "form-data",
  };

  export const ROLES = {
    SUPER_ADMIN: 1,
    ADMIN: 2,
    EMPLOYEE: 4,
    CUSTOMER: 5,
    USER:7
  };