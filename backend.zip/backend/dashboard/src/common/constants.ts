const Messages = {
  NO_DATA: "No data found",
  FETCHED: "Data feteched Successfully",
  UPDATED: "Updated Successfully",
  SOMETHING_WENT_WRONG: "Something went wrong",
  SAVED: "Saved Succesfully",
  DELETED: "Deleted Succesfully",
  SHORTNAME_ALREADY_EXIST: "Short name already exist",
  PROJECT_ALREADY_EXIST: "Project already in Use",
  SESSION_DOES_NOT_EXIST: "Session Does not exist",
  INVALID_JWT: "Invalid Token",
  UPLOADED: "Data uploaded",
};
export default Messages;
