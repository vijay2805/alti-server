import * as jwt from "jsonwebtoken";
const secretKey='qwerty';
export const generateJWT = (payload: any) => {
    const token = jwt.sign(
      {
        id: payload.userId,
        emailid: payload.email,
      },
      secretKey,
      {},
      { expiresIn: "24h" }
    );
    return token;
  };