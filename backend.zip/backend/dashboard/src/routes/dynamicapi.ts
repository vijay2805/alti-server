import express from "express";
import DynamicAPIController from "../controllers/dynamicapi.controller";
const router = express.Router();

router.post("/DynamicAPIData", DynamicAPIController.DynamicAPIData);

export default router;
