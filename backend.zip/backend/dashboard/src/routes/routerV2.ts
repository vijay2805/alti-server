import express from "express";
const router = express.Router();

import connectorsService from "../services/connectorServiceV2";
import rgspyService from "../services/rgspyServiceV2";
import flowbuilderService from "../services/flowbuilderServiceV2";
import metricsService from "../services/metricsServiceV2";

router.use((req, res, next) => {
    next();
})


router.use(connectorsService);
router.use(rgspyService);
router.use(flowbuilderService);
router.use(metricsService);
export default router;
