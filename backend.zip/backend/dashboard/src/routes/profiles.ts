import express from 'express'
import profileController from '../controllers/profile.controller'

const router = express.Router()

router.post('/', profileController.addProfile)
router.get('/',profileController.getAllProfile)
router.get('/:id',profileController.getProfileById);
router.patch('/:id', profileController.UpdateProfile);
export default router
