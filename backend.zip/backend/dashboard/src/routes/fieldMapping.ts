import express from 'express'
import fieldMappingController from '../controllers/fieldMapping_controller'

const router = express.Router()

router.post('/',fieldMappingController.addFieldMapping);
router.patch('/:id',fieldMappingController.updateFieldMapping);

export default router
