import express from "express";
import menuController from "../controllers/menu.controllers";
const router = express.Router();

router.get('/', menuController.getallMenus);
router.get('/projects/:project_id', menuController.getMenuByProjectId);

export default router;