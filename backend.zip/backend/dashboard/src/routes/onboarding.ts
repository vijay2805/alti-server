import express from 'express'
import onboardingController from '../controllers/onboarding.controller'

const router = express.Router()

router.post('/login', onboardingController.getonboardingByUserName)

router.post('/verify-qrcode', onboardingController.user_qr_verify)

router.patch('/user-reset-qrcode/:id', onboardingController.user_resetQr)

router.patch('/:id', onboardingController.updateonboarding)
router.patch('/reset-pwd/:id', onboardingController.resetPassword_onboarding)
export default router
