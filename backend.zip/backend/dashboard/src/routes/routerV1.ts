import express from "express";
const router = express.Router();

import connectorsService from "../services/connectorServiceV1";
import rgspyService from "../services/rgspyServiceV1";
import metricsSerice from "../services/metricsSericeV1";

router.use((req, res, next) => {
    next();
})


router.use(connectorsService);
router.use(rgspyService);
router.use(metricsSerice);
export default router;