import express from "express";
import { Request, Response } from 'express';
import dynamic_crud_api_controller from "../controllers/dynamic_crud_api_controller";
import * as ResponseHandler from "../helpers/response.handler";
const router = express.Router();

router.post('/', dynamic_crud_api_controller.dynamic_crud_api);
router.use('*', (req: Request, res: Response) => {
    res.locals.message = 'NO Routes Found in API.';
    ResponseHandler.JSONERROR(req, res);

});
export default router;