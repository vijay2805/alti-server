import express from 'express'
import connectorsController from '../controllers/connectors.controller'

const router = express.Router()

router.post('/', connectorsController.addConnector);
router.get('/',connectorsController.getAllConnector)
router.get('/:id',connectorsController.getConnectorById);
router.patch('/:id', connectorsController.UpdateConnector);
export default router