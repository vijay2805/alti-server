import express from 'express'
import objectMappingController from '../controllers/objectMapping_controller'

const router = express.Router()

router.post('/',objectMappingController.addObjectMapping);
router.patch('/:id',objectMappingController.updateObjectMapping);

export default router
