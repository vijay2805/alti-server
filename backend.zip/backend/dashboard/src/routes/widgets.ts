import express from "express";
import widgetController from "../controllers/widget.controllers";
const router = express.Router();

router.get('/', widgetController.getallWidgets);
router.get('/:widget_ids', widgetController.getallWidgetsById);
router.get('/menus/:menu_id', widgetController.getallWidgetsByMenuIds);
router.post('/menus', widgetController.getallWidgetsByMenuIdsNew);

export default router;