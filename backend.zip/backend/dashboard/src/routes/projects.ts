import express from "express";
import projectController from "../controllers/projects.controllers";
const router = express.Router();

router.get('/', projectController.getallProjects);

export default router;