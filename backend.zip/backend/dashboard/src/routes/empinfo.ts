import express from 'express'
import empinfoController from '../controllers/empinfo.controller'

const router = express.Router()



router.get('/:id',empinfoController.getEmpinfoById);

export default router
