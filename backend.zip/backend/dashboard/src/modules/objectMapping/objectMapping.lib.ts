import objectMapping from '../../models/objectMapping'

export const addObjectMapping = async (obj) => {
    const result = await objectMapping.create(obj);
    return result;
  };

  export const getObjectMappingById = async condition => {
    const result = await objectMapping.findOne({
      where: condition
    })
    return result
}


export const updateObjectMapping = async (condition, obj) => {
  const result = await objectMapping.update(obj, { where: condition });
  return result;
};


export const getallObjectMappings = async condition => {
  const result = await objectMapping.findAll({
    where: condition,
    order: [['object_id', 'DESC']]
  })
  return result
}