import onboarding from "../../models/onboarding";
export const getallonboarding = async (condition) => {
  const result = await onboarding.findAll({
    where: condition,
    order: [["user_id", "DESC"]],
  });
  return result;
};

export const getonboardingByUser = async (condition) => {
  const result = await onboarding.findOne({
    where: condition,
  });
  return result;
};



export const updateonboarding = async (condition: any, obj: any) => {
  const result = await onboarding.update(obj, {
    where: condition,
  });
  return result;
};

export const getonboardingById = async (condition) => {
  const result = await onboarding.findOne({
    where: condition,
  });
  return result;
};

