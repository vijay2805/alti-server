import Profile from '../../models/profile'

export const addProfile = async (obj) => {
    const result = await Profile.create(obj);
    return result;
  };
  export const updateProfile = async (condition, obj) => {
    const result = await Profile.update(obj, { where: condition });
    return result;
  };
export const getallProfiles = async condition => {
  const result = await Profile.findAll({
    where: condition,
    order: [['profile_id', 'DESC']]
  })
  return result
}

export const getProfileById = async condition => {
    const result = await Profile.findOne({
      where: condition
    })
    return result
}




