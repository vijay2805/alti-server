import Connector from '../../models/connectors'

export const addConnector = async (obj) => {
    const result = await Connector.create(obj);
    return result;
  };
  export const updateConnector = async (condition, obj) => {
    const result = await Connector.update(obj, { where: condition });
    return result;
  };
export const getallConnectors = async condition => {
  const result = await Connector.findAll({
    where: condition,
    order: [['connector_id', 'DESC']]
  })
  return result
}

export const getConnectorById = async condition => {
    const result = await Connector.findOne({
      where: condition
    })
    return result
}