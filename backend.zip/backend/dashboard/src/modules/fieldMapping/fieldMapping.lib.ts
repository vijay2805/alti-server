import fieldMapping from '../../models/fieldMapping'

export const addFieldMapping = async (obj) => {
    const result = await fieldMapping.create(obj);
    return result;
  };

  export const getFieldMappingById = async condition => {
    const result = await fieldMapping.findOne({
      where: condition
    })
    return result
}


export const updateFieldMapping = async (condition, obj) => {
  const result = await fieldMapping.update(obj, { where: condition });
  return result;
};


export const getallFieldMappings = async condition => {
  const result = await fieldMapping.findAll({
    where: condition,
    order: [['field_id', 'DESC']]
  })
  return result
}