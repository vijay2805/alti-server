import { Request, Response, NextFunction, HttpException } from "express";
import xss from "xss";
import * as jwt from "jsonwebtoken";
import * as HttpStatus from "http-status-codes";
import * as dotenv from "dotenv";
import * as ResponseHandler from "../helpers/response.handler";
import * as EnvHandler from "../helpers/environment.handler";
import * as onboardingLib from '../modules/onboarding/onboarding.lib'

import { Op, Sequelize } from "sequelize";
import Messages from "../common/constants";

// import APIErrorLogger from "./apilogger";

dotenv.config();

/**
 * Validate JWT token
 * @param req
 * @param res
 * @param next
 */
export const validateHeaders = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const auth_key = req.headers['auth_key']
    if (auth_key === '&^%$#@!$') {
      next();
      }else {
        res.locals.errorCode = HttpStatus.UNAUTHORIZED;
        res.locals.message = "Invalid Headers!!";
        ResponseHandler.JSONERROR(req, res);
      }
    
  } catch (e) {
    res.locals.errorCode = HttpStatus.UNAUTHORIZED;
    res.locals.errors = "An error occurred!";
    ResponseHandler.JSONERROR(req, res);
  }
};

export const validateJwt = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
   
      // Get the jwt token from the headers
      const token = <string>req.headers["x-access-token"];
      const jwtSecret = EnvHandler.envJWT_SECRET();
      let payload;
      // Validate the token
      payload = <any>jwt.verify(token, jwtSecret);

      // get logged in user details from db
      req.loggedInUser = payload.userId || payload.userId;
    
      req.email = payload.email;
 
      req.token = token;

      let active_session: any = {};
   
        active_session = await onboardingLib.getonboardingByUser({
            user_id: payload.userId,
          active_token: token,
        });
     
      if (active_session) {
        
        next();
      } else {
       
        res.locals.errorCode = HttpStatus.UNAUTHORIZED;
        res.locals.message = Messages.SESSION_DOES_NOT_EXIST;
        ResponseHandler.JSONERROR(req, res);
      }
    
  } catch (e) {
    const protocol = req.protocol;
    const host = req.hostname;
    const url = req.originalUrl;
    const port = process.env.PORT;

    const fullUrl = `${protocol}://${host}:${port}${url}`;
    // APIErrorLogger.error(
    //   `${e}, Request : ${fullUrl}, Method:${req.method}`
    // );
    res.locals.errorCode = HttpStatus.UNAUTHORIZED;
    res.locals.errors = "An error occurred!";
    ResponseHandler.JSONERROR(req, res);
  }
};

export const sanitizeRequest = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Sanitize query parameters
  if (req.query) {
    for (const key in req.query) {
      if (typeof req.query[key] === 'string' && Object.prototype.hasOwnProperty.call(req.query, key)) {
        req.query[key] = xss(req.query[key]);
      }
    }
  }

  // Sanitize body parameters
  if (req.body) {
    for (const key in req.body) {
      if (typeof req.body[key] === 'string' && Object.prototype.hasOwnProperty.call(req.body, key)) {
        req.body[key] = xss(req.body[key]);
      }
    }
  }

  // You can extend this to sanitize other input sources as well, like headers

  next();
};
