import winston from "winston";
import * as path from "path";
import moment from "moment";
const DailyRotateFile = require("winston-daily-rotate-file");
const levels = {
  error: 0,
  warn: 1,
  info: 2,
  http: 3,
  debug: 4,
};

const level = () => {
  const env = process.env.NODE_ENV || "prod";
  const isDevelopment = env === "prod";
  return isDevelopment ? "debug" : "warn";
};

const colors = {
  error: "red",
  warn: "yellow",
  info: "green",
  http: "magenta",
  debug: "white",
};

winston.addColors(colors);

const format = winston.format.combine(
  // winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
  // winston.format.timestamp({
  //   format: moment().format("YYYY-MM-DD hh:mm:ss").trim(),
  // }),
  //   winston.format.colorize({ all: true }),
  
  winston.format.printf(
    (info: any) => `${info.level}: ${info.message}`
  ),
  winston.format.json(),
  // winston.format.prettyPrint()
);

var transport = new DailyRotateFile({
  filename: "api-errors-%DATE%.log", //'application-%DATE%.log',
  dirname: path.join(__dirname, `./../../../../../public/logs`),
  format: format,
  datePattern: "YYYY-MM-DD-HH",
  zippedArchive: false,
  maxSize: "1g",
  maxFiles: 24,
});

const transports = [
  //   new winston.transports.Console(),
  transport,
  //   new winston.transports.File({
  //     filename: path.join(__dirname, `./../../../../../public`, "sjolog1.log"),
  //     format: winston.format.json()
  //   }),
];

const APIErrorLogger = winston.createLogger({
  //   level: level(),
  //   defaultMeta: { component: "system-analytics" },
  levels,
  format,
  transports,
});

export default APIErrorLogger;
