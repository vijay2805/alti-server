import { Request, Response } from 'express'
import { sanitizeAndValidateObj } from '../utility/sanitizeAndValidateDate'
import Messages from '../common/constants'
import * as ResponseHandler from '../helpers/response.handler'
import { APIEngineDBConnection } from '../config/connection'
import axios from 'axios'
import { Sequelize, QueryTypes } from 'sequelize'

class widgetController {
  
  static getallWidgetsById = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const widget_ids = req?.params?.widget_ids;
      let data: any = []
      data = await APIEngineDBConnection.query(
        `SELECT * from public.rg_widget_config order by widget_id in (${widget_ids})`,//limit 4;
        {
          type: QueryTypes.SELECT
        }
      )
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  static getallWidgets = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      console.log('calling getallWidgets')
      let data: any = []
      data = await APIEngineDBConnection.query(
        `SELECT * from public.rg_widget_config order by widget_id desc`,//limit 4;
        {
          type: QueryTypes.SELECT
        }
      )
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  static getallWidgetsByMenuIds = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const menu_id = req?.params?.menu_id;
      let data: any = [];
      let component_data:any=[];
      let menu_data:any=[];
      let widgetArray:any=[];
      component_data = await APIEngineDBConnection.query(
        `SELECT * from public.rg_menu_config where menu_id in (${menu_id});`,
        {
          type: QueryTypes.SELECT
        }
      );
      if(component_data&& component_data.length>0){
        const query2 = `SELECT * FROM public.rg_component_config WHERE component_id IN (${component_data?.map((row) => row.menu_component_id).join(",")})`;
        menu_data =  await APIEngineDBConnection.query(
          query2,
          {
            type: QueryTypes.SELECT
          }
        );
      }
      
      menu_data && menu_data.length>0 && await menu_data?.forEach((x) => {
        // console.log(x.component_json?.dashboard_widgets);
        const data=x.component_json?.dashboard_widgets?x.component_json?.dashboard_widgets:[];
        const widgetIds = data.flatMap(widgets =>
          widgets.widgets_x.map(widget => widget.widget)
        );
        // console.log("Widget IDs:", widgetIds); 
        widgetArray = [...widgetArray, ...widgetIds];
        // console.log("widgetArray=", widgetArray);
    });
    // Create distinctWidgetArray
    const distinctWidgetArray = [...new Set(widgetArray)];
    if(distinctWidgetArray && distinctWidgetArray.length>0){
      const query3=`SELECT widget_id,widget_name FROM public.rg_widget_config WHERE widget_id IN (${distinctWidgetArray.join(",")})`;
      // console.log("distinctWidgetArray menu_data", distinctWidgetArray);
      data=await APIEngineDBConnection.query(
        query3,
        {
          type: QueryTypes.SELECT
        }
      );
    }
      // return false;
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  static getallWidgetsByMenuIdsNew = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const menu_id = req?.body;
      let data: any = [];
      let component_data: any = [];
      let menu_data: any = [];
      let widgetArray: any = [];
      // await Promise.all(menu_id.map(async (menuId) => {
      //   component_data = await APIEngineDBConnection.query(
      //     `SELECT * from public.rg_menu_config where menu_id = ${menuId};`,
      //     {
      //       type: QueryTypes.SELECT
      //     }
      //   );
      //   if (component_data && component_data.length > 0) {
      //     const obj = {
      //       label: component_data[0]['menu_name'],
      //       options: []
      //     };
      
      //     const comp_id = component_data[0]['menu_component_id'];
      //     menu_data = await APIEngineDBConnection.query(
      //       `SELECT * FROM public.rg_component_config WHERE component_id=${comp_id}`,
      //       {
      //         type: QueryTypes.SELECT
      //       }
      //     );
      
      //     menu_data && menu_data.length > 0 && await Promise.all(menu_data.map(async (x) => {
      //       const data = x.component_json?.dashboard_widgets ? x.component_json?.dashboard_widgets : [];
      //       const widgetIds = data.flatMap(widgets => widgets.widgets_x.map(widget => widget.widget));
      //       widgetArray = [...widgetArray, ...widgetIds];
      //     }));
      
      //     const distinctWidgetArray = [...new Set(widgetArray)];
      //     await Promise.all(distinctWidgetArray.map(async (index) => {
      //       let rg_widget_config_res = await APIEngineDBConnection.query(
      //         `SELECT widget_id,widget_name FROM public.rg_widget_config WHERE widget_id=${index}`,
      //         {
      //           type: QueryTypes.SELECT,
      //         }
      //       );
      //       if (rg_widget_config_res && rg_widget_config_res.length > 0) {
      //         obj.options.push(...rg_widget_config_res);
      //       }
      //     }));
      
      //     data.push(obj);
      //   }
      // }));
      await Promise.all(menu_id.map(async (menuId) => {
        const widgetArray = []; // Reset widgetArray for each menuId
        component_data = await APIEngineDBConnection.query(
            `SELECT * from public.rg_menu_config where menu_id = ${menuId};`,
            {
                type: QueryTypes.SELECT
            }
        );
        if (component_data && component_data.length > 0) {
            const obj = {
                label: component_data[0]['menu_name'],
                options: []
            };
    
            const comp_id = component_data[0]['menu_component_id'];
            menu_data = await APIEngineDBConnection.query(
                `SELECT * FROM public.rg_component_config WHERE component_id=${comp_id}`,
                {
                    type: QueryTypes.SELECT
                }
            );
    
            if (menu_data && menu_data.length > 0) {
                for (const x of menu_data) {
                    // const data = x.component_json?.dashboard_widgets ? x.component_json?.dashboard_widgets : [];
                    // const widgetIds = data.flatMap(widgets => widgets.widgets_x.map(widget => widget.widget));
                    // widgetArray.push(...widgetIds);

                    //new logic start
                     const data = x.component_json ? x.component_json : [];
                     await data.map(widget => widgetArray.push(widget.i));
                    // return false;
                  //new
                }
    
                const distinctWidgetArray = [...new Set(widgetArray)];
                await Promise.all(distinctWidgetArray.map(async (index) => {
                    let rg_widget_config_res = await APIEngineDBConnection.query(
                        `SELECT widget_id,widget_name FROM public.rg_widget_config WHERE widget_id=${index}`,
                        {
                            type: QueryTypes.SELECT,
                        }
                    );
                    if (rg_widget_config_res && rg_widget_config_res.length > 0) {
                        obj.options.push(...rg_widget_config_res);
                    }
                }));
            }
    
            data.push(obj);
        }
    }));
    
      console.log("data==", data);      
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  
}

export default widgetController
