import { Request, Response } from 'express'
import { sanitizeAndValidateObj } from '../utility/sanitizeAndValidateDate'
import Messages from '../common/constants'
import * as ResponseHandler from '../helpers/response.handler'
import axios from 'axios'
import { Sequelize, QueryTypes,Op } from 'sequelize'
import * as objectMappingLib from "../modules/objectMapping/objectMapping.lib";
class fieldMappingController {

  static addObjectMapping=async(req: Request, res: Response)=>{
    let { loggedInUser } = sanitizeAndValidateObj(req.query);
    console.log("loggedInUser==",loggedInUser);
    loggedInUser = loggedInUser ? loggedInUser : 1;
    try {
      const input=req.body;
      console.log("addObjectMapping===input:",input);
    //   return false;
      let data:any=[];
        let inputObjectJson = input.object_id;
        inputObjectJson && inputObjectJson.length > 0 &&
        inputObjectJson.map(async(index: any) => {
            console.log("inputObjectJson",index);
        let isexist:any = await objectMappingLib.getObjectMappingById({
            object_id: index,
            profile_id:input.profile_id,
            customer_id: input.customer_id,
            status:input?.status
            });
            if(!isexist){
                const obj={
                    object_id:index,
                    profile_id:input.profile_id,
                    customer_id: input.customer_id,
                    created_on: new Date(new Date().getTime() + 3600000 * 5.5),
                    created_by:input.created_by?input.created_by:loggedInUser,
                    status:input?.status || "A",
                }
                data.push(objectMappingLib.addObjectMapping(obj));
            }
        });
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }

  static updateObjectMapping=async(req: Request, res: Response)=>{
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const input=req.body;
      const field_id=req.params.id;
    //   console.log("===input:",field_id,input)
    //   return false;
      let data:any=[];
    
    let inputObjectJson = input.object_id;
    inputObjectJson && inputObjectJson.length > 0 &&
        inputObjectJson.map(async(index: any) => {
            let isexist:any = await objectMappingLib.getObjectMappingById({
                object_id: index,
                // profile_id:input.profile_id,
                customer_id: input.customer_id,
                status:input?.status,
                object_profile_id:{[Op.eq]:field_id}
                });
             
              if(isexist){
                //update here data
                const obj={
                    object_id:index,
                    profile_id:input.profile_id,
                    customer_id: input.customer_id,
                    modified_on: new Date(new Date().getTime() + 3600000 * 5.5),
                    modified_by:input.created_by?input.created_by:loggedInUser,
                    status:input?.status || "A",
                }
                data=objectMappingLib.updateObjectMapping({ object_profile_id: field_id },obj);
              }else{
                //insert datta here
                let isexist:any = await objectMappingLib.getObjectMappingById({
                    object_id: index,
                    profile_id:input.profile_id,
                    customer_id: input.customer_id,
                    status:input?.status,
                    // object_profile_id:{[Op.not]:field_id}
                    });
                   
                    if(!isexist){
                        const obj={
                            object_id:index,
                            profile_id:input.profile_id,
                            customer_id: input.customer_id,
                            created_on: new Date(new Date().getTime() + 3600000 * 5.5),
                            created_by:input.created_by?input.created_by:loggedInUser,
                            status:input?.status || "A",
                        }
                       let res_data= objectMappingLib.addObjectMapping(obj);
                       data.push(res_data);
                    }
              }
        });
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
}

export default fieldMappingController
