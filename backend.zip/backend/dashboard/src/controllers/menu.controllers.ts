import { Request, Response } from 'express'
import { sanitizeAndValidateObj } from '../utility/sanitizeAndValidateDate'
import Messages from '../common/constants'
import * as ResponseHandler from '../helpers/response.handler'
import { APIEngineDBConnection } from '../config/connection'
import axios from 'axios'
import { Sequelize, QueryTypes } from 'sequelize'

class menuController {
  static getallMenus = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      console.log('calling getallMenus')
      let data: any = []
      data = await APIEngineDBConnection.query(
        `SELECT * from public.rg_menu_config;`,
        {
          type: QueryTypes.SELECT
        }
      )
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  static getMenuByProjectId = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const project_id = req?.params?.project_id;
      let data: any = []
      data = await APIEngineDBConnection.query(
        `SELECT * from public.rg_menu_config where project_id in (${project_id});`,
        {
          type: QueryTypes.SELECT
        }
      )
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
}

export default menuController
