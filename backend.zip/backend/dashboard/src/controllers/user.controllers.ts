import { Request, Response } from 'express'
import { sanitizeAndValidateObj } from '../utility/sanitizeAndValidateDate'
import Messages from '../common/constants'
import * as ResponseHandler from '../helpers/response.handler'
import { APIEngineDBConnection } from '../config/connection'
import axios from 'axios'
import { Sequelize, QueryTypes } from 'sequelize'

class userController {
  static getallUsers = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      console.log('calling getallWidgets')
      let data: any = []
      data = await APIEngineDBConnection.query(
        `SELECT * from public.rg_cloud_users where status='A';`,
        {
          type: QueryTypes.SELECT
        }
      )
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  
}

export default userController
