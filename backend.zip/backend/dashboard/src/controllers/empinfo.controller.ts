import { Request, Response } from 'express'
import { sanitizeAndValidateObj } from '../utility/sanitizeAndValidateDate'
import Messages from '../common/constants'
import * as ResponseHandler from '../helpers/response.handler'
import axios from 'axios'
import { Sequelize, QueryTypes, Op } from 'sequelize'
import {
  APIEngineDBConnection,
  RgFrameworkDBConnection
} from '../config/connection'
import * as HttpStatus from 'http-status-codes'

class widgetController {
  static getEmpinfoById = async (req: Request, res: Response) => {
    const auth_key = req.headers['auth_key']
    if (auth_key === '&^%$#@!$') {
      let { loggedInUser } = sanitizeAndValidateObj(req.query)
      loggedInUser = loggedInUser ? loggedInUser : 1
      try {
        const emp_id = req.params.id
        console.log('getEmpinfoById', emp_id)
        let data: any = []
        let dataObj: any = {}
        let user_data: any = [] //for email based data
        let role_data: any = []
        let profile_data: any = []
        let object_data: any = []
        let fields_data: any = []
        //user data by email start
        //email based functionality start if email based data not required need to comment it
        user_data = await RgFrameworkDBConnection.query(
          `SELECT * from public.fw_users where email='${emp_id}' and status='A';`,
          {
            type: QueryTypes.SELECT
          }
        )
        console.log('user_data=', user_data)
        //email based functionality end

        if (user_data.length > 0 && user_data[0]['user_id']) {
          const user_id = user_data[0]['user_id']
          //getting role id by employe id start
        role_data = await RgFrameworkDBConnection.query(
          `SELECT * from public.fw_user_role_mapping where user_id=${user_id} and status='A';`,
          {
            type: QueryTypes.SELECT
          }
        );
        if (role_data.length > 0 && role_data[0]['role_id']) {
          const role_id = role_data[0]['role_id'];
          dataObj['role_data'] = role_data;
          profile_data = await RgFrameworkDBConnection.query(
            `SELECT * from public.fw_profiles where role_id=${role_id} and status='A';`,
            {
              type: QueryTypes.SELECT
            }
          );
          if(profile_data.length>0 && profile_data[0]['profile_id']){
            const profile_id = profile_data[0]['profile_id'];
            dataObj['profile_data'] = profile_data;
            object_data = await RgFrameworkDBConnection.query(
              `SELECT * from public.fw_object_profile_mapping where profile_id=${profile_id} and status='A';`,
              {
                type: QueryTypes.SELECT
              }
            );
            // if(object_data.length>0){
            //  let fields_data_res=[];
             let res=  object_data.length>0 && await Promise.all(object_data.map(async(Obj,index) => {

              //for object name start
              const object_id = object_data[index]['object_id']
              let obj_name: any = await RgFrameworkDBConnection.query(
                `SELECT obj_name from public.fw_object_info where obj_id=${object_id};`,
                {
                  type: QueryTypes.SELECT
                }
              )
              // console.log(obj_name);
              // return false;
              //for object name end
              object_data[index]['obj_name'] = obj_name[0]['obj_name'];

                let res_fields:any = await RgFrameworkDBConnection.query(
                  `SELECT * from public.fw_object_field_mapping where object_id=${Obj.object_id} and status='A';`,
                  {
                    type: QueryTypes.SELECT
                  }
                );
                return  Obj['fields_data']=res_fields;
              }));
              dataObj['object_data'] = object_data;
              // console.log(res);
              // dataObj['fields_data'] = res;
            // }else{
            //   throw new Error("Object Doesn't Exists for the user")
            // }
          }else{
            throw new Error("Profile Doesn't Exists for the user")
          }
        }else{
          throw new Error("Role Doesn't Exists for the user")
        }
        //end
        }else{
          throw new Error("User Doesn't Exists")
        }
        data.push(dataObj)
        res.locals.data = data
        ResponseHandler.JSONSUCCESS(req, res)
      } catch (e) {
        res.locals.errors = e.message
        ResponseHandler.JSONERROR(req, res)
      }
    } else {
      res.locals.errorCode = HttpStatus.UNAUTHORIZED
      res.locals.message = 'Invalid Headers'
      ResponseHandler.JSONERROR(req, res)
    }
  }
}

export default widgetController
