import { Request, Response } from 'express'
import { sanitizeAndValidateObj } from '../utility/sanitizeAndValidateDate'
import Messages from '../common/constants'
import * as ResponseHandler from '../helpers/response.handler'
import axios from 'axios'
import { Sequelize, QueryTypes, Op } from 'sequelize'
import * as fieldMappingLib from '../modules/fieldMapping/fieldMapping.lib'
class fieldMappingController {
  static addFieldMapping = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    console.log('loggedInUser==', loggedInUser)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const input = req.body
      console.log('===input:', input)
      let data: any = []
      let isexist: any = await fieldMappingLib.getFieldMappingById({
        object_id: input.object_id
      })

      if (isexist) {
        throw new Error('Module Already Mapped')
      } else {
        let inputFieldJson = input.field_info
        inputFieldJson &&
          inputFieldJson.length > 0 &&
          inputFieldJson.map((item: any) => {
            let readable = 0
            let editable = 0
            let deletable = 0
            if (item.type == 1) {
              readable = 1
            } else if (item.type == 2) {
              readable = 1
              editable = 1
            } else if (item.type == 3) {
              deletable = 1
            }

            const obj = {
              field_name: item?.fieldName,
              object_id: input.object_id,
              readable: readable,
              editable: editable,
              deletable: deletable,
              created_on: new Date(new Date().getTime() + 3600000 * 5.5),
              created_by: input.created_by ? input.created_by : loggedInUser,
              customer_id: input.customer_id,
              status: input?.status || 'A'
            }
            data.push(fieldMappingLib.addFieldMapping(obj))
          })
      }
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }

  static updateFieldMapping = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const input = req.body
      const field_id = req.params.id
      //   console.log("===input:",field_id,input)
      //   return false;
      let data: any = []

      let inputFieldJson = input.field_info
      inputFieldJson &&
        inputFieldJson.length > 0 &&
        inputFieldJson.map(async (item: any) => {
          let isexist: any = await fieldMappingLib.getFieldMappingById({
            object_id: input.object_id,
            field_id: field_id,
            field_name: { [Op.eq]: item?.fieldName }
          })
          let readable = 0
          let editable = 0
          let deletable = 0
          if (item.type == 1) {
            readable = 1
          } else if (item.type == 2) {
            readable = 1
            editable = 1
          } else if (item.type == 3) {
            deletable = 1
          }
          console.log(isexist)
          if (isexist) {
            //update here data
            const obj = {
              field_name: item?.fieldName,
              object_id: input.object_id,
              readable: readable,
              editable: editable,
              deletable: deletable,
              modified_on: new Date(new Date().getTime() + 3600000 * 5.5),
              modified_by: input.created_by ? input.created_by : loggedInUser,
              customer_id: input.customer_id,
              status: input?.status || 'A'
            }
            data = fieldMappingLib.updateFieldMapping(
              { field_id: field_id },
              obj
            )
          } else {
            //insert datta here
            if (item?.fieldName) {
              const obj = {
                field_name: item?.fieldName,
                object_id: input.object_id,
                readable: readable,
                editable: editable,
                deletable: deletable,
                created_on: new Date(new Date().getTime() + 3600000 * 5.5),
                created_by: input.created_by ? input.created_by : loggedInUser,
                customer_id: input.customer_id,
                status: input?.status || 'A'
              }
              // data.push();
              let res_data = fieldMappingLib.addFieldMapping(obj)
              data.push(res_data)
            }
          }
        })
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
}

export default fieldMappingController
