import { Request, Response } from 'express'
import { sanitizeAndValidateObj } from '../utility/sanitizeAndValidateDate'
import Messages from '../common/constants'
import * as ResponseHandler from '../helpers/response.handler'
import axios from 'axios'
import { Sequelize, QueryTypes, Op } from 'sequelize'
import * as connectorsLib from '../modules/connectors/connectors.lib'
class connectorController {
  static addConnector = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const input = req.body
      // console.log("addConnector called,input==",input);
      if (input && input.connector_name) {
        //check duplicates adding
        let isexist: any = await connectorsLib.getConnectorById({
          connector_name: input?.connector_name
        })
        let data: any = []
        if (isexist) {
          throw new Error('Connector Name Alrady Exists')
        } else {
          //loop here roles
          // console.log("addConnector called",input);
          let obj = {
            connector_name: input?.connector_name,
            connector_desc: input?.connector_desc,
            connector_info: input?.connector_info,
            created_on: new Date(new Date().getTime() + 3600000 * 5.5),
            created_by: input?.created_by || loggedInUser,
            status: input?.status || 'A'
          }
          data = await connectorsLib.addConnector(obj)
        }
        //enc
        res.locals.data = data
        res.locals.message = 'Connector Created Successfully'
        ResponseHandler.JSONSUCCESS(req, res)
      } else {
        throw new Error('Please Provide Connector Name')
      }
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  static getConnectorById = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const connector_id = req.params.id
      let data: any = []
      data = await connectorsLib.getConnectorById({
        connector_id: connector_id
      })
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }

  static getAllConnector = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      let data: any = []
      data = await connectorsLib.getallConnectors({})
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }

  static UpdateConnector = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const connector_id = req.params.id
      const input = req.body
      if (input && input.connector_name) {
        //check duplicates adding
        let isexist: any = await connectorsLib.getConnectorById({
          connector_name: input.connector_name,
          connector_id: { [Op.not]: connector_id }
        })
        let data: any = []
        if (isexist) {
          throw new Error('Connector Name Alrady Exists')
        } else {
          let obj = {
            connector_name: input?.connector_name,
            connector_desc: input?.connector_desc,
            connector_info: input?.connector_info,
            modified_on: new Date(new Date().getTime() + 3600000 * 5.5),
            modified_by:input?.modified_by || loggedInUser,
            status:input?.status,
          }
          data=await connectorsLib.updateConnector({ connector_id: connector_id },obj);
        }
        //enc
        res.locals.data = data
        ResponseHandler.JSONSUCCESS(req, res)
      } else {
        throw new Error('Please Provide Connector Name')
      }
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
}

export default connectorController
