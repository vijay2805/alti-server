import { Request, Response } from 'express'
import { sanitizeAndValidateObj } from '../utility/sanitizeAndValidateDate'
import Messages from '../common/constants'
import * as ResponseHandler from '../helpers/response.handler'
import { APIEngineDBConnection } from '../config/connection'
import axios from 'axios'
import { Sequelize, QueryTypes,Op } from 'sequelize'
import * as profileLib from "../modules/profiles/profile.lib";
class widgetController {
  static addProfile = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
        const input=req.body;
      //check duplicates adding
      let isexist:any = await profileLib.getProfileById({
        profile_name: input.profile_name,
        status:{ [Op.not]:"D" }
      });
      let data: any = [];
      if (isexist){
        throw new Error("Profile Name Alrady Exists");
      }else{
        //loop here roles
        await input.role_id.map(async(id)=>{
            let isexist:any = await profileLib.getProfileById({
                // profile_name: input.profile_name,
                role_id: id,
                status:{ [Op.not]:"D" }
              });
              if(!isexist){
                const obj={
                    profile_name:input?.profile_name,
                    role_id:id,
                    customer_id:input?.customer_id,
                    clients_info:"",
                    project_info:input?.project_info,
                    menu_info:input?.menu_info,
                    widget_info:input?.widget_info,
                    created_on: new Date(new Date().getTime() + 3600000 * 5.5),
                    created_by:input?.created_by || loggedInUser,
                    status:input?.status || "A",
                }
                data=profileLib.addProfile(obj);
              }
        });
      }
      //enc
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  static getAllProfile=async(req: Request, res: Response)=>{
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      let data: any = [];
      data=await profileLib.getallProfiles({
        created_by: loggedInUser,
        status:{ [Op.not]:"D" }
      });
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  static getProfileById=async(req: Request, res: Response)=>{
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const profile_id=req.params.id;
      let data: any = [];
      data=await profileLib.getProfileById({
        profile_id: profile_id,
      });
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  static UpdateProfile = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      const profile_id=req.params.id;
      const input=req.body;
      console.log(input.role_id);
      //check duplicates adding
      // let isexist:any = await profileLib.getProfileById({
      //   profile_name: input.profile_name,
      //   profile_id:{ [Op.not]:profile_id }
      // });
      let data: any = [];
      // if (isexist){
      //   throw new Error("Profile Name Alrady Exists");
      // }else{
        //loop here roles
        await input.role_id.map(async(id)=>{
            let isexist:any = await profileLib.getProfileById({
                // profile_name: input.profile_name,
                role_id: id,
                status:{ [Op.not]:"D" }
              });
              if(isexist){
                const obj={
                    profile_name:input?.profile_name,
                    role_id:id,
                    customer_id:input?.customer_id,
                    clients_info:"",
                    project_info:input?.project_info,
                    menu_info:input?.menu_info,
                    widget_info:input?.widget_info,
                    modified_on: new Date(new Date().getTime() + 3600000 * 5.5),
                    modified_by:input?.modified_by || loggedInUser,
                    status:input?.status,
                }
                data=profileLib.updateProfile({ profile_id: profile_id },obj);
              }else{
                  const obj={
                    profile_name:input?.profile_name,
                    role_id:id,
                    customer_id:input?.customer_id,
                    clients_info:"",
                    project_info:input?.project_info,
                    menu_info:input?.menu_info,
                    widget_info:input?.widget_info,
                    created_on: new Date(new Date().getTime() + 3600000 * 5.5),
                    created_by:loggedInUser,
                    status:input?.status || "A",
                }
                data=profileLib.addProfile(obj);
              }
        });
      // }
      //enc
      res.locals.data = data
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
  
}

export default widgetController
