import { Request, Response } from "express";
import * as ResponseHandler from "../helpers/response.handler";
import connection, { RgFrameworkDBConnection } from "../config/connection";
import { object } from "joi";
import { log } from "console";
const { QueryTypes } = require("sequelize");
import axios from "axios";

class dynamic_crud_api_controller {
  static dynamic_crud_api = async (req: Request, res: Response) => {
    let body_params: any = req?.body;
    let finalResult: any;
    let req_method = body_params?.request_method;
    let db_table = body_params?.db_table;
    let db_schema = body_params?.db_schema;
    let dbTableData = await getTableData(db_table, db_schema);
    let req_body = body_params?.request_body;
    let required_fields_all = [];
    let allFields = [];
    let fullDataSchema = [];

    console.log("dbTableData", dbTableData)
    
    for (let data of dbTableData) {
     
      required_fields_all.push(data?.column_name);
     
      allFields.push(data?.column_name);
      fullDataSchema.push({
        columnName: data?.column_name,
        dataType: data?.data_type,
      });
    }
    let primary_key = allFields[0];
    let full_data_schema: any = fullDataSchema.slice(1);
    let required_fields: any = required_fields_all.slice(1);
    let db_data = {
      db_table: db_table,
      db_schema: db_schema,
    };
    let duplicateValues: any = false;
    if (body_params?.unique_constraint?.length > 0) {
      // unique_constraint
      let res_constraint: any = await unique_constraint(
        body_params,
        req_body,
        db_data,
        primary_key
      );
console.log("res_constraint==",res_constraint);
      if (res_constraint?.length !== 0) {
        duplicateValues = true;
      }
    }
    if (req_method == "POST") {
      if (duplicateValues == false) {
        finalResult = await createNewRecord(
          db_data,
          required_fields,
          allFields,
          req_body,
          full_data_schema
        );
      } else {
        finalResult = {
          status: 400,
          message: "unique_constraint condition fail",
        };
      }
    } else if (req_method == "GET") {
      let param_value: any;
      if (body_params?.params) {
        param_value = body_params?.params;
      } else {
        param_value = "";
      }

      finalResult = await getRecords(db_data, param_value, primary_key);
    } else if (req_method == "PATCH") {
      if (duplicateValues == false) {
        finalResult = await updateRecords(db_data, body_params);
      } else {
        finalResult = {
          status: 400,
          message: "unique_constraint condition fail",
        };
      }
    } else if (req_method == "DELETE") {
      finalResult = await updateRecords(db_data, body_params);
    }
     // console.log("++finalResult", finalResult);
      // return false;

    res.locals.data = finalResult;
    res.locals.message = finalResult?.message;
    res.locals.errors = finalResult?.errors;
    if (finalResult?.status == 400) {
      ResponseHandler.DYNAMICJSONERROR(req, res);
    } else {
      ResponseHandler.JSONSUCCESS(req, res);
    }
  };
}

const getTableData = async (tableName: any, db_schema: any) => {
  let data: any = {};
  data = await RgFrameworkDBConnection.query(
    ` select *
        from INFORMATION_SCHEMA.COLUMNS s where table_schema='${db_schema}' and table_name ='${tableName}'`,
    {
      type: QueryTypes.SELECT,
    }
  );
  return data;
};

const createNewRecord = async (
  db_data: any,
  required_fields: any,
  allFields: any,
  reqBody: any,
  full_data_schema: any
) => {
  let data: any = {};
  let rq_fields;
  try {
    let req_body = reqBody;

    let newCloumn = [];
    let keys = Object.keys(reqBody);
    let check_keys = true;
    keys.map((v, i) => {
      let check = allFields.includes(v);
      if (!check) {
        newCloumn.push(v);
        check_keys = false;
        return;
      }
    });

    if (check_keys == true) {
      let values = [];
      let keys = [];
      for (const [key, value] of Object.entries(reqBody)) {
        keys.push(key);
        values.push(`'${value}'`);
      }

      data = await RgFrameworkDBConnection.query(
        `insert into ${db_data.db_schema}.${db_data.db_table} (${keys}) values(${values})
                RETURNING *`,
        {
          type: QueryTypes.INSERT,
        }
      );
      //return data;
    } else {
      data = {
        message: `${newCloumn} cloumn name doesn't exist`,
      };
    }
  } catch (error) {
    data = error?.errors;
    data["message"] = error?.errors[0]?.message;
    data["errors"] = error?.errors;
    data["status"] = 400;
  }
  return data;
};

const getRecords = async (db_data: any, params: any, primary_key: any) => {
  console.log("getRecords=",db_data,params,primary_key);
  let data: any = {};
  let cond: any = "";
  if (Object.keys(params).length !== 0) {
    cond = " where ";
    let Keys = Object.keys(params);
    let lastKey = Keys[Keys.length - 1];
    for (const [key, value] of Object.entries(params)) {
      let addCond = "";

      if (key === lastKey) {
        addCond = "";
      } else {
        addCond = "AND";
      }
      if(db_data.db_table=='Inquery' && key=='in_ids'){
        cond += ` ${key} in (${value})`;
      }
      else if(db_data.db_table=='fw_roles' && key=='parent_role_id'){
        console.log("key, value",key,value);
        if(value===true){
          cond += ` ${key} <> 0`;
        }else{
          cond += ` ${key} = 0`;
        }
        
      }
      else{
        cond += ` ${key} = '${value}'`;
      }
      
      cond += ` ${addCond} `;
    }
  }
  console.log("cond==",cond);
  data = await RgFrameworkDBConnection.query(
    `select * from ${db_data.db_schema}.${db_data.db_table} ${cond} order by ${primary_key} DESC`,
    {
      type: QueryTypes.SELECT,
    }
  );
  return data;
};

const updateRecords = async (db_data: any, body_params: any) => {
  let setData = [];
  for (const [key, value] of Object.entries(body_params?.request_body)) {
    if(value == null){
      setData.push(`${key} = ${value}`);
    }else{
      setData.push(`${key} = '${value}'`);
    }
  }
  let cond: any = "";
  for (const [key, value] of Object.entries(body_params?.params)) {
    cond = `where ${key} = '${value}'`;
  }
  let data: any = {};
  try {
    data = await RgFrameworkDBConnection.query(
      `update ${db_data.db_schema}.${db_data.db_table} 
            set ${setData}
            ${cond} returning *`,
      {
        type: QueryTypes.PATCH,
      }
    );
  } catch (error) {
    data = error?.errors;
    data["message"] = error?.errors[0]?.message;
    data["errors"] = error?.errors;
    data["status"] = 400;
  }

  return data;
};

const deleteRecords = async (db_data: any, reqBody: any) => {
  let cond: any = "";
  for (const [key, value] of Object.entries(reqBody)) {
    cond = ` where ${key} = ${value}`;
  }
  let data: any = {};
  data = await RgFrameworkDBConnection.query(
    `delete from ${db_data.db_schema}.${db_data.db_table}
        ${cond}`,
    {
      type: QueryTypes.DELETE,
    }
  );
  return data;
};

// Handling unique_constraint
const unique_constraint = async (
  body_params: any,
  reqBody: any,
  db_data: any,
  primary_key: any
) => {
  const constraint_arr = body_params?.unique_constraint;
  let req_body_keys = [];

  for (let keys of Object.keys(reqBody)) {
    req_body_keys.push(keys);
  }
  let exists_keys: any;
  console.log(req_body_keys);
  console.log(constraint_arr);
  for (let key of constraint_arr) {
    console.log(req_body_keys.includes(key));
    exists_keys = req_body_keys.includes(key);
  }
  console.log(exists_keys);
  let data = {};
  if (exists_keys == true) {
    let where_cond = [];
    let new_where_cond: any;
    var lastElemet = constraint_arr[constraint_arr?.length - 1];
    for (let value of constraint_arr) {
      let cond;
      if (value != lastElemet) {
        cond = `AND`;
      } else {
        cond = ``;
      }
      where_cond.push(`${value} = '${reqBody[value]}'  ${cond}`);
    }

    new_where_cond = where_cond.join(" ");
    let sql = `select * from ${db_data.db_schema}.${db_data.db_table}
    where ${new_where_cond}`;
    if (body_params?.params) {
      //     console.log("true");
      sql += `AND ${primary_key} <> ${body_params?.params[primary_key]}`;
    }
    console.log("++new_where_cond", sql);
    data = await RgFrameworkDBConnection.query(`${sql}`, {
      type: QueryTypes.SELECT,
    });
  } else {
    data = {
      errMsg: "Error",
    };
  }
  return data;
};
export default dynamic_crud_api_controller;
