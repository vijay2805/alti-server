import { Request, Response } from 'express'
import { sanitizeAndValidateObj } from '../utility/sanitizeAndValidateDate'

import Messages from '../common/constants'
import * as ResponseHandler from '../helpers/response.handler'
import * as onboardingLib from '../modules/onboarding/onboarding.lib'
var CryptoJS = require('crypto-js')
import axios from 'axios'
import * as Speakeasy from 'speakeasy'
import * as QRCode from 'qrcode'
import { generateJWT } from '../helpers/auth.handler'
import { ROLES } from '../common/common'
import { Sequelize, QueryTypes } from 'sequelize'
import { RgFrameworkDBConnection } from "../config/connection";

class onboardingController {
  static getonboardingByUserName = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    let twofa_qr_url = ''
    let secret_key = ''
    try {
      const sessionKey = async () => {
        var number = Math.random() // 0.9394456857981651
        number.toString(36) // '0.xtis06h6'
        var id = number.toString(36).substr(2, 9) // 'xtis06h6'

        return id
      }
      const user_name = req.body.username
      let user_pwd = req.body.password
      let userDetail = await onboardingLib.getonboardingByUser({
        username: user_name
      })
      userDetail = JSON.parse(JSON.stringify(userDetail))

      if (userDetail !== null) {
        let passwordDB: any = userDetail?.password_hash
        let decrypted_pwd = await decrypt(passwordDB)
        console.log("decrypted_pwd",decrypted_pwd);
        // userDetail["decrypted_pwd"] = passwordDB;
        if (userDetail.status.trim() == 'A') {
          if (decrypted_pwd == user_pwd) {
            let data: any = {}
            data = userDetail
            const session_key: string = await sessionKey()

            const token: string = generateJWT({
              userId: data?.user_id,
              email: data?.email ? data.email : ''
            })

            const is_twofa_login = 1
            const is_two_fa =
              data['enable_twofa'] && parseInt(data['enable_twofa'])
            if (is_twofa_login === 1) {
              // if 2fa enabled
              if (is_two_fa === 0) {
                const secret: any = await generate2faAuthCode(data['email'])
                twofa_qr_url = secret['qrUrl']
                secret_key = secret['base32']

                // add authcode in db for this user
                let updatedSec = await onboardingLib.updateonboarding(
                  { user_id: data['user_id'] },
                  {
                    twofa_auth_code: secret['base32'],
                    active_session: new Date(
                      new Date().getTime() + 3600000 * 5.5
                    ),
                    active_token: token,
                    is_active_session: 1
                  }
                )
              } else {
                secret_key = data['twofa_auth_code']
              }
            }
 //get rbac data start
 let role_data_sub: any = [];
 let role_data: any = [];

 const customer_id_res=data?.customer_id;
 const user_id_res=data?.user_id;
 role_data_sub = await RgFrameworkDBConnection.query(
   `SELECT * from public.fw_project_rbac_role_mapping where customer_id=${customer_id_res} and user_id=${user_id_res} and status='A';`,
   {
     type: QueryTypes.SELECT
   }
 );
 if(role_data_sub.length>0){
  role_data = await RgFrameworkDBConnection.query(
    `SELECT * from public.fw_project_rbac_role_configuration where customer_id=${role_data_sub[0].customer_id} and role_id=${role_data_sub[0].role_id} and status='A';`,
    {
      type: QueryTypes.SELECT
    }
  );
 }
 
//console.log("role_data=",role_data);
//get settings access start
let settings_data: any = [];
settings_data = await RgFrameworkDBConnection.query(
  `SELECT * from public.fw_settings where customer_id=${customer_id_res} and user_id=${user_id_res} and status='A';`,
  {
    type: QueryTypes.SELECT
  }
);
// console.log("settings_data==",settings_data.length);
// return false;
//get settings access end
 //get frbac data end
            data = {
              verified: true,
              user: {
                ...data,
                name: data.username,
                role_info:role_data,
                rbac_access:settings_data&&settings_data?.length>0?true:false,
                token,
                session_key,
                secret_key,
                staffId: data.user_id,
                is_customer_user: 0,
                check_two_fa: is_two_fa ? true : false,
                is_twofa_enabled: data['enable_twofa'] === 0 ? false : true,
                is_twofa_login: true,
                twofa_qr_url
              }
            }

            if (!data) res.locals.message = Messages.NO_DATA

            res.locals.data = data
            ResponseHandler.JSONSUCCESS(req, res)
          } else {
            res.locals.message = 'User Name Or Password Incorrect'
            ResponseHandler.JSONERROR(req, res)
          }
        } else {
          res.locals.message = 'Inactive User'
          ResponseHandler.JSONERROR(req, res)
        }
      } else {
        res.locals.message = "User Doesn't Exist"
        ResponseHandler.JSONERROR(req, res)
      }
    } catch (e) {
      const input = sanitizeAndValidateObj(req.body)
      let datalog = {
        pagename: 'onboardingController',
        function_name: 'getonboardingById',
        error_message: e,
        req_body: input && JSON.stringify(input),
        req_id: parseInt(req.params.id),
        createddate: new Date(new Date().getTime() + 3600000 * 5.5),
        created_staff_id: loggedInUser
      }
      //await errorlogs.adderrorLog(datalog);
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }

  static user_resetQr = async (req: Request, res: Response) => {
    let { loggedInUser } = sanitizeAndValidateObj(req.query)
    loggedInUser = loggedInUser ? loggedInUser : 1
    try {
      let id = parseInt(req.params.id, 10)

      let twofa_auth_code = req.body.twofa_auth_code
      let enable_twofa = req.body.enable_twofa
      let updated_by = req.body.modified_id
      let update_date = req.body.modified_date

      let updateCondition = {
        twofa_auth_code: twofa_auth_code,
        enable_twofa: enable_twofa,
        updated_by: updated_by,
        update_date: update_date
      }

      let updateuserDetail: any = await onboardingLib.updateonboarding(
        { user_id: id },
        updateCondition
      )
      let condition = {
        user_id: id
      }
      let user_details: any = await onboardingLib.getonboardingByUser(condition)
      user_details = JSON.parse(JSON.stringify(user_details))

      if (!user_details) res.locals.message = Messages.NO_DATA

      res.locals.data = user_details
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      console.log('=====error:', e)
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }

  static user_qr_verify = async (req: Request, res: Response) => {
    try {
      let input = sanitizeAndValidateObj(req.body)

      let secretKey = input.secretkey,
        token = input.token

      // remove session key from user
      const result = await verify2faAuthCode(secretKey, token)
      if (result) {
        //add authcode in db for this user
        let update_cond = {
          twofa_auth_code: secretKey,
          enable_twofa: 1
        }

        let updateUserDetails: any = await onboardingLib.updateonboarding(
          { user_id: input.user_id },
          update_cond
        )

        res.locals.data = { Verified: result }
        res.locals.message = 'Verified'
        ResponseHandler.JSONSUCCESS(req, res)
      } else {
        res.locals.data = { VERIFIED: result }
        res.locals.message = 'Verification Failed'

        ResponseHandler.JSONERROR(req, res)
      }
    } catch (e) {
      res.locals.errorCode = 401
      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }

  static updateonboarding = async (req: Request, res: Response) => {
    const { loggedInUser, masterUserID } = sanitizeAndValidateObj(req.query)
    try {
      const input = sanitizeAndValidateObj(req.body)
      const id = parseInt(req.params.id, 10)

      if (input.otp) {
        const obj = {
          email: input?.email,
          username: input?.user_name,
          passsword_hash: input?.user_pwd,
       
          // status: input.status,
          user_type: input?.user_type || 1,
          updated_date: new Date(new Date().getTime() + 3600000 * 5.5),
          updated_by: id
          //twofa_auth_code: input.twofa_auth_code,
          // enable_twofa: input.enable_twofa,
        }

        await onboardingLib.updateonboarding({ user_id: id }, obj)
        const data = await onboardingLib.getonboardingById({
          user_id: id
        })

        res.locals.data = data
        res.locals.message = data
          ? Messages.UPDATED
          : Messages.SOMETHING_WENT_WRONG
        ResponseHandler.JSONSUCCESS(req, res)
      } else {
        res.locals.message = 'Please enter correct OTP'
        ResponseHandler.JSONERROR(req, res)
      }
    } catch (e) {
      const input = sanitizeAndValidateObj(req.body)

      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }

  //resetPassword_onboarding
  static resetPassword_onboarding = async (req: Request, res: Response) => {
    const { loggedInUser, masterUserID } = sanitizeAndValidateObj(req.query)
    try {
      const input = sanitizeAndValidateObj(req.body)
      const id = parseInt(req.params.id, 10)

      const obj = {
        password_hash: input?.user_pwd,
       // user_type: input?.user_type || 1,
        modified_on: new Date(new Date().getTime() + 3600000 * 5.5),
        modified_by: id
      }

      await onboardingLib.updateonboarding({ user_id: id }, obj)
      const data = await onboardingLib.getonboardingById({
        user_id: id
      })

      res.locals.data = data
      res.locals.message = data
        ? Messages.UPDATED
        : Messages.SOMETHING_WENT_WRONG
      ResponseHandler.JSONSUCCESS(req, res)
    } catch (e) {
      const input = sanitizeAndValidateObj(req.body)

      res.locals.errors = e.message
      ResponseHandler.JSONERROR(req, res)
    }
  }
}

export default onboardingController

const decrypt = async text => {
  let res = new Promise((resolve, reject) => {
    var bytes = CryptoJS.AES.decrypt(text, 'secret_key@123456')
    var decText = bytes.toString(CryptoJS.enc.Utf8)

    resolve(decText)
  })

  return res
}

const gen_qrcode = secret => {
  return QRCode.toDataURL(secret.otpauth_url, { errorCorrectionLevel: 'M' })
}

const generate2faAuthCode = user_email => {
  const QR_NAME = 'RG'
  var secret = Speakeasy.generateSecret({
    name: QR_NAME + '-' + user_email
  })
  return gen_qrcode(secret).then(url => {
    return { base32: secret.base32, qrUrl: url }
  })
}

export const verify2faAuthCode = (secret, token) => {
  let res = Speakeasy.totp.verify({
    secret: secret,
    encoding: 'base32',
    token: token,
    window: 2
  })
  return res
}
