import { Response, Request } from "express";
import objectPath from "object-path";
import fetch from "node-fetch";
import sha1 from "sha1";
import Messages from "../common/constants";
import { HTTP_METHODS, REQUEST_TYPES } from "../common/common";
import * as ResponseHandler from "../helpers/response.handler";
import {
  sanitizeAndValidateString,
  sanitizeAndValidateObj,
  sanitizeAndValidateDate,
 
} from "../utility/sanitizeAndValidateDate";

class DynamicAPIController {
  static DynamicAPIData = async (req: Request, res: Response) => {
    const { loggedInUser, masterUserID } = sanitizeAndValidateObj(req.query);
    try {
      const input: any = sanitizeAndValidateObj(req.body);

      let data: any = [];
      const headerObj = {
        auth: input["headers"],
        request_type: input["request_type"],
        request_body: input["request_body"],
        input_type: input["input_type"],
        api_url: input["api_url"],
        filter_applicable: input["filter_applicable"],
        filters: input["filters"],
        filter_body: input["filter_body"],
        auth_key: input["auth_key"],
        auth_value: input["auth_value"],
        auth_type: input["auth_type"],
      };

      const [url, obj] = setHeaders(headerObj);

      process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
      if (url) {
        await Promise.resolve(
          fetch(url, obj)
            .then((res) => {
              return res.json();
            })
            .then((json) => {
              if (Array.isArray(json)) {
                json.forEach((d) => {
                  if (input["response_path"]) {
                    data = objectPath.get(json, input["response_path"]);
                  } else {
                    data.push(d);
                  }
                });
              } else {
                if (input["response_path"]) {
                  const key = input["response_path"];
                  data = objectPath.get(json, key);
                } else {
                  data.push(json);
                }
              }

              if (!data) {
                res.locals.message = Messages.NO_DATA;
              } else {
                res.locals.message = Messages.FETCHED;
                let newdata = JSON.parse(JSON.stringify(data));
                
              }
              res.locals.data = data;
              ResponseHandler.JSONSUCCESS(req, res);
            })
        ).catch((e) => {
          console.log("Catch Hit", e);
          //res.locals.message = Messages.SOMETHING_WENT_WRONG;
          //   ThirdPartyAPIErrorLogger.error(`${e},Request : ${url}`);
          res.locals.data = data;
          res.locals.message = e.message;
          ResponseHandler.JSONERROR(req, res);
        });
      } else {
        // res.locals.message = Messages.SOMETHING_WENT_WRONG;
        // ResponseHandler.JSONSUCCESS(req, res);
      }
    } catch (e) {
      const input = sanitizeAndValidateObj(req.body);
      let datalog = {
        pagename: "DynamicAPIController",
        function_name: "DynamicAPIData",
        error_message: e,
        req_body: input && JSON.stringify(input),
        req_id: parseInt(req.params.id),
        createddate: new Date(new Date().getTime() + 3600000 * 5.5),
        created_staff_id: loggedInUser,
        master_user_id: masterUserID,
      };
      //   await errorlogs.adderrorLog(datalog);
      res.locals.errors = e.message;
      ResponseHandler.JSONERROR(req, res);
    }
  };
}

export const setHeaders = (input, rgshift_token = "") => {
  const obj: any = {
    headers: {},
  };
  console.log("===========input", input);
  let url = input["api_url"];
  try {
    const today = new Date().toISOString().slice(0, 10);
    console.log("url", url, input.request_type);
    if (input.auth && input.auth.length) {
      input.auth.forEach((hobj: any) => {
        const authKey = hobj["auth_key"];
        if (hobj.auth_type) {
          obj["headers"][authKey] = sha1(hobj.auth_value);
        } else {
          obj["headers"][authKey] = hobj.auth_value;
        }
      });
    } else if (input.auth_key) {
      const authKey = input["auth_key"];
      if (input.auth_type) {
        obj["headers"][authKey] = sha1(input.auth_value);
      } else {
        obj["headers"][authKey] = input.auth_value;
      }
    }

    if (input.req_token) {
      obj["headers"]["authorization"] = rgshift_token; //input.auth_value;
    }

    // console.log("vj headers", obj, input);

    if (
      input.request_type === HTTP_METHODS.POST ||
      input.request_type === HTTP_METHODS.PUT ||
      input.request_type === HTTP_METHODS.PATCH
    ) {
      obj["method"] = input.request_type;

      console.log("inside post");

      if (input.input_type === REQUEST_TYPES.FORMDATA) {
        const formData = new FormData();
        for (let key in input.request_body) {
          if (!Array.isArray(input.request_body[key])) {
            formData.append(key, input.request_body[key]);
          } else {
            input.request_body[key].forEach((obj, i) => {
              formData.append(key[i], obj);
            });
          }
        }

        // MultiHeaders
        if (input.isMultiAuth) {
          input?.multiAuthArray.map((item: any) => {
            obj["headers"][item.auth_key] = item.auth_value;
          });
        }

        // filter
        if (
          input.filter_applicable &&
          input.filter_body &&
          input.filter_body.length
        ) {
          input.filter_body.forEach((item: any) => {
            const field =
              input.filters &&
              input.filters.find((x: any) => x.key === item.key);

            if (field) {
              switch (field.location) {
                case "query":
                  if (field.isDate && !item.value) {
                    // set current date
                    item.value = today;
                  }
                  url = setApiUrl(input["api_url"], item);
                  break;

                case "form-data":
                  if (field.isDate && !item.value) {
                    // set current date
                    item.value = today;
                  }
                  if (!formData[field.key] && item.value) {
                    formData.append(field.key, item.value);
                  } else {
                    if (item.value) formData[field.key] = item.value;
                  }
                  break;

                default:
                  break;
              }
            }
          });
        }
        obj["body"] = formData;
      } else if (input.input_type === REQUEST_TYPES.JSON) {
        // obj["body"] = input.request_body;
        let bodyData: any = {};
        for (let key in input.request_body) {
          bodyData[key] = input.request_body[key];
        }
        obj["headers"]["Content-type"] = "application/json";

        // MultiHeaders
        if (input.isMultiAuth) {
          input?.multiAuthArray?.map((item: any) => {
            obj["headers"][item.auth_key] = item.auth_value;
          });
        }
        // filter
        if (
          input.filter_applicable &&
          input.filter_body &&
          input.filter_body.length
        ) {
          input.filter_body.forEach((item: any) => {
            const field =
              input.filters &&
              input.filters.find((x: any) => x.key === item.key);

            if (field) {
              switch (field.location) {
                case "query":
                  if (field.isDate && !item.value) {
                    // set current date
                    item.value = today;
                  }
                  url = setApiUrl(input["api_url"], item);
                  break;

                case "json":
                  try {
                    if (field.isDate && !item.value) {
                      // set current date
                      item.value = today;
                    }
                    if (item.value) {
                      bodyData[field.key] = item.value;
                      // obj["body"] = JSON.stringify(obj["body"]);
                    }
                  } catch (error) {
                    console.log("error", error);
                  }
                  break;
                case "get":
                  if (field.isDate && !item.value) {
                    // set current date
                    item.value = today;
                  }
                  let param = setApiUrl(url, item);
                  const splitQueryParams = url.split("?");
                  url = `${splitQueryParams[0]}?${param}`;
                  break;

                default:
                  break;
              }
            }
          });
        }

        obj["body"] = JSON.stringify(bodyData);
      }
    } else if (input.request_type === HTTP_METHODS.GET) {
      obj["method"] = HTTP_METHODS.GET;
      obj["headers"]["Content-type"] = "application/json";
      url = input["api_url"];
      let strArr = [];

      // MultiHeaders
      if (input.isMultiAuth) {
        input?.multiAuthArray.map((item: any) => {
          obj["headers"][item.auth_key] = item.auth_value;
        });
      }
      // filter

      if (
        input.filter_applicable &&
        input.filter_body &&
        input.filter_body.length
      ) {
        input.filter_body.forEach((item: any) => {
          const field = input.filters.find((x: any) => x.key === item.key);
          if (field) {
            if (field.isDate && !item.value) {
              // set current date
              item.value = today;
            }
            let param = setApiUrl(url, item);
            const splitQueryParams = url.split("?");
            url = `${splitQueryParams[0]}?${param}`;
          }
        });

        // if (strArr.length) {
        //     const splitQueryParams = url.split('?');
        //     url = `${splitQueryParams[0]}?${strArr.join('&')}`;

        //    // return url;
        // } else {
        //   //  return url;
        // }
      }
    }

    console.log("Vj url", url, obj);

    return [url, obj];
  } catch (e) {
    console.log("evj", e);
  }
};

const setApiUrl = (apiUrl, field) => {
  const splitQueryParams = apiUrl.split("?");
  const splitParams = splitQueryParams[1] && splitQueryParams[1].split("&");
  const strArr = [];
  let url = apiUrl;
  let param = "";
  if (splitParams) {
    splitParams.forEach((item: any) => {
      const splitParam = item.split("=");

      if (field.key === splitParam[0]) {
        if (field.value) {
          param = `${splitParam[0]}=${field.value}`;
        } else {
          param = `${splitParam[0]}=${splitParam[1]}`;
        }
      } else {
        param = `${splitParam[0]}=${splitParam[1]}`;
      }
      strArr.push(param);
    });
  }

  return strArr.join("&");
};

export default DynamicAPIController;
