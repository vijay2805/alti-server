
import {{ createSlice }} from '@reduxjs/toolkit';

const exampleSlice = createSlice({{
  name: 'example',
  initialState: {{ value: 'hello from mfe-investment' }},
  reducers: {{}},
}});

export const exampleReducer = exampleSlice.reducer;
