
const path = require('path');

module.exports = {
  entry: './src/loader.js',
  output: {
    filename: 'loader.js',
    path: path.resolve(__dirname, 'dist'),
    publicPath: 'auto',
    library: {
      type: 'umd',
      name: 'UniversalLoader'
    }
  },
  mode: 'production'
};
