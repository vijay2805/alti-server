
const mountPointId = 'react-product-root';

function getDataset() {
  const mountNode = document.getElementById(mountPointId);
  if (!mountNode) {
    console.error('[universal-loader] Mount node not found');
    return {};
  }
  return mountNode.dataset || {};
}

async function authenticate(token) {
  // Placeholder: replace with real API call
  // Expected response: { policyId, productType }
  console.log('[universal-loader] Simulating auth for token', token);
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        policyId: 'POLICY-12345',
        productType: 'insurance'
      });
    }, 10);
  });
}

const mfeMap = {
  insurance: 'http://localhost:4301',
  investment: 'http://localhost:4302',
  host: 'http://localhost:4300'
};

async function loadRemote(remoteUrl, globalName) {
  await import(/* webpackIgnore: true */ remoteUrl + '/remoteEntry.js');
  if (!window[globalName]) {
    throw new Error('Remote global ' + globalName + ' not found after loading');
  }
  return window[globalName];
}

(async function() {
  try {
    const dataset = getDataset();
    const token = dataset.token;
    const journeyToken = dataset.journeyToken || null;

    const { policyId, productType } = await authenticate(token);

    const typeKey = (productType || 'host').toLowerCase();
    const baseUrl = mfeMap[typeKey] || mfeMap['host'];
    const globalName = typeKey === 'insurance' ? 'mfe_insurance'
                      : typeKey === 'investment' ? 'mfe_investment'
                      : 'mfe_host';

    console.log('[universal-loader] Loading MFE', typeKey, 'from', baseUrl);

    const mfeApi = await loadRemote(baseUrl, globalName);

    let initialRoute = '/';
    if (typeKey === 'insurance') initialRoute = '/dashboard';
    if (typeKey === 'investment') initialRoute = '/dashboard';

    mfeApi.mount('#' + mountPointId, {
      token,
      journeyToken,
      policyId,
      productType,
      initialRoute
    });
  } catch (err) {
    console.error('[universal-loader] Failed to load MFE', err);
  }
})();
