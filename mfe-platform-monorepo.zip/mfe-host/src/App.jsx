
import React, {{ useEffect }} from 'react';
import {{ Provider }} from 'react-redux';
import {{ BrowserRouter, useNavigate }} from 'react-router-dom';
import {{ store }} from './store';
import {{ AppRoutes }} from './routes/AppRoutes';

const AppInner = ({{ initialRoute, policyId, productType, journeyToken }}) => {{
  const navigate = useNavigate();

  useEffect(() => {{
    if (journeyToken === 'claim') {{
      navigate('/claim', {{ state: {{ policyId }} }});
    }} else if (initialRoute) {{
      navigate(initialRoute, {{ state: {{ policyId }} }});
    }}
  }}, [initialRoute, journeyToken, policyId, navigate]);

  return <AppRoutes />;
}};

export const App = (props) => (
  <Provider store={store}>
    <BrowserRouter>
      <AppInner {{...props}} />
    </BrowserRouter>
  </Provider>
);
