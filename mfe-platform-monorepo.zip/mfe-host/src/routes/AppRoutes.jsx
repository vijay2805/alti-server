
import React from 'react';
import {{ Routes, Route }} from 'react-router-dom';

const Home = () => <div>Home route for mfe-host</div>;
const Dashboard = () => <div>Dashboard for mfe-host</div>;
const Claim = () => <div>Claim journey for mfe-host</div>;
const NotFound = () => <div>Not found in mfe-host</div>;

export const AppRoutes = () => (
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/dashboard" element={<Dashboard />} />
    <Route path="/claim" element={<Claim />} />
    <Route path="*" element={<NotFound />} />
  </Routes>
);
