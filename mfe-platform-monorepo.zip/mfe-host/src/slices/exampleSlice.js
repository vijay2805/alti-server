
import {{ createSlice }} from '@reduxjs/toolkit';

const exampleSlice = createSlice({{
  name: 'example',
  initialState: {{ value: 'hello from mfe-host' }},
  reducers: {{}},
}});

export const exampleReducer = exampleSlice.reducer;
