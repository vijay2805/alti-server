
import React from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './App';

const mounts = {};

const mount = (selector, props) => {
  const container = typeof selector === 'string' ? document.querySelector(selector) : selector;
  if (!container) {
    console.error('[mfe-insurance] Mount failed: container not found');
    return;
  }
  const root = createRoot(container);
  root.render(<App {...props} />);
  mounts[selector] = root;
};

const unmount = (selector) => {
  const root = mounts[selector];
  if (root) {
    root.unmount();
    delete mounts[selector];
  }
};

const api = { mount, unmount };

if (!window.mfe_insurance) {
  window.mfe_insurance = api;
}

export default api;
