
import {{ createSlice }} from '@reduxjs/toolkit';

const exampleSlice = createSlice({{
  name: 'example',
  initialState: {{ value: 'hello from mfe-insurance' }},
  reducers: {{}},
}});

export const exampleReducer = exampleSlice.reducer;
