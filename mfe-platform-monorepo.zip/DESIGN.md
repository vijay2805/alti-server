
# JSP + React Micro Frontends (Module Federation) – Design

## 1. High-Level Architecture

```mermaid
flowchart LR
  User --> JSP["JSP Legacy App<br/>(Internet Banking)"]
  JSP --> DIV["<div id='react-product-root'>"]
  JSP --> Loader["universal-loader.js"]
  Loader --> AuthAPI["Token / Identity API"]
  AuthAPI --> Loader
  Loader --> Decision["Decide productType<br/>(insurance / investment / host)"]
  Decision --> MFE_Ins["mfe-insurance (remoteEntry.js)"]
  Decision --> MFE_Inv["mfe-investment (remoteEntry.js)"]
  Decision --> MFE_Host["mfe-host (remoteEntry.js)"]
  MFE_Ins --> DOM["React mounts into JSP div"]
  MFE_Inv --> DOM
  MFE_Host --> DOM
```

- **JSP** remains the **orchestrator / shell**.
- **universal-loader.js** is the **only script** JSP needs to know.
- Loader calls a **Token / Identity API** using a token embedded in JSP.
- Based on the response (`productType`, `policyId`), loader **selects the correct MFE**.
- Selected MFE is a **Module Federation remote** and mounts React into `#react-product-root`.

---

## 2. Monorepo Structure

```text
mfe-platform/
├── package.json
├── pnpm-workspace.yaml
│
├── universal-loader/
│   ├── src/loader.js
│   ├── webpack.config.js
│   └── package.json
│
├── mfe-host/
│   ├── src/
│   │   ├── index.jsx
│   │   ├── App.jsx
│   │   ├── mount.js
│   │   ├── store.js
│   │   ├── slices/
│   │   └── routes/AppRoutes.jsx
│   ├── webpack.config.js
│   └── package.json
│
├── mfe-insurance/
│   └── (same structure as mfe-host)
│
└── mfe-investment/
    └── (same structure as mfe-host)
```

- All MFEs share the **same entry contract**: `./src/mount.js` exposed as `./App` via Module Federation.
- All MFEs use:
  - **React 18** (upgradeable to 19 later)
  - **React Router v6**
  - **Redux Toolkit** with local store per MFE.

---

## 3. Module Federation Contract

Each MFE exposes the same API:

```js
// webpack.config.js (per MFE)
new ModuleFederationPlugin({
  name: 'mfe_insurance',          // unique per MFE
  filename: 'remoteEntry.js',
  exposes: {
    './App': './src/mount.js',    // common entry
  },
  shared: {
    react: { singleton: true, requiredVersion: false },
    'react-dom': { singleton: true, requiredVersion: false },
    'react-router-dom': { singleton: true, requiredVersion: false },
    '@reduxjs/toolkit': { singleton: true, requiredVersion: false },
    'react-redux': { singleton: true, requiredVersion: false },
  },
});
```

Each `mount.js` exports an API:

```js
export default {
  mount(selector, props),
  unmount(selector)
};
```

The **universal loader** assumes this contract for *all* MFEs.

---

## 4. Execution Flow (End-to-End)

### 4.1 Click in JSP

1. User logs into **JSP Internet Banking**.
2. JSP lists products (insurance, investment, etc.) but does **not** decide React app:
   ```html
   <a href="https://legacy-bank.com/journey?token=XYZ&journeyToken=claim">
     View Details
   </a>
   ```

3. Request lands on a JSP page that renders:

   ```jsp
   <div id="react-product-root"
        data-token="${token}"
        data-journeyToken="${journeyToken}">
   </div>

   <script type="module" src="https://cdn.company.com/universal-loader/loader.js"></script>
   ```

### 4.2 universal-loader.js

1. Reads `data-token` and `data-journeyToken` from `#react-product-root`.
2. Calls **Token / Identity API** with the token:
   - Validates session
   - Returns `{ policyId, productType }`
3. Maps `productType` to one of:
   - `mfe-insurance`
   - `mfe-investment`
   - `mfe-host` (fallback / generic)
4. Dynamically loads the correct **remoteEntry.js** using `import(/* webpackIgnore: true */ url)`.
5. Accesses the global `window.mfe_insurance` / `window.mfe_investment` / `window.mfe_host`.
6. Calls:
   ```js
   mfeApi.mount('#react-product-root', {
     token,
     journeyToken,
     policyId,
     productType,
     initialRoute
   });
   ```

### 4.3 Inside the selected React MFE

1. `mount()` creates a React root with `<App {...props} />`.
2. `App` wraps routes with:
   - `Provider` (Redux Toolkit store)
   - `BrowserRouter` (React Router)
3. `App` computes navigation based on props:
   - If `journeyToken === 'claim'` → navigate to `/claim`
   - Else if `productType === 'insurance'` → navigate to `/dashboard`
   - Else fallback `/`
4. Route components render the corresponding **journey UI** (insurance dashboard, investment view, etc.).

---

## 5. Responsibilities Split

### JSP (Java Team)

- Owns authentication framework, session, core layout.
- Renders:
  - `<div id="react-product-root" ...>`
  - `<script src="universal-loader.js">`
- Does **not** know:
  - Which MFE will load.
  - Any React internals.

### React MFEs (Your Team)

- Owns all journey UI:
  - Insurance journeys
  - Investment journeys
  - Host / shared dashboard
- Implements:
  - Routing (React Router)
  - Local state (Redux Toolkit)
  - Module Federation entry + mount API
- Agrees on a **common mount contract** used by universal loader.

---

## 6. Extensibility

To add a new product (e.g. `pension`):

1. Create new app `mfe-pension/` following the same structure.
2. Configure Module Federation name `mfe_pension`.
3. Add route mapping in universal loader:

   ```js
   const mfeMap = {
     insurance: 'http://localhost:4301',
     investment: 'http://localhost:4302',
     pension: 'http://localhost:4303',
     host: 'http://localhost:4300',
   };
   ```

4. No change is required in JSP.

---

## 7. Non-Goals / Out-of-Scope

- Sharing a single Redux store instance across MFEs.
- Server-side rendering of MFEs.
- Deep-link error handling from JSP layer.
- Security token generation itself (owned by JSP/backend).

---

## 8. Summary

- **Single entry** from JSP: `universal-loader.js`.
- **Dynamic decision** of MFE based on token → API → `productType`.
- **Isolated MFEs** for insurance, investment, host, etc.
- **Stable contract** via Module Federation exposing `./App` (mount API).
- **Monorepo** for easier local development and team collaboration.
