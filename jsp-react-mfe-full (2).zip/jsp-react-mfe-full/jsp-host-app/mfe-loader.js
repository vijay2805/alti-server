const REMOTES = {
  motor: {
    name: "MotorApp",
    url: "http://localhost:3001/remoteEntry.js"
  },
  home: {
    name: "HomeApp",
    url: "http://localhost:3002/remoteEntry.js"
  }
};

let activeUnmount = null;

function loadScript(url) {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = url;
    s.onload = resolve;
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

async function loadProduct(type) {
  const cfg = REMOTES[type];
  const container = document.getElementById("mfe-root");

  if (activeUnmount) {
    activeUnmount();
    activeUnmount = null;
  }
  container.innerHTML = "";

  try {
    if (!window[cfg.name]) {
      await loadScript(cfg.url);
    }

    // ❌ DO NOT call __webpack_init_sharing__ in JSP host

    const factory = await window[cfg.name].get("./App");
    const module = factory();

    activeUnmount = module.mount(container, {
      onBack: () => {
        if (activeUnmount) activeUnmount();
        container.innerHTML = "";
      }
    });
  } catch (e) {
    console.error(e);
    container.innerHTML = "<h3>Failed to load MFE</h3>";
  }
}
