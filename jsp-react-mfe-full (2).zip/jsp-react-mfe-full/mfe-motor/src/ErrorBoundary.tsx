import React from "react";

export class ErrorBoundary extends React.Component<any, any> {
  state = { hasError: false };
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  render() {
    if (this.state.hasError) {
      return <h3>Motor MFE crashed</h3>;
    }
    return this.props.children;
  }
}
