import React from "react";
import ReactDOM from "react-dom/client";
import { ErrorBoundary } from "./ErrorBoundary";

function App({ onBack }: any) {
  console.log("calling in motor")
  return (
    <div>
      <h3>Motor Insurance MFE</h3>
      {/* <button onClick={onBack}>Back to JSP</button> */}
    </div>
  );
}

let root: any;
export function mount(el: HTMLElement, props: any) {
  root = ReactDOM.createRoot(el);
  root.render(
    <ErrorBoundary>
      <App {...props} />
    </ErrorBoundary>
  );
  return () => root.unmount();
}
