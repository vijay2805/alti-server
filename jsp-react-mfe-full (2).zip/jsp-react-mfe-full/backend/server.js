const express = require('express');
const cookieParser = require('cookie-parser');

const app = express();
const PORT = 4000;

// Parse cookies
app.use(cookieParser());

// CORS (only for local dev)
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  next();
});

/**
 * GET policy details
 * Reads SELECTED_POLICY_ID from cookie
 */
app.get('/api/policy/details', (req, res) => {
  const policyId = req.cookies.SELECTED_POLICY_ID;
  console.log('call API', policyId);
  // Simulate session expiry
  if (!policyId) {
    return res.status(401).json({
      message: 'SESSION_EXPIRED',
    });
  }

  // Mock policy DB
  const policies = {
    P1001: {
      policyNumber: 'P1001',
      product: 'Motor',
      status: 'Active',
      premium: '12000',
      holder: 'John Doe',
    },
    P2001: {
      policyNumber: 'P2001',
      product: 'Home',
      status: 'Active',
      premium: '8000',
      holder: 'John Doe',
    },
  };

  const policy = policies[policyId];

  if (!policy) {
    return res.status(404).json({
      message: 'POLICY_NOT_FOUND',
    });
  }
  setTimeout(() => {
    return res.json(policy);
  }, 9000);
});

app.get('/api/policy/context', (req, res) => {
  const policyId = req.cookies.SELECTED_POLICY_ID;
  const saml = req.headers['x-saml-assertion']; // example
  console.log('policy id', policyId);
  // if (!policyId || !saml) {
  if (!policyId) {
    return res.status(401).json({ message: 'SESSION_EXPIRED' });
  }

  // mock lookup
  if (policyId === 'P2001') {
    return res.json({
      policyId,
      productType: 'home',
    //   planType: 'bronze',

      planType: "gold"
    });
  }

  return res.json({
    policyId,
    productType: 'motor',
  });
});

app.get('/api/home/gold/details', (req, res) => {
  const policyId = req.cookies.SELECTED_POLICY_ID;

  if (!policyId) {
    return res.status(401).json({ message: 'SESSION_EXPIRED' });
  }

  res.json({
    policyId,
    plan: 'GOLD',
    premium: '15000',
    coverage: 'Comprehensive',
    benefits: ['Fire', 'Theft', 'Natural Disaster'],
  });
});

app.get('/api/home/bronze/details', (req, res) => {
  const policyId = req.cookies.SELECTED_POLICY_ID;

  if (!policyId) {
    return res.status(401).json({ message: 'SESSION_EXPIRED' });
  }

  res.json({
    policyId,
    plan: 'BRONZE',
    premium: '8000',
    coverage: 'Basic',
    benefits: ['Fire'],
  });
});

app.listen(PORT, () => {
  console.log(`✅ Node Policy API running on http://localhost:${PORT}`);
});
