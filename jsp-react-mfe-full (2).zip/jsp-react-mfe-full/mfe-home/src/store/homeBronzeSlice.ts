import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

interface HomeBronzeState {
  data: any | null;
  loading: boolean;
  error: string | null;
}

const initialState: HomeBronzeState = {
  data: null,
  loading: true,
  error: null
};

export const fetchHomeBronzeDetails = createAsyncThunk<
  any,
  void,
  { rejectValue: string }
>("homeBronze/fetchDetails", async (_, { rejectWithValue }) => {
  const res = await fetch("http://localhost:4000/api/home/bronze/details", {
    credentials: "include"
  });

  if (!res.ok) {
    const err = await res.json();
    return rejectWithValue(err.message);
  }

  return res.json();
});

const homeBronzeSlice = createSlice({
  name: "homeBronze",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchHomeBronzeDetails.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchHomeBronzeDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(fetchHomeBronzeDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload ?? "UNKNOWN_ERROR";
      });
  }
});

export default homeBronzeSlice.reducer;
