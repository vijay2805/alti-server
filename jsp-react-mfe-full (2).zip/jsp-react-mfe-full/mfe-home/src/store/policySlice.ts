import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";

/**
 * Policy context returned from Node API
 * This is ONLY metadata, not full policy details
 */
export interface PolicyContext {
  policyId: string;
  productType: "motor" | "home";
  planType?: "gold" | "bronze";
}

/**
 * Slice state
 */
interface PolicyContextState {
  context: PolicyContext | null;
  loading: boolean;
  error: string | null;
}

/**
 * Initial state
 */
const initialState: PolicyContextState = {
  context: null,
  loading: true,
  error: null
};

/**
 * Thunk: Fetch policy context
 * Reads cookie + SAML on backend
 */
export const fetchPolicyContext = createAsyncThunk<
  PolicyContext,
  void,
  { rejectValue: string }
>(
  "policyContext/fetch",
  async (_, { rejectWithValue }) => {
    const res = await fetch("http://localhost:4000/api/policy/context", {
      credentials: "include"
    });

    if (!res.ok) {
      const err = await res.json();
      return rejectWithValue(err.message);
    }

    return res.json();
  }
);

/**
 * Slice
 */
const policyContextSlice = createSlice({
  name: "policyContext",
  initialState,
  reducers: {
    /**
     * Optional: clear context on logout / back navigation
     */
    clearPolicyContext(state) {
      state.context = null;
      state.loading = false;
      state.error = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchPolicyContext.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        fetchPolicyContext.fulfilled,
        (state, action: PayloadAction<PolicyContext>) => {
          state.loading = false;
          state.context = action.payload;
        }
      )
      .addCase(
        fetchPolicyContext.rejected,
        (state, action: PayloadAction<string | undefined>) => {
          state.loading = false;
          state.error = action.payload ?? "UNKNOWN_ERROR";
        }
      );
  }
});

export const { clearPolicyContext } = policyContextSlice.actions;

export default policyContextSlice.reducer;



// import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";

// interface PolicyState {
//   details: any | null;
//   loading: boolean;
//   error: string | null;
// }

// export const fetchPolicyDetails = createAsyncThunk<
//   any,
//   void,
//   { rejectValue: string }
// >("policy/fetchDetails", async (_, { rejectWithValue }) => {
//   const res = await fetch("http://localhost:4000/api/policy/details", {
//     credentials: "include"
//   });

//   if (!res.ok) {
//     const err = await res.json();
//     return rejectWithValue(err.message);
//   }

//   return res.json();
// });

// // const initialState: PolicyState = {
// //   details: null,
// //   loading: true,
// //   error: null
// // };

// const policySlice = createSlice({
//   name: "policy",
//   initialState,
//   reducers: {},
//   extraReducers: (builder) => {
//     builder
//       .addCase(fetchPolicyDetails.pending, (state) => {
//         state.loading = true;
//         state.error = null;
//       })
//       .addCase(fetchPolicyDetails.fulfilled, (state, action) => {
//         state.loading = false;
//         state.details = action.payload;
//       })
//       .addCase(
//         fetchPolicyDetails.rejected,
//         (state, action: PayloadAction<string | undefined>) => {
//           state.loading = false;
//           state.error = action.payload ?? "UNKNOWN_ERROR";
//         }
//       );
//   }
// });

// export default policySlice.reducer;


// interface PolicyContext {
//     policyId: string;
//     productType: "motor" | "home";
//     planType?: "gold" | "bronze";
//   }

//   interface PolicyContextState {
//     context: {
//       productType: string;
//       planType?: string;
//     } | null;
//     loading: boolean;
//     error: string | null;
//   }
  
//   const initialState: PolicyContextState = {
//     context: null,
//     loading: true,
//     error: null
//   };
  
//   interface State {
//     context: PolicyContext | null;
//     loading: boolean;
//     error: string | null;
//   }

//   export const fetchPolicyContext = createAsyncThunk<
//   PolicyContext,
//   void,
//   { rejectValue: string }
// >("policy/context", async (_, { rejectWithValue }) => {
//   const res = await fetch("http://localhost:4000/api/policy/context", {
//     credentials: "include"
//   });

//   if (!res.ok) {
//     const err = await res.json();
//     return rejectWithValue(err.message);
//   }

//   return res.json();
// });
