import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

interface HomeGoldState {
  data: any | null;
  loading: boolean;
  error: string | null;
}

const initialState: HomeGoldState = {
  data: null,
  loading: true,
  error: null
};

export const fetchHomeGoldDetails = createAsyncThunk<
  any,
  void,
  { rejectValue: string }
>("homeGold/fetchDetails", async (_, { rejectWithValue }) => {
  const res = await fetch("http://localhost:4000/api/home/gold/details", {
    credentials: "include"
  });

  if (!res.ok) {
    const err = await res.json();
    return rejectWithValue(err.message);
  }

  return res.json();
});

const homeGoldSlice = createSlice({
  name: "homeGold",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchHomeGoldDetails.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchHomeGoldDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(fetchHomeGoldDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload ?? "UNKNOWN_ERROR";
      });
  }
});

export default homeGoldSlice.reducer;
