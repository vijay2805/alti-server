import { configureStore } from "@reduxjs/toolkit";
import homeGoldReducer from "./homeGoldSlice";
import homeBronzeReducer from "./homeBronzeSlice";
import policyContextReducer from "./policySlice";

// import policyReducer from "./policySlice";

export const createStore = () =>
  configureStore({
    reducer: {
        policyContext: policyContextReducer,
      homeGold: homeGoldReducer,
      homeBronze: homeBronzeReducer
    }
  });

export type RootState = ReturnType<
  ReturnType<typeof createStore>["getState"]
>;
