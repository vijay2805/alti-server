import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {MemoryRouter, Routes, Route} from "react-router";
// import { fetchPolicyDetails } from "./store/policySlice";
import { RootState } from "./store";
import HomeGoldPolicy from "./routes/HomeGoldPolicy";
import HomeBronzePolicy from "./routes/HomeBronzePolicy";

export default function App({ productType }: any) {
    console.log("calling APP in home")
  const dispatch = useDispatch<any>();
//   const { details, loading, error } = useSelector((s: any) => s.policy);
  const { context, loading } = useSelector((state: RootState) => state.policyContext);
  if (loading) return <p>Loading...</p>;
  if (!context) return <p>No policy</p>;

  let startRoute = "/unsupported";

  if (context.productType === "motor") {
    startRoute = "/motor";
  }

  if (context.productType === "home") {
    startRoute =
      context.planType === "gold"
        ? "/home/gold"
        : "/home/bronze";
  }
// console.log("details", loading)
//   useEffect(() => {
//     dispatch(fetchPolicyDetails());
//   }, []);

// useEffect(() => {
//     console.log("calling inside useEffect")
//     const id = setTimeout(() => {
//       dispatch(fetchPolicyDetails());
//     }, 0);
  
//     return () => clearTimeout(id);
//   }, []);
  

//   if (loading) return <p>Loading policy...</p>;

//   if (error === "SESSION_EXPIRED") {
//     return <p>Session expired. Please login again.</p>;
//   }

//   if (error) return <p>Error: {error}</p>;

  return (
    // <div>
    //   <h3>Policy Details</h3>
    //   <p>Policy Number: {details.policyNumber}</p>
    //   <p>Status: {details.status}</p>
    //   <p>Premium: {details.premium}</p>
    //   <p>Holder: {details.holder}</p>
    // </div>
    <MemoryRouter initialEntries={[startRoute]}>
      <Routes>
        {/* <Route path="/motor" element={<MotorPolicy />} /> */}
        <Route path="/home/gold" element={<HomeGoldPolicy />} />
  <Route path="/home/bronze" element={<HomeBronzePolicy />} />
      </Routes>
    </MemoryRouter>
  );
}
