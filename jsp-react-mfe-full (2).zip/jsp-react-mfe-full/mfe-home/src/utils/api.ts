import axios from "axios";

export const api = axios.create({
  baseURL: "/api",   // SAME ORIGIN as JSP
  withCredentials: true
});
