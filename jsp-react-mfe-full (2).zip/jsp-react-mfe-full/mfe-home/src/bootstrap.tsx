import React from "react";
import ReactDOM from "react-dom/client";
import { Provider } from "react-redux";
import { createStore } from "./store";
import App from "./App";
import { fetchPolicyContext } from "./store/policySlice";

let root: ReactDOM.Root | null = null;

export function mount(el: HTMLElement, props: any) {
  console.log("initial call")
  const store = createStore(); // 🔥 per-mount store

  root = ReactDOM.createRoot(el);
  root.render(
    <Provider store={store}>
      <App {...props} />
    </Provider>
  );
  store.dispatch(fetchPolicyContext());

  return () => root?.unmount();
}
