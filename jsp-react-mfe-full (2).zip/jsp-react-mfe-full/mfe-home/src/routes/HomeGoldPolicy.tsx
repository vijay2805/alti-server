import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchHomeGoldDetails } from "../store/homeGoldSlice";

export default function HomeGoldPolicy() {
  const dispatch = useDispatch<any>();
  const { data, loading, error } = useSelector((s: any) => s.homeGold);

  useEffect(() => {
    dispatch(fetchHomeGoldDetails());
  }, []);

  if (loading) return <p>Loading Home Gold policy...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h3>Home Policy – Gold Plan</h3>
      <p>Policy ID: {data.policyId}</p>
      <p>Premium: ₹{data.premium}</p>
      <p>Coverage: {data.coverage}</p>

      <h4>Benefits</h4>
      <ul>
        {data.benefits.map((b: string) => (
          <li key={b}>{b}</li>
        ))}
      </ul>
    </div>
  );
}
