import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchHomeBronzeDetails } from "../store/homeBronzeSlice";

export default function HomeBronzePolicy() {
  const dispatch = useDispatch<any>();
  const { data, loading, error } = useSelector((s: any) => s.homeBronze);

  useEffect(() => {
    dispatch(fetchHomeBronzeDetails());
  }, []);

  if (loading) return <p>Loading Home Bronze policy...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h3>Home Policy – Bronze Plan</h3>
      <p>Policy ID: {data.policyId}</p>
      <p>Premium: ₹{data.premium}</p>
      <p>Coverage: {data.coverage}</p>

      <h4>Benefits</h4>
      <ul>
        {data.benefits.map((b: string) => (
          <li key={b}>{b}</li>
        ))}
      </ul>
    </div>
  );
}
