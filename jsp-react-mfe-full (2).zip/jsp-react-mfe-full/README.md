# Fully executable JSP + React 19 MFE sample
